<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SwimHub Homepage</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="styles/styles.css"> 
  <style>
    /* General styles */
    body {
      font-family: 'Poppins', sans-serif;
      margin: 0;
      padding: 0;
      background: linear-gradient(180deg, #f0f9ff 0%, #e0f2fe 100%);
      color: #0c4a6e;
      line-height: 1.6;
    }

    /* User Icon Styles */
    .user-icon {
      cursor: pointer;
      transition: transform 0.3s ease;
    }

    .user-icon:hover {
      transform: scale(1.1);
    }

    .user-icon img {
      height: 36px;
      width: 36px;
      border-radius: 50%;
      border: 2px solid #bae6fd;
      box-shadow: 0 2px 8px rgba(2, 132, 199, 0.2);
    }

    /* Main content styles */
    .container {
      max-width: 1200px;
      margin: 40px auto;
      padding: 0 25px;
    }

    h1 {
      font-family: 'Playfair Display', serif;
      font-size: 3.5rem;
      color: #075985;
      margin-bottom: 15px;
      text-shadow: 1px 1px 3px rgba(8, 47, 73, 0.1);
      line-height: 1.2;
      text-align: center;
    }

    h2 {
      font-family: 'Montserrat', sans-serif;
      font-size: 1.8rem;
      color: #0ea5e9;
      margin-bottom: 30px;
      font-weight: 400;
      text-align: center;
    }

    /* Benefits section */
    .benefits-section {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 30px;
      margin: 50px 0;
    }

    .benefit-card {
      background-color: #fff;
      border-radius: 16px;
      padding: 0;
      text-align: center;
      box-shadow: 0 8px 20px rgba(2, 132, 199, 0.15);
      overflow: hidden;
      transition: transform 0.4s ease, box-shadow 0.4s ease;
      position: relative;
    }

    .benefit-card:hover {
      transform: translateY(-10px);
      box-shadow: 0 12px 25px rgba(2, 132, 199, 0.25);
    }

    .benefit-card img {
      width: 100%;
      height: 250px;
      object-fit: cover;
      filter: brightness(0.9);
      transition: filter 0.3s ease;
    }

    .benefit-card:hover img {
      filter: brightness(1);
    }

    .benefit-card h2 {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      background: linear-gradient(transparent, rgba(6, 182, 212, 0.8));
      color: white;
      padding: 80px 20px 20px;
      margin: 0;
      font-family: 'Montserrat', sans-serif;
      font-weight: 700;
      font-size: 1.8rem;
      text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.3);
    }

    /* Swimming classes section */
    .swimming-section {
      display: flex;
      gap: 30px;
      margin: 70px 0;
      align-items: center;
    }
    
    .swimming-section img {
      width: 55%;
      height: 400px;
      object-fit: cover;
      border-radius: 16px;
      box-shadow: 5px 5px 15px rgba(2, 132, 199, 0.2);
      transition: transform 0.4s ease;
    }
    
    .swimming-section img:hover {
      transform: scale(1.02);
    
    }
    
    .swimming-section .details {
      background-color: #fff;
      padding: 40px;
      border-radius: 16px;
      box-shadow: 0 8px 20px rgba(2, 132, 199, 0.15);
      width: 45%;
      display: flex;               /* Added */
      flex-direction: column;     /* Added */
      align-items: center;        /* Added - This centers the button */
      text-align: center;         /* Added - Optional: centers text too */
    }
    
    .swimming-section .details h2 {
      font-family: 'Playfair Display', serif;
      font-size: 2.2rem;
      color: #075985;
      margin-bottom: 20px;
      font-weight: 700;
      text-align: center;         /* Added to keep heading centered */
    }
    
    .swimming-section .details p {
      margin-bottom: 30px;
      color: #334155;
      font-size: 1.1rem;
      text-align: center;         /* Added to keep paragraph centered */
    }
    
    .swimming-section .details button {
      background: linear-gradient(90deg, #0284c7 0%, #0ea5e9 100%);
      color: #fff;
      border: none;
      padding: 14px 30px;
      border-radius: 50px;
      cursor: pointer;
      transition: all 0.3s ease;
      font-weight: 600;
      font-size: 1rem;
      letter-spacing: 0.5px;
      box-shadow: 0 4px 10px rgba(2, 132, 199, 0.3);/* No changes needed to button styles - it will center automatically */
    }
    
    .swimming-section .details button:hover {
      background: linear-gradient(90deg, #0369a1 0%, #0284c7 100%);
      transform: translateY(-2px);
      box-shadow: 0 6px 15px rgba(2, 132, 199, 0.4);
    }

    /* Reviews section */
    .reviews-section {
      margin: 80px 0;
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 30px;
    }

    .review-card {
      background-color: #fff;
      border-radius: 16px;
      padding: 30px;
      text-align: center;
      box-shadow: 0 8px 20px rgba(2, 132, 199, 0.1);
      transition: transform 0.3s ease;
    }

    .review-card:hover {
      transform: translateY(-10px);
    }

    .review-card img {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      object-fit: cover;
      margin-bottom: 20px;
      border: 4px solid #bae6fd;
      box-shadow: 0 4px 10px rgba(2, 132, 199, 0.2);
    }

    .review-card .rating {
      color: #f59e0b;
      font-size: 1.5rem;
      margin: 15px 0;
      letter-spacing: 3px;
    }

    .review-card p {
      font-style: italic;
      color: #475569;
      position: relative;
    }

    .review-card p::before,
    .review-card p::after {
      content: '"';
      font-size: 1.5rem;
      color: #0ea5e9;
      opacity: 0.6;
    }

    @media (max-width: 768px) {
      header {
        flex-direction: column;
        padding: 15px;
      }
      
      header nav ul {
        margin-top: 15px;
        flex-wrap: wrap;
        justify-content: center;
      }
      
      h1 {
        font-size: 2.5rem;
      }
      
      h2 {
        font-size: 1.4rem;
      }
      
      .benefits-section,
      .reviews-section {
        grid-template-columns: 1fr;
      }
      
      .swimming-section {
        flex-direction: column;
      }
      
      .swimming-section img,
      .swimming-section .details {
        width: 100%;
      }
    }
  </style>
</head>
<body>
  <!-- Header -->
<?php 
include 'public_header.php';
include 'session_check.php';
 ?>


  <!-- Main Content -->
  <div class="container">
    <!-- Welcome Section -->
    <section>
      <h1>Welcome to SwimHub</h1>
      <h2>Dive into Confidence, Skill, and Fun</h2>
    </section>

    <!-- Benefits Section -->
    <section class="benefits-section">
      <div class="benefit-card">
        <img src="image/1.jpeg" alt="Benefit Image">
        <h2>Key Benefits of Joining</h2>
      </div>
      <div class="benefit-card">
        <img src="image/2.jpeg" alt="Benefit Image">
        <h2>Who Can Join?</h2>
      </div>
    </section>

    <!-- Swimming Classes Section -->
    <section class="swimming-section">
      <img src="image/3.jpeg" alt="Swimming Class Image">
      <div class="details">
        <h2>Swimming Classes</h2>
        <p>Join our expert-led swimming classes designed for all skill levels. Whether you're just starting out or looking to refine your technique, our certified instructors will guide you every stroke of the way.</p>
        <button>View Membership</button>
      </div>
    </section>

    <!-- Reviews Section -->
    <section class="reviews-section">
      <div class="review-card">
        <img src="image/4.jpeg" alt="User Profile">
        <div class="rating">★★★★★</div>
        <p>The instructors are amazing! My kids learned so much in just a few weeks.</p>
      </div>
      <div class="review-card">
        <img src="image/5.jpeg" alt="User Profile">
        <div class="rating">★★★★☆</div>
        <p>Great facilities and professional staff. Highly recommend for adult beginners.</p>
      </div>
      <div class="review-card">
        <img src="image/6.jpeg" alt="User Profile">
        <div class="rating">★★★★★</div>
        <p>Transformed my swimming technique completely. Worth every penny!</p>
      </div>
    </section>
  </div>
  
</body>
</html>
