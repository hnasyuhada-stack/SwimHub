<body>
  <div class="dashboard-container">
    <!-- sidebar, main content, etc. -->
  </div>
  <footer>
    © 2025 SwimHub. All rights reserved.
  </footer>
</body>
