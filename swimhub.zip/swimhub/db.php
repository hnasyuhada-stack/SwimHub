<?php
$host = "localhost";
$port = "3307"; 
$dbname = "swimhub";
$user = "root";
$pass = ""; 


// Create connection (specify port number as fifth parameter)
$conn = new mysqli($host, $user, $pass, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>