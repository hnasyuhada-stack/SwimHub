<?php
session_start();
include 'db.php';
$payment_id = $_GET['payment_id'] ?? 0;

// Fetch payment info
$stmt = $conn->prepare("SELECT * FROM payment WHERE payment_id=?");
$stmt->bind_param("i", $payment_id);
$stmt->execute();
$payment = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$payment || $payment['status'] !== 'Pending') {
    header("Location: viewpayment.php?msg=notfound");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Mock Payment Gateway | SwimHub</title>
    <meta charset="UTF-8">
    <style>
        body {
            background: #f0f9ff;
            font-family: 'Segoe UI', Arial, sans-serif;
            color: #193356;
        }
        .gateway-container {
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 4px 24px rgba(2,132,199,0.08);
            max-width: 410px;
            margin: 64px auto 0 auto;
            padding: 40px 36px 32px 36px;
            text-align: center;
        }
        .gateway-title {
            color: #0284c7;
            font-size: 1.6rem;
            font-weight: 700;
            margin-bottom: 22px;
        }
        .gateway-info {
            font-size: 1.1rem;
            margin-bottom: 18px;
        }
        .label {
            color: #0284c7;
            font-weight: 600;
        }
        .amount {
            color: #1e40af;
            font-size: 1.22rem;
            font-weight: bold;
        }
        .gateway-actions {
            display: flex;
            justify-content: center;
            gap: 16px;
            margin-top: 32px;
        }
        .pay-btn, .back-btn {
            padding: 13px 36px;
            font-size: 1.08rem;
            border-radius: 25px;
            border: none;
            cursor: pointer;
            font-weight: 600;
            box-shadow: 0 2px 8px rgba(2,132,199,0.07);
            transition: background 0.18s;
            outline: none;
        }
        .pay-btn {
            background: linear-gradient(90deg, #0284c7, #0ea5e9);
            color: #fff;
        }
        .pay-btn:hover {
            background: linear-gradient(90deg, #0369a1, #0284c7);
        }
        .back-btn {
            background: #e0f2fe;
            color: #0284c7;
        }
        .back-btn:hover {
            background: #bae6fd;
            color: #075985;
        }
        @media (max-width: 600px) {
            .gateway-container {
                padding: 18px 6vw;
            }
            .gateway-actions {
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="gateway-container">
        <div class="gateway-title">Mock Payment Gateway</div>
        <div class="gateway-info">
            Pay for: <span class="label"><?= htmlspecialchars($payment['description'] ?? "Membership Payment") ?></span>
        </div>
        <div class="gateway-info">
            Amount: <span class="amount">RM <?= number_format($payment['amount'], 2) ?></span>
        </div>
        <form method="post" action="pay_now.php">
            <input type="hidden" name="payment_id" value="<?= $payment_id ?>">
            <div class="gateway-actions">
                <button type="submit" class="pay-btn" name="confirm" value="1">Confirm Payment</button>
                <a href="viewpayment.php" class="back-btn" style="display:inline-block;text-decoration:none;line-height:38px;">Back</a>
            </div>
        </form>
    </div>
</body>
</html>
