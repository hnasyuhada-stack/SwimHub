-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Jul 17, 2025 at 01:45 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `swimhub`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_email` varchar(100) NOT NULL,
  `admin_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(3, 'System Admin', 'admin@gmail.com', '$2y$10$LSPS7z.o27GAltdveZQq4e2cFidnETe2XWWBdxVaCoE0byDm8Xoly');

-- --------------------------------------------------------

--
-- Table structure for table `membership_package`
--

CREATE TABLE `membership_package` (
  `package_id` int(11) NOT NULL,
  `package_name` varchar(100) DEFAULT NULL,
  `package_age_group` varchar(20) DEFAULT NULL,
  `package_class` varchar(10) DEFAULT NULL,
  `package_session` int(11) DEFAULT NULL,
  `package_duration` int(11) DEFAULT NULL,
  `package_price` decimal(10,2) DEFAULT NULL,
  `package_desc` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `membership_package`
--

INSERT INTO `membership_package` (`package_id`, `package_name`, `package_age_group`, `package_class`, `package_session`, `package_duration`, `package_price`, `package_desc`) VALUES
(1, 'Standard Adult', '18+', '4', 10, 3, 1000.00, 'Adult membership, small group'),
(2, 'Basic Kids', '3-6', '4', 10, 3, 650.00, 'Kids, medium group'),
(8, 'Toddler Splash', '3-6', '4', 8, 3, 400.00, 'Gentle introduction to water safety and confidence through fun games for toddlers. Parents may join in for support.'),
(9, 'Adult Beginner', '18+', '8', 10, 3, 600.00, 'Learn swimming from scratch with confidence in a supportive, small group. Perfect for non-swimmers and those overcoming water fear.'),
(10, 'Intensive Weekend Booster', '18+', '16', 4, 1, 800.00, 'Four fast-paced sessions over weekends. Perfect for a quick boost or school holiday crash course.');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `membership_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `paid_date` datetime NOT NULL DEFAULT current_timestamp(),
  `reference_no` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `user_id`, `membership_id`, `amount`, `description`, `status`, `paid_date`, `reference_no`) VALUES
(136, 23, 40, 800.00, 'New membership for package 10', 'Paid', '2025-07-02 19:53:17', 'TXN68651DADAACFD'),
(137, 23, 40, 800.00, 'Renew membership for package #10 (1 months). New expiry: 2025-09-02', 'Paid', '2025-07-02 19:54:55', 'TXN68651E0F515B6'),
(138, 17, 41, 600.00, 'New membership for package 9', 'Paid', '2025-07-02 19:57:18', 'TXN68651E9E9E6C5'),
(139, 24, 42, 800.00, 'New membership for package 10', 'Paid', '2025-07-02 20:29:15', 'TXN6865261B906E7'),
(140, 24, 42, 800.00, 'Renew membership for package #10 (1 months). New expiry: 2025-09-03', 'Paid', '2025-07-02 20:30:00', 'TXN686526480676F'),
(141, 24, 42, 800.00, 'Renew membership for package #10 (1 months). New expiry: 2025-10-03', 'Paid', '2025-07-02 20:30:11', 'TXN686526535A3AF'),
(142, 25, 43, 800.00, 'New membership for package 10', 'Paid', '2025-07-03 11:03:51', 'TXN6865F31779442'),
(143, 25, 43, 800.00, 'Renew membership for package #10 (1 months). New expiry: 2025-09-04', 'Paid', '2025-07-03 11:04:22', 'TXN6865F3360348F'),
(144, 17, 41, 600.00, 'Renew membership for package #9 (3 months). New expiry: 2026-01-23', 'Paid', '2025-07-03 11:09:36', 'TXN6865F47045801');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phoneno` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `swimming_level` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `email`, `password`, `phoneno`, `age`, `swimming_level`) VALUES
(17, 'HANA 2', 'BINTI HANIS', 'hana@gmail.com', '$2y$10$JIKr4UzEArWjf31X5NOuKu3A7r9wu6z9HaeB0gRRZNUGD.mPW7hgK', '0199448015', 22, 'Intermediate'),
(18, 'Aqeel', 'M', 'aqeel@gmail.com', '$2y$10$Dc5JQlcj/lEctuMMChQsDeqS/Q/HOLN.jve9vtEHdn.nW7xSzhaeq', '0199448015', 22, 'Advanced'),
(23, 'HANA', 'BINTI HANIS', 'siti@gmail.com', '$2y$10$nIVcqGLCHIMVnYJIJ4o6VORlKQgNESpTCosgNaB0s.Oay.Nz0lwoC', '0199448015', 25, 'Advanced'),
(24, 'hasya', 'syuhada', 'kamal@gmail.com', '$2y$10$HyHdEMzLNngRZhN3nC7EWeqA..oeGnhgwJcM7wTR0tQ74tbnRZI2e', '0199448015', 25, 'Advanced'),
(25, 'HANA', 'BINTI HANIS', 'test@gmail.com', '$2y$10$imu.Idbwnc0nd58ul.iVO.syzkL2O8QnB/OjIC9l9tfOrRrEq3Rae', '0199448015', 25, 'Beginner');

-- --------------------------------------------------------

--
-- Table structure for table `user_membership`
--

CREATE TABLE `user_membership` (
  `membership_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `package_id` int(11) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `selected_class_size` varchar(10) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `sessions_remaining` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_membership`
--

INSERT INTO `user_membership` (`membership_id`, `user_id`, `package_id`, `status`, `selected_class_size`, `start_date`, `expiry_date`, `end_date`, `sessions_remaining`) VALUES
(40, 23, 10, 'Active', NULL, '2025-07-02', NULL, '2025-09-02', NULL),
(41, 17, 9, 'Active', NULL, '2025-07-23', NULL, '2026-01-23', NULL),
(42, 24, 10, 'Active', NULL, '2025-07-03', NULL, '2025-10-03', NULL),
(43, 25, 10, 'Active', NULL, '2025-07-04', NULL, '2025-09-04', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `admin_email` (`admin_email`);

--
-- Indexes for table `membership_package`
--
ALTER TABLE `membership_package`
  ADD PRIMARY KEY (`package_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_membership`
--
ALTER TABLE `user_membership`
  ADD PRIMARY KEY (`membership_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `membership_package`
--
ALTER TABLE `membership_package`
  MODIFY `package_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `user_membership`
--
ALTER TABLE `user_membership`
  MODIFY `membership_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
