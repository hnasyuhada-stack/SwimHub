<?php
session_start();
include 'db.php';

if (isset($_POST['payment_id']) && isset($_POST['confirm'])) {
    $payment_id = (int)$_POST['payment_id'];
    $ref_no = strtoupper(uniqid("TXN"));

    // Mark as paid, add ref no & paid date
    $stmt = $conn->prepare("UPDATE payment SET status='Paid', paid_date=NOW(), reference_no=? WHERE payment_id=?");
    $stmt->bind_param("si", $ref_no, $payment_id);
    $stmt->execute();
    $stmt->close();

    // Fetch payment info
    $stmt = $conn->prepare("SELECT * FROM payment WHERE payment_id=?");
    $stmt->bind_param("i", $payment_id);
    $stmt->execute();
    $payment = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($payment) {
        $membership_id = $payment['membership_id'];

        // UPGRADE
        if (preg_match('/Upgrade to package #(\d+)/', $payment['description'], $matches)) {
            $new_package_id = (int)$matches[1];

            // Find current end date
            $stmt3 = $conn->prepare("SELECT end_date FROM user_membership WHERE membership_id=?");
            $stmt3->bind_param("i", $membership_id);
            $stmt3->execute();
            $stmt3->bind_result($end_date);
            $stmt3->fetch();
            $stmt3->close();

            // Set new end_date to the later of old end_date or 1 month from now
            $now_plus_1_month = date('Y-m-d', strtotime('+1 month'));
            $new_end_date = max($end_date, $now_plus_1_month);

            $stmt2 = $conn->prepare("UPDATE user_membership SET package_id=?, end_date=? WHERE membership_id=?");
            $stmt2->bind_param("isi", $new_package_id, $new_end_date, $membership_id);
            $stmt2->execute();
            $stmt2->close();
        }
        // RENEW
        else if (strpos($payment['description'], 'Renew') === 0) {
            // Get package duration from membership_package
            $stmt4 = $conn->prepare("SELECT package_id FROM user_membership WHERE membership_id=?");
            $stmt4->bind_param("i", $membership_id);
            $stmt4->execute();
            $stmt4->bind_result($package_id);
            $stmt4->fetch();
            $stmt4->close();

            $stmt5 = $conn->prepare("SELECT package_duration FROM membership_package WHERE package_id=?");
            $stmt5->bind_param("i", $package_id);
            $stmt5->execute();
            $stmt5->bind_result($package_duration);
            $stmt5->fetch();
            $stmt5->close();

            // Get the current end date
            $stmt6 = $conn->prepare("SELECT end_date FROM user_membership WHERE membership_id=?");
            $stmt6->bind_param("i", $membership_id);
            $stmt6->execute();
            $stmt6->bind_result($current_end_date);
            $stmt6->fetch();
            $stmt6->close();

            $now = date('Y-m-d');
            $base = (strtotime($current_end_date) > strtotime($now)) ? $current_end_date : $now;

            // Calculate new end date
            $new_end_date = date('Y-m-d', strtotime("+$package_duration months", strtotime($base)));

            $stmt7 = $conn->prepare("UPDATE user_membership SET end_date=? WHERE membership_id=?");
            $stmt7->bind_param("si", $new_end_date, $membership_id);
            $stmt7->execute();
            $stmt7->close();
        }
        // (Optional: handle other payment types if needed)
    }

    header("Location: viewpayment.php?msg=success&receipt=$payment_id");
    exit();
}
?>
