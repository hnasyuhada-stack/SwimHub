<?php
include 'db.php';

$successMsg = "";
if (isset($_SESSION['success'])) {
    $successMsg = $_SESSION['success'];
    unset($_SESSION['success']);
}

$email = $password = "";
$emailErr = $passwordErr = "";
$loginErr = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $password = trim($_POST["password"]);

    // Validate email
    if (empty($email)) {
        $emailErr = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email format.";
    } elseif (!str_ends_with($email, ".com")) {
        $emailErr = "Email must end with .com";
    }

    // Validate password
    if (empty($password)) {
        $passwordErr = "Password is required.";
    } elseif (strlen($password) < 6) {
        $passwordErr = "Password must be at least 6 characters";
    }

    // If no errors, check credentials
    if (empty($emailErr) && empty($passwordErr)) {
        $sql = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                // Set session variables
                $_SESSION['user_id']         = $row['user_id'];
                $_SESSION['first_name']      = $row['first_name'];
                $_SESSION['last_name']       = $row['last_name'];
                $_SESSION['email']           = $row['email'];
                $_SESSION['phoneno']         = $row['phoneno'];
                $_SESSION['age']             = $row['age'];
                $_SESSION['swimming_level']  = $row['swimming_level'];
                header("Location: userhomepage.php");
                exit();
            } else {
                $loginErr = "Invalid password.";
            }
        } else {
            $loginErr = "No account found with this email.";
        }
        $stmt->close();
    }
}
?>
<?php if (isset($_GET['timeout'])): ?>
  <div class="timeout-alert" id="timeoutAlert">
    <span class="timeout-icon">⏰</span>
    <span>Session expired due to inactivity. Please login again.</span>
    <button type="button" class="close-btn" onclick="document.getElementById('timeoutAlert').style.display='none';">&times;</button>
  </div>
<?php endif; ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login | SwimHub</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">
    <style>
:root {
  --primary: #0284c7;
  --primary-dark: #075985;
  --primary-light: #e0f2fe;
  --accent: #06b6d4;
  --error: #ef4444;
  --success: #10b981;
  --text: #1e293b;
  --text-light: #64748b;
  --background: #f0f9ff;
}
.timeout-alert {
  display: flex;
  align-items: center;
  background: linear-gradient(90deg, #fffbe6 60%, #ffe1e7 100%);
  border: 1.5px solid #fde68a;
  color: #b45309;
  font-weight: 600;
  font-size: 1.09rem;
  padding: 14px 22px;
  border-radius: 12px;
  margin-bottom: 18px;
  box-shadow: 0 4px 16px rgba(251,191,36,0.10);
  position: relative;
  animation: fadeInDown 0.4s;
}
.timeout-icon {
  font-size: 1.25em;
  margin-right: 14px;
}
.close-btn {
  background: transparent;
  border: none;
  color: #e11d48;
  font-size: 1.4em;
  font-weight: bold;
  cursor: pointer;
  margin-left: auto;
  transition: color 0.16s;
}
.close-btn:hover {
  color: #be123c;
}
@keyframes fadeInDown {
  from { opacity: 0; transform: translateY(-20px);}
  to { opacity: 1; transform: translateY(0);}
}

.login-container {
  width: 100%;
  margin-top: 1px;
  max-width: 420px;
  background: rgba(255,255,255,0.98);
  padding: 40px 38px 32px 38px;
  border-radius: 18px;
  box-shadow: 0 10px 32px rgba(2, 132, 199, 0.15);
  border: 1px solid #e0f2fe;
  display: flex;
  flex-direction: column;
  align-items: center;
  position: relative;
  overflow: hidden;
}
.login-container::before {
  content: '';
  position: absolute;
  top: 0; left: 0; width: 100%; height: 8px;
  background: linear-gradient(90deg, var(--primary) 0%, var(--accent) 100%);
}
.login-container .logo-header {
  text-align: center;
}
.login-container .logo {
  width: 70px;
  height: 70px;
  margin: 0 auto 10px auto;
  display: block;
}
.login-container .academy-name {
  font-family: 'Montserrat', sans-serif;
  font-weight: 700;
  font-size: 1.5rem;
  color: #075985;
  margin: 10px 0 0 0;
}
.login-container .academy-subtitle {
  font-family: 'Poppins', sans-serif;
  font-size: 1rem;
  color: #64748b;
  margin-top: 5px;
  margin-bottom: 10px;
}
.login-container form label {
  font-weight: 600;
  color: #1e293b;
  margin-top: 10px;
  margin-bottom: 6px;
  font-size: 1rem;
  display: block;
}
.required-star {
  color: #ef4444;
  font-weight: 700;
  margin-left: 3px;
  font-size: 1.1em;
}
.input-wrapper,
.password-wrapper {
  width: 100%;
  display: flex;
  align-items: center;
  position: relative;
}
.input-wrapper input[type="email"],
.password-wrapper input[type="password"],
.password-wrapper input[type="text"] {
  width: 100%;
  padding: 14px 44px 14px 14px;
  border: 2px solid #e2e8f0;
  border-radius: 8px;
  font-size: 1rem;
  background-color: #f8fafc;
  margin-bottom: 5px;
  transition: border 0.2s, box-shadow 0.2s;
  display: block;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}
.input-wrapper input[type="email"].error,
.password-wrapper input.error {
    border-color: #ef4444;
    background: #fff0f0;
}
.input-wrapper input[type="email"]:focus,
.password-wrapper input[type="password"]:focus,
.password-wrapper input[type="text"]:focus {
  border-color: #0284c7;
  outline: none;
  box-shadow: 0 0 0 3px rgba(2,132,199,0.13);
  background: #fff;
}
.toggle-password {
  position: absolute;
  right: 15px;
  top: 50%;
  transform: translateY(-50%);
  cursor: pointer;
  font-size: 1.3rem;
  color: #64748b;
  user-select: none;
  z-index: 10;
}
.form-error {
    color: #ef4444;
    font-size: 0.99em;
    margin-bottom: 3px;
    margin-top: -4px;
    margin-left: 1px;
    text-align: left;
    font-weight: 500;
    letter-spacing: 0.01em;
}
.success-msg {
    background: #d1fae5;
    color: #047857;
    padding: 14px 20px;
    margin-bottom: 20px;
    border-radius: 8px;
    text-align: center;
    font-weight: 600;
    font-size: 1rem;
}
.login-container button[type="submit"] {
  width: 100%;
  margin-top: 25px;
  padding: 15px 0;
  background: linear-gradient(90deg,#0284c7 0%, #06b6d4 100%);
  color: #fff;
  border: none;
  border-radius: 8px;
  font-size: 1.1rem;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.2s;
  box-shadow: 0 4px 12px rgba(2,132,199,0.12);
}
.login-container button[type="submit"]:hover {
  background: linear-gradient(90deg,#0369a1 0%, #0284c7 100%);
  transform: translateY(-1.5px);
  box-shadow: 0 8px 24px rgba(2,132,199,0.19);
}
.login-container .text-center {
  text-align: center;
  margin-top: 23px;
  color: #64748b;
  font-size: 1rem;
}
.login-container .text-center a {
  color: #0284c7;
  font-weight: 600;
  text-decoration: none;
  transition: color 0.17s;
}
.login-container .text-center a:hover {
  color: #075985;
  text-decoration: underline;
}
.login-container .login-error {
  color: #ef4444;
  text-align: center;
  background: rgba(239,68,68,0.09);
  padding: 10px 0;
  border-radius: 8px;
  margin-bottom: 16px;
  font-size: 1rem;
}
@media (max-width: 480px) {
  .login-container {
    padding: 28px 9px 22px 9px;
    margin: 30px 6px 0 6px;
  }
  .login-container .logo { width: 50px; height: 50px; }
  .login-container .academy-name { font-size: 1.1rem; }
}
</style>
</head>
<body>
<div style="margin: 80px 0; display: flex; justify-content: center; align-items: flex-start;">
<div class="login-container">
  <div class="logo-header">
      <img src="image/logo.png" alt="SwimHub Logo" class="logo">
      <h1 class="academy-name">SwimHub</h1>
      <p class="academy-subtitle">Swimming Academy</p>
  </div>

  <?php if (!empty($successMsg)): ?>
      <div class="success-msg"><?= htmlspecialchars($successMsg); ?></div>
  <?php endif; ?>

  <?php if (!empty($loginErr)): ?>
      <div class="login-error"><?= $loginErr; ?></div>
  <?php endif; ?>

<form id="loginForm" method="post" action="" novalidate>
    <label for="email">Email <span class="required-star">*</span></label>
    <div class="input-wrapper">
        <input 
            type="email" 
            id="email" 
            name="email" 
            value="<?= htmlspecialchars($email); ?>" 
            placeholder="yourname@example.com"
            class="<?= $emailErr ? 'error' : '' ?>"
            required
        >
    </div>
    <div id="emailError" class="form-error"><?= $emailErr; ?></div>

    <label for="password">Password <span class="required-star">*</span></label>
    <div class="password-wrapper">
        <input type="password" id="password" name="password" class="<?= $passwordErr ? 'error' : '' ?>" required>
        <span class="toggle-password" id="togglePassword">👁️</span>
    </div>
    <div id="passwordError" class="form-error"><?= $passwordErr; ?></div>

    <button type="submit">Sign In</button>
    <p class="text-center">
        Don't have an account? 
        <a href="index.php?page=SignUp">Register here</a>
    </p>
</form>
</div>
</div>
<script>
  // Password show/hide toggle
  document.getElementById('togglePassword').addEventListener('click', function () {
      var pwd = document.getElementById('password');
      if (pwd.type === "password") {
          pwd.type = "text";
          this.textContent = "🙈";
      } else {
          pwd.type = "password";
          this.textContent = "👁️";
      }
  });

  document.addEventListener("DOMContentLoaded", function () {
      const emailInput = document.getElementById('email');
      const passwordInput = document.getElementById('password');
      const emailError = document.getElementById('emailError');
      const passwordError = document.getElementById('passwordError');

      function validateEmail(email) {
          return /^[^\s@]+@[^\s@]+\.com$/.test(email.trim());
      }
      function validatePassword(password) {
          return password.trim().length >= 6;
      }

      emailInput.addEventListener('input', function () {
          if (emailInput.value === "") {
              emailError.textContent = "Email is required.";
              emailInput.classList.add('error');
          } else if (!validateEmail(emailInput.value)) {
              emailError.textContent = "Email must end with .com";
              emailInput.classList.add('error');
          } else {
              emailError.textContent = "";
              emailInput.classList.remove('error');
          }
      });

      passwordInput.addEventListener('input', function () {
          if (passwordInput.value === "") {
              passwordError.textContent = "Password is required.";
              passwordInput.classList.add('error');
          } else if (!validatePassword(passwordInput.value)) {
              passwordError.textContent = "Password must be at least 6 characters";
              passwordInput.classList.add('error');
          } else {
              passwordError.textContent = "";
              passwordInput.classList.remove('error');
          }
      });

      document.getElementById('loginForm').addEventListener('submit', function (e) {
          let valid = true;
          if (emailInput.value === "") {
              emailError.textContent = "Email is required.";
              emailInput.classList.add('error');
              valid = false;
          } else if (!validateEmail(emailInput.value)) {
              emailError.textContent = "Email must end with .com";
              emailInput.classList.add('error');
              valid = false;
          } else {
              emailInput.classList.remove('error');
          }
          if (passwordInput.value === "") {
              passwordError.textContent = "Password is required.";
              passwordInput.classList.add('error');
              valid = false;
          } else if (!validatePassword(passwordInput.value)) {
              passwordError.textContent = "Password must be at least 6 characters";
              passwordInput.classList.add('error');
              valid = false;
          } else {
              passwordInput.classList.remove('error');
          }
          if (!valid) e.preventDefault();
      });
  });
</script>
<script>
  setTimeout(function() {
    var alertBox = document.getElementById('timeoutAlert');
    if (alertBox) alertBox.style.display = 'none';
  }, 6000);
</script>

</body>
</html>
