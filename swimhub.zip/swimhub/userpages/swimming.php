<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SwimHub Classes</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles/styles.css">
  <style>
body {
  font-family: 'Poppins', sans-serif;
  margin: 0;
  padding: 0;
  background: linear-gradient(180deg, #e0f2fe 0%, #f0f9ff 100%);
  color: #084b6f;
  line-height: 1.7;
  overflow-x: hidden;
}

.container {
  max-width: 1180px;
  margin: 40px auto 0 auto;
  padding: 0 22px 45px 22px;
}

.banner {
  background: linear-gradient(90deg, #0ea5e9 0%, #38bdf8 100%);
  color: #fff;
  border-radius: 28px;
  padding: 38px 18px 28px 18px;
  margin-bottom: 35px;
  box-shadow: 0 6px 32px rgba(14,165,233,0.15);
  text-align: center;
  position: relative;
  overflow: hidden;
}
.banner:after {
  content: "";
  position: absolute;
  right: -60px;
  bottom: -45px;
  width: 180px;
  height: 180px;
  background: radial-gradient(circle, #e0f2fe 35%, transparent 80%);
  opacity: 0.3;
}
.banner h1 {
  font-family: 'Playfair Display', serif;
  font-size: 3.1rem;
  font-weight: bold;
  margin-bottom: 9px;
  text-shadow: 0 2px 18px rgba(8,47,73,0.12);
  letter-spacing: 0.02em;
}
.banner h2 {
  font-size: 1.45rem;
  font-family: 'Montserrat', sans-serif;
  color: #f3fafc;
  margin: 0;
  font-weight: 500;
  letter-spacing: 0.01em;
}

.features-row {
  display: flex;
  gap: 30px;
  margin-bottom: 44px;
}
.feature-card {
  flex: 1;
  background: linear-gradient(120deg, #fff 75%, #bae6fd 100%);
  border-radius: 18px;
  box-shadow: 0 4px 24px rgba(2,132,199,0.08);
  text-align: center;
  padding: 34px 20px 26px 20px;
  transition: transform 0.3s, box-shadow 0.3s;
  position: relative;
}
.feature-card:hover {
  transform: translateY(-8px) scale(1.035);
  box-shadow: 0 10px 35px rgba(14,165,233,0.15);
}
.feature-card img, .feature-card .icon {
  width: 80px;
  height: 80px;
  margin-bottom: 22px;
  border-radius: 18px;
  background: #e0f2fe;
  object-fit: cover;
  display: inline-block;
}
.feature-card .icon {
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 2.8rem;
  color: #0ea5e9;
  background: linear-gradient(90deg,#bae6fd 40%,#e0f2fe 100%);
}
.feature-card h3 {
  font-family: 'Montserrat', sans-serif;
  font-size: 1.24rem;
  font-weight: 700;
  color: #075985;
  margin: 0 0 6px 0;
  letter-spacing: 0.01em;
}
.feature-card p {
  color: #334155;
  font-size: 1.02rem;
}

.swimming-section {
  display: flex;
  flex-wrap: wrap;
  gap: 38px;
  margin: 60px 0 32px 0;
  align-items: stretch;
}
.swimming-section img {
  width: 55%;
  min-width: 310px;
  max-width: 480px;
  height: 410px;
  object-fit: cover;
  border-radius: 22px;
  box-shadow: 0 10px 28px rgba(2, 132, 199, 0.18);
  transition: transform 0.4s;
}
.swimming-section img:hover {
  transform: scale(1.025);
}
.swimming-section .details {
  background-color: #fff;
padding: 22px 24px 20px 24px;
  border-radius: 18px;
  box-shadow: 0 8px 26px rgba(2, 132, 199, 0.12);
  min-width: 300px;
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  margin: 0 auto;
}
.swimming-section .details h2 {
  font-family: 'Playfair Display', serif;
  font-size: 2.2rem;
  color: #075985;
  margin-bottom: 16px;
  font-weight: 700;
  text-align: left;
}
.swimming-section .details p {
  margin-bottom: 16px;
  color: #334155;
  font-size: 1.08rem;
  text-align: left;
}
.swimming-section .details ul {
  margin: 6px 0 16px 0;
  padding-left: 19px;
  color: #0c4a6e;
  font-size: 1.01rem;
}

.swimming-section .details ul li {
  margin-bottom: 7px;
}
.swimming-section .details button {
  background: linear-gradient(90deg, #0284c7 0%, #0ea5e9 100%);
  color: #fff;
  border: none;
  padding: 15px 36px;
  border-radius: 50px;
  cursor: pointer;
  transition: all 0.3s;
  font-weight: 700;
  font-size: 1.09rem;
  letter-spacing: 0.5px;
  box-shadow: 0 4px 16px rgba(2,132,199,0.18);
  margin-top: 10px;
}
.swimming-section .details button:hover {
  background: linear-gradient(90deg, #0369a1 0%, #0284c7 100%);
  transform: translateY(-1.5px) scale(1.04);
  box-shadow: 0 8px 26px rgba(2,132,199,0.22);
}
@media (max-width: 950px) {
  .container {
    padding: 0 7px;
  }
  .swimming-section {
    flex-direction: column;
    align-items: center;
  }
  .swimming-section img, .swimming-section .details {
    width: 100%;
    max-width: 600px;
  }
}
@media (max-width: 650px) {
  .banner h1 { font-size: 2.2rem; }
  .banner { padding: 22px 7px 20px 7px; border-radius: 16px; }
  .features-row { flex-direction: column; gap: 18px; }
  .feature-card { padding: 24px 10px 18px 10px; border-radius: 12px;}
  .swimming-section img { height: 230px; border-radius: 10px;}
  .swimming-section .details { padding: 18px 8px; border-radius: 11px;}
  .swimming-section .details h2 { font-size: 1.24rem;}
}
  </style>
</head>
<body>
<div class="container">
  <!-- Banner -->
  <div class="banner">
    <h1>🏊‍♂️ Swimming Classes at SwimHub 🏊‍♀️</h1>
    <h2>Inspiring confidence, skill, and fun for every age & ability</h2>
  </div>
  
  <!-- Features Highlights Row -->
  <div class="features-row">
    <div class="feature-card">
      <span class="icon">👨‍🏫</span>
      <h3>Certified, Friendly Coaches</h3>
      <p>Get guided by experienced, passionate instructors focused on safety and personal growth.</p>
    </div>
    <div class="feature-card">
      <span class="icon">📊</span>
      <h3>Simple Payment Management</h3>
      <p>Pay for your swimming packages securely online and track payment status easily.</p>
    </div>
    <div class="feature-card">
      <span class="icon">🫂</span>
      <h3>Supportive Swim Community</h3>
      <p>Join a welcoming community with small class sizes and ongoing encouragement from coaches and members.</p>
    </div>
  </div>
  
  <!-- Swimming Class Levels Section -->
  <section class="swimming-section">
    <img src="image/7.jpg" alt="Group Class">
    <div class="details">
      <h2>Class Levels & Schedules</h2>
      <p>We offer classes for <strong>beginners, intermediate, and advanced</strong> swimmers:</p>
      <ul>
        <li><b>Beginner:</b> Water confidence, basic floating, front and backstroke</li>
        <li><b>Intermediate:</b> Freestyle, breaststroke, and endurance training</li>
        <li><b>Advanced:</b> Stroke refinement, butterfly, dives, and race preparation</li>
      </ul>
      <p>All classes are conducted in small groups for focused instruction. Sessions are available on weekdays and weekends to fit your busy schedule.</p>
      <button onclick="window.location.href='http://localhost/swinhub/index.php?page=SignUp'">Book Your First Class</button>
    </div>
  </section>

</div>
</body>
</html>
