<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Policy | SwimHub</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles/styles.css"> 
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      margin: 0;
      padding: 0;
      background: linear-gradient(180deg, #e0f2fe 0%, #f0f9ff 100%);
      color: #084b6f;
      line-height: 1.7;
      overflow-x: hidden;
    }
    .container {
      max-width: 900px;
      margin: 48px auto 32px auto;
      background: #fff;
      padding: 38px 34px 28px 34px;
      border-radius: 22px;
      box-shadow: 0 10px 32px rgba(2, 132, 199, 0.11);
    }
    h1 {
      font-family: 'Playfair Display', serif;
      color: #075985;
      font-size: 2.6rem;
      text-align: center;
      margin-bottom: 15px;
      font-weight: 700;
      letter-spacing: 0.02em;
    }
    h2 {
      font-family: 'Montserrat', sans-serif;
      color: #0284c7;
      font-size: 1.22rem;
      margin: 35px 0 15px 0;
      font-weight: 700;
      letter-spacing: 0.5px;
      border-left: 3px solid #bae6fd;
      padding-left: 12px;
    }
    ul.policy-list {
      margin-bottom: 20px;
      padding-left: 23px;
    }
    .policy-list li {
      margin-bottom: 9px;
      font-size: 1.09rem;
      color: #1e293b;
    }
    p, ul, ol {
      font-size: 1.04rem;
      color: #334155;
    }
    .note {
      background: #e0f2fe;
      padding: 16px 18px;
      border-radius: 10px;
      margin: 28px 0 10px 0;
      color: #0369a1;
      font-weight: 500;
      border-left: 4px solid #0284c7;
      box-shadow: 0 3px 18px rgba(14,165,233,0.06);
    }
    @media (max-width: 650px) {
      .container {
        padding: 12px 4px;
        border-radius: 13px;
      }
      h1 { font-size: 1.45rem;}
      h2 { font-size: 1rem; padding-left: 7px;}
    }
  </style>
</head>
<body>
<div class="container">
  <h1>SwimHub Policies</h1>
  <p>Welcome to SwimHub! Please review these policies to ensure a safe and positive swimming experience for everyone. By registering and booking through SwimHub, you agree to follow the rules below:</p>

  <h2>Registration & Membership</h2>
  <ul class="policy-list">
    <li>All users must register through SwimHub before joining any class.</li>
    <li>Provide accurate personal details (name, age, contact, medical info) for your safety.</li>
    <li>Membership is valid for the registered user only and cannot be transferred.</li>
    <li>All payments for packages or classes must be settled before attending.</li>
  </ul>

  <h2>Attendance & Class Booking</h2>
  <ul class="policy-list">
    <li>Classes must be booked in advance via the SwimHub system. Walk-in slots are not guaranteed.</li>
    <li>Cancellations or rescheduling must be done at least 24 hours before the scheduled class through your SwimHub account.</li>
    <li>No-shows or late cancellations may result in forfeited class credits.</li>
  </ul>

  <h2>Safety & Behaviour</h2>
  <ul class="policy-list">
    <li>Follow all pool safety rules and SwimHub staff instructions.</li>
    <li>Proper swimwear is required. Cotton or street clothes are not allowed in the pool.</li>
    <li>Children under 12 must be supervised by an adult.</li>
    <li>No running or horseplay in or around the pool area.</li>
    <li>Report any accidents, injuries, or unsafe conditions to SwimHub staff immediately.</li>
  </ul>

  <h2>Health & Hygiene</h2>
  <ul class="policy-list">
    <li>Shower before entering the pool to keep the water clean for all users.</li>
    <li>Do not swim if you feel unwell, have open wounds, or any contagious condition.</li>
    <li>No food or drinks in the pool area (water bottles are allowed).</li>
  </ul>

  <h2>Privacy & Data Protection</h2>
  <ul class="policy-list">
    <li>Your data is kept secure and used only for registration, communication, and safety purposes within SwimHub.</li>
    <li>We do not share your information except as required by law or for member safety.</li>
    <li>All online payments are processed securely.</li>
  </ul>

  <h2>Refund & Cancellation</h2>
  <ul class="policy-list">
    <li>Refunds are provided only if a class is cancelled by SwimHub or with a valid medical certificate.</li>
    <li>Unused classes expire at the end of your package period and do not carry forward.</li>
    <li>For refund requests, contact SwimHub support via your account or at the front desk.</li>
  </ul>

  <div class="note">
    <strong>Note:</strong> Policies may change from time to time. Please check this page regularly for updates.
  </div>
</div>
</body>
</html>
