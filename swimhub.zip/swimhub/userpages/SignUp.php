<?php
include 'db.php';
$firstName = $lastName = $email = $phone = $age = "";
$password = "";
$firstNameErr = $lastNameErr = $emailErr = $phoneErr = $ageErr = $passwordErr = $swimLevelErr = "";

// Default for swim level to prevent undefined
$swimLevel = isset($_POST['swimlevel']) ? $_POST['swimlevel'] : '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validate First Name
    if (empty($_POST["firstname"])) {
        $firstNameErr = "First name is required";
    } else {
        $firstName = trim($_POST["firstname"]);
        if (!preg_match("/^[A-Za-z\s]+$/", $firstName)) {
            $firstNameErr = "Only letters and spaces allowed.";
        }
    }

    // Validate Last Name
    if (empty($_POST["lastname"])) {
        $lastNameErr = "Last name is required";
    } else {
        $lastName = trim($_POST["lastname"]);
        if (!preg_match("/^[A-Za-z\s]+$/", $lastName)) {
            $lastNameErr = "Only letters and spaces allowed.";
        }
    }

    // Validate Email
    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
    } else {
        $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Invalid email format";
        } elseif (substr($email, -4) !== ".com") {
            $emailErr = "Email must end with .com";
        } else {
            $sql = "SELECT * FROM users WHERE email = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                $emailErr = "This email is already registered.";
            }
            $stmt->close();
        }
    }

    // Validate Phone Number
    if (empty($_POST["phone"])) {
        $phoneErr = "Phone number is required";
    } else {
        $phone = trim($_POST["phone"]);
        if (!preg_match("/^0\d{9,10}$/", $phone)) {
            $phoneErr = "Must start with 0 and be 10 or 11 digits.";
        }
    }

    // Validate Age
    if (empty($_POST["age"])) {
        $ageErr = "Age is required";
    } else {
        $age = intval($_POST["age"]);
        if ($age < 1 || $age > 90) {
            $ageErr = "Age must be between 1 and 90.";
        }
    }

    // Validate Swimming Level
    if (empty($_POST["swimlevel"])) {
        $swimLevelErr = "Swimming level is required";
    } else {
        $swimLevel = $_POST["swimlevel"];
        if (!in_array($swimLevel, ["Beginner", "Intermediate", "Advanced"])) {
            $swimLevelErr = "Please select a valid swimming level";
        }
    }

    // Validate Password
    if (empty($_POST["password"])) {
        $passwordErr = "Password is required";
    } else {
        $password = trim($_POST["password"]);
        if (strlen($password) < 6) {
            $passwordErr = "Password must be at least 6 characters.";
        }
    }

    // If no errors, insert into database
    if (
        empty($firstNameErr) && empty($lastNameErr) &&
        empty($emailErr) && empty($phoneErr) &&
        empty($ageErr) && empty($passwordErr) && empty($swimLevelErr)
    ) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO users (first_name, last_name, email, phoneno, age, swimming_level, password) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssiss", $firstName, $lastName, $email, $phone, $age, $swimLevel, $hashedPassword);

        if ($stmt->execute()) {
            $_SESSION['success'] = "Registration successful! Please log in.";
            header("Location: index.php?page=Login");
            exit();
        } else {
            echo "<script>alert('Error: Could not register user.');</script>";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up | SwimHub</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
:root {
  --primary: #0284c7;
  --primary-dark: #075985;
  --accent: #06b6d4;
  --error: #ef4444;
  --success: #10b981;
  --text: #1e293b;
  --text-light: #64748b;
  --background: #f0f9ff;
}
.signup-container {
  width: 100%;
  max-width: 700px;
  margin: 60px auto 0 auto;
  background: rgba(255,255,255,0.98);
  padding: 40px 38px 32px 38px;
  border-radius: 18px;
  box-shadow: 0 10px 32px rgba(2, 132, 199, 0.15);
  border: 1px solid #e0f2fe;
  display: flex;
  flex-direction: column;
  align-items: center;
  position: relative;
  overflow: hidden;
  margin-bottom: 54px;
}
.signup-container::before {
  content: '';
  position: absolute;
  top: 0; left: 0; width: 100%; height: 8px;
  background: linear-gradient(90deg, var(--primary) 0%, var(--accent) 100%);
}
.signup-container .logo-header {
  text-align: center;
  margin-bottom: 25px;
}
.signup-container .logo {
  width: 80px;
  height: 80px;
  margin: 0 auto 10px auto;
  display: block;
}
.signup-container .academy-name {
  font-family: 'Montserrat', sans-serif;
  font-weight: 700;
  font-size: 1.6rem;
  color: #075985;
  margin: 10px 0 0 0;
}
.signup-container .academy-subtitle {
  font-family: 'Poppins', sans-serif;
  font-size: 1rem;
  color: #64748b;
  margin-top: 5px;
  margin-bottom: 10px;
}
.signup-container form label {
  font-weight: 600;
  color: #1e293b;
  font-size: 1rem;
  display: block;
}
.required-star {
  color: #ef4444;
  font-weight: 700;
  margin-left: 3px;
  font-size: 1.1em;
}
.signup-container input[type="text"],
.signup-container input[type="email"],
.signup-container input[type="number"],
.signup-container input[type="password"],
.signup-container select {
  width: 100%;
  padding: 14px 14px;
  border: 2px solid #e2e8f0;
  border-radius: 8px;
  font-size: 1rem;
  margin-bottom: 5px;
  background-color: #f8fafc;
  transition: border 0.2s, box-shadow 0.2s;
}
.signup-container input:focus,
.signup-container select:focus {
  border-color: #0284c7;
  outline: none;
  box-shadow: 0 0 0 3px rgba(2,132,199,0.13);
  background: #fff;
}
.signup-container .input-wrapper {
  position: relative;
  margin-top: 8px;
}
.signup-container .toggle-password {
  position: absolute;
  right: 16px;
  top: 14px;
  cursor: pointer;
  user-select: none;
  color: var(--text-light);
  font-size: 1.1rem;
  transition: color 0.2s ease;
}
.signup-container .toggle-password:hover {
  color: var(--primary);
}
.signup-container .error {
  color: var(--error);
  font-size: 0.85rem;
  margin-top: 5px;
  display: block;
  min-height: 20px;
}
.signup-container .password-strength {
  margin-top: 8px;
  font-size: 0.85rem;
  display: flex;
  align-items: center;
  gap: 5px;
}
.signup-container .strength-meter {
  height: 4px;
  border-radius: 2px;
  background: #e2e8f0;
  flex-grow: 1;
  overflow: hidden;
}
.signup-container .strength-meter-fill {
  height: 100%;
  width: 0%;
  transition: width 0.3s ease, background 0.3s ease;
}
.signup-container .weak { color: var(--error); background: var(--error);}
.signup-container .medium { color: #f59e0b; background: #f59e0b;}
.signup-container .strong { color: var(--success); background: var(--success);}
.signup-container button {
  margin-top: 30px;
  width: 100%;
  padding: 16px;
  background: linear-gradient(90deg, var(--primary) 0%, var(--accent) 100%);
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 12px rgba(2, 132, 199, 0.2);
}
.signup-container button:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 16px rgba(2, 132, 199, 0.3);
}
.signup-container .login-link {
  text-align: center;
  margin-top: 25px;
  color: var(--text-light);
}
.signup-container .login-link a {
  color: var(--primary);
  text-decoration: none;
  font-weight: 600;
  transition: color 0.2s ease;
}
.signup-container .login-link a:hover {
  color: var(--primary-dark);
  text-decoration: underline;
}
@media (max-width: 480px) {
  .signup-container {
    padding: 24px 8px 18px 8px;
    margin: 30px 6px 0 6px;
  }
  .signup-container .logo { width: 60px; height: 60px; }
  .signup-container .academy-name { font-size: 1.2rem; }
}
.signup-form-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1px 10px;
  width: 100%;
  max-width: 600px;
  margin: 0 auto;
}
.signup-form-full {
  grid-column: 1 / -1;
}
.signup-form-grid input,
.signup-form-grid select {
  width: 100%;
  box-sizing: border-box;
}
@media (max-width: 700px) {
  .signup-form-grid {
    grid-template-columns: 1fr;
    gap: 18px;
    max-width: 98%;
  }
}
</style>
</head>
<body>
<div class="signup-container">
    <div class="logo-header">
        <img src="image/logo.png" alt="SwimHub Logo" class="logo">
        <h1 class="academy-name">SwimHub</h1>
        <p class="academy-subtitle">Swimming Academy</p>
    </div>
   <form id="signupForm" method="post" action="index.php?page=SignUp" class="signup-form-grid" autocomplete="off">
      <div>
        <label for="firstname">First Name <span class="required-star">*</span></label>
        <input type="text" id="firstname" name="firstname" value="<?= htmlspecialchars($firstName); ?>"  required>
        <span class="error" id="firstnameError"><?= $firstNameErr; ?></span>
      </div>
      <div>
        <label for="lastname">Last Name <span class="required-star">*</span></label>
        <input type="text" id="lastname" name="lastname" value="<?= htmlspecialchars($lastName); ?>"  required>
        <span class="error" id="lastnameError"><?= $lastNameErr; ?></span>
      </div>
      <div>
        <label for="email">Email <span class="required-star">*</span></label>
        <input type="email" id="email" name="email" value="<?= htmlspecialchars($email); ?>" placeholder="yourname@example.com" required>
        <span class="error" id="emailError"><?= $emailErr; ?></span>
      </div>
      <div>
        <label for="phone">Phone Number <span class="required-star">*</span></label>
        <input type="text" id="phone" name="phone" value="<?= htmlspecialchars($phone); ?>" placeholder="01********" required>
        <span class="error" id="phoneError"><?= $phoneErr; ?></span>
      </div>
      <div>
        <label for="age">Age <span class="required-star">*</span></label>
        <input type="number" id="age" name="age" value="<?= htmlspecialchars($age); ?>"  min="1" max="90" required>
        <span class="error" id="ageError"><?= $ageErr; ?></span>
      </div>
      <div>
        <label for="swimlevel">Swimming Level <span class="required-star">*</span></label>
        <select name="swimlevel" id="swimlevel" required>
            <option value="" disabled selected hidden>Select swimming level</option>
            <option value="Beginner" <?= $swimLevel == "Beginner" ? "selected" : "" ?>>Beginner</option>
            <option value="Intermediate" <?= $swimLevel == "Intermediate" ? "selected" : "" ?>>Intermediate</option>
            <option value="Advanced" <?= $swimLevel == "Advanced" ? "selected" : "" ?>>Advanced</option>
        </select>
        <span class="error" id="swimlevelError"><?= $swimLevelErr; ?></span>
      </div>
      <div class="signup-form-full">
        <label for="password">Password <span class="required-star">*</span></label>
        <div class="input-wrapper">
          <input type="password" id="password" name="password" placeholder="At least 6 characters" required>
          <span class="toggle-password" id="togglePassword">👁️</span>
        </div>
        <div class="password-strength">
          <span>Strength:</span>
          <span id="strengthText">None</span>
          <div class="strength-meter">
            <div class="strength-meter-fill" id="strengthMeter"></div>
          </div>
        </div>
        <span class="error" id="passwordError"><?= $passwordErr; ?></span>
      </div>
      <div class="signup-form-full">
        <button type="submit">Create Account</button>
        <p class="login-link">
          Already have an account? <a href="index.php?page=Login">Log In</a>
        </p>
      </div>
    </form>
</div>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const fields = {
        firstname: {
            el: document.getElementById('firstname'),
            errorEl: document.getElementById('firstnameError'),
            validate: (val) => /^[A-Za-z\s]+$/.test(val.trim())
        },
        lastname: {
            el: document.getElementById('lastname'),
            errorEl: document.getElementById('lastnameError'),
            validate: (val) => /^[A-Za-z\s]+$/.test(val.trim())
        },
        email: {
            el: document.getElementById('email'),
            errorEl: document.getElementById('emailError'),
            validate: (val) => /^[^\s@]+@[^\s@]+\.com$/.test(val.trim())
        },
        phone: {
            el: document.getElementById('phone'),
            errorEl: document.getElementById('phoneError'),
            validate: (val) => /^0\d{9,10}$/.test(val.replace(/\D/g, ""))
        },
        age: {
            el: document.getElementById('age'),
            errorEl: document.getElementById('ageError'),
            validate: (val) => {
                const num = parseInt(val);
                return !isNaN(num) && num > 0 && num <= 90;
            }
        },
        swimlevel: {
            el: document.getElementById('swimlevel'),
            errorEl: document.getElementById('swimlevelError'),
            validate: (val) => ["Beginner", "Intermediate", "Advanced"].includes(val)
        },
        password: {
            el: document.getElementById('password'),
            errorEl: document.getElementById('passwordError'),
            strengthText: document.getElementById('strengthText'),
            strengthMeter: document.getElementById('strengthMeter')
        }
    };

    // Real-time validation for all fields except password
    Object.keys(fields).forEach(key => {
        if (key === 'password') return;
        const field = fields[key];
        const eventType = key === 'swimlevel' ? 'change' : 'input';
        field.el.addEventListener(eventType, () => {
            let val = field.el.value;
            if (key === 'swimlevel') {
                val = field.el.options[field.el.selectedIndex].value;
            }
            const isValid = field.validate(val);
            field.errorEl.textContent = isValid || val.length === 0 ? '' : getErrorMessage(key);
        });
    });

    // Password strength indicator and validation
    fields.password.el.addEventListener('input', () => {
        const val = fields.password.el.value;
        let strength = 0;
        let strengthClass = '';
        let strengthLabel = 'None';
        if (val.length > 0) {
            strength = 1;
            strengthLabel = 'Weak';
            strengthClass = 'weak';
            if (val.length >= 6) {
                strength = 2;
                strengthLabel = 'Medium';
                strengthClass = 'medium';
            }
            if (val.length >= 8 && /[A-Z]/.test(val) && /[0-9]/.test(val)) {
                strength = 3;
                strengthLabel = 'Strong';
                strengthClass = 'strong';
            }
        }
        fields.password.strengthText.textContent = strengthLabel;
        fields.password.strengthText.className = strengthClass;
        fields.password.strengthMeter.className = 'strength-meter-fill ' + strengthClass;
        fields.password.strengthMeter.style.width = (strength/3)*100 + '%';

        // live error
        if (val.length > 0 && val.length < 6) {
            fields.password.errorEl.textContent = 'Password must be at least 6 characters';
        } else {
            fields.password.errorEl.textContent = '';
        }
    });

  // Password show/hide toggle
  document.getElementById('togglePassword').addEventListener('click', function () {
      var pwd = document.getElementById('password');
      if (pwd.type === "password") {
          pwd.type = "text";
          this.textContent = "🙈";
      } else {
          pwd.type = "password";
          this.textContent = "👁️";
      }
  });

    // Form submission validation
    document.getElementById('signupForm').addEventListener('submit', function (e) {
        let isValid = true;
        Object.keys(fields).forEach(key => {
            const field = fields[key];
            let val = field.el.value;
            if (key === 'swimlevel') {
                val = field.el.options[field.el.selectedIndex].value;
            }
            if (key === 'password') {
                if (val.length < 6) {
                    field.errorEl.textContent = 'Password must be at least 6 characters';
                    isValid = false;
                }
            } else {
                if (val.trim() === '' || (key === 'swimlevel' && val === '')) {
                    field.errorEl.textContent = getEmptyMessage(key);
                    isValid = false;
                } else if (!field.validate(val)) {
                    field.errorEl.textContent = getErrorMessage(key);
                    isValid = false;
                }
            }
        });
        if (!isValid) e.preventDefault();
    });

    function getErrorMessage(key) {
        switch (key) {
            case 'firstname':
            case 'lastname':
                return 'Only letters and spaces allowed';
            case 'email':
                return 'Must be a valid .com email';
            case 'phone':
                return 'Must start with 0 and be 10-11 digits';
            case 'age':
                return 'Must be between 1-90';
            case 'swimlevel':
                return 'Swimming level is required';
            default:
                return 'Invalid input';
        }
    }
    function getEmptyMessage(key) {
        switch (key) {
            case 'firstname': return 'First name is required';
            case 'lastname': return 'Last name is required';
            case 'email': return 'Email is required';
            case 'phone': return 'Phone number is required';
            case 'age': return 'Age is required';
            case 'swimlevel': return 'Swimming level is required';
            case 'password': return 'Password is required';
            default: return 'This field is required';
        }
    }
});
</script>
</body>
</html>