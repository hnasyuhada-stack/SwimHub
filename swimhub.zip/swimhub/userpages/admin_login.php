<?php
require_once __DIR__ . '/../db.php';


$email = $password = "";
$emailErr = $passwordErr = "";
$loginErr = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $password = trim($_POST["password"]);

    // Validate email
    if (empty($email)) {
        $emailErr = "Email is required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $emailErr = "Invalid email format.";
    } elseif (!str_ends_with($email, ".com")) {
        $emailErr = "Email must end with .com";
    }

    // Validate password
    if (empty($password)) {
        $passwordErr = "Password is required.";
    }

    // Check admin login with database
    if (empty($emailErr) && empty($passwordErr)) {
        $stmt = $conn->prepare("SELECT * FROM admin WHERE admin_email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $admin = $result->fetch_assoc();
            if (password_verify($password, $admin['admin_password'])) {
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_email'] = $admin['admin_email'];
                $_SESSION['admin_id'] = $admin['admin_id'];
                header("Location: admin/admin_dashboard.php");
                exit();
            } else {
                $loginErr = "Invalid password.";
            }
        } else {
            $loginErr = "Admin account not found or not authorised.";
        }
        $stmt->close();
    }
}
?>

<?php if (isset($_GET['timeout'])): ?>
  <div class="timeout-alert" id="timeoutAlert">
    <span class="timeout-icon">⏰</span>
    <span>Session expired due to inactivity. Please login again.</span>
    <button type="button" class="close-btn" onclick="document.getElementById('timeoutAlert').style.display='none';">&times;</button>
  </div>
<?php endif; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login | SwimHub</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <style>
:root {
  --primary: #0284c7;
  --primary-dark: #075985;
  --primary-light: #e0f2fe;
  --accent: #06b6d4;
  --error: #ef4444;
  --success: #10b981;
  --text: #1e293b;
  --text-light: #64748b;
  --background: #f0f9ff;
}
body {
  background: linear-gradient(180deg, #e0f2fe 0%, #e0f2fe 100%);
  font-family: 'Poppins', sans-serif;
}
.authorised-notice {
  width: 80%;
  margin: 0 auto 18px auto;
  background: linear-gradient(90deg, #ffeaea 0%, #fff 100%);
  color: #c92a2a;
  font-weight: 700;
  font-size: 12px;
  border-radius: 13px;
  box-shadow: 0 2px 14px rgba(239,68,68,0.10);
  padding: 13px 20px;
  text-align: left;
  display: flex;
  align-items: center;
  gap: 13px;
  border: 1.5px solid #ffc9c9;
  letter-spacing: 0.01em;
}
.notice-icon {
  font-size: 1.35em;
  margin-right: 5px;
}
/* --- Login Container Card --- */
.login-container {
  width: 100%;
  margin-top: 0;
  max-width: 420px;
  background: rgba(255,255,255,0.98);
  padding: 40px 38px 32px 38px;
  border-radius: 18px;
  box-shadow: 0 10px 32px rgba(2, 132, 199, 0.15);
  border: 1px solid #e0f2fe;
  display: flex;
  flex-direction: column;
  align-items: center;
  position: relative;
  overflow: hidden;
}
.login-container::before {
  content: '';
  position: absolute;
  top: 0; left: 0; width: 100%; height: 8px;
  background: linear-gradient(90deg, var(--primary) 0%, var(--accent) 100%);
}
.login-container .logo-header {
  text-align: center;
  margin-bottom: 12px;
}
.login-container .logo {
  width: 70px; height: 70px;
  margin: 0 auto 10px auto;
  display: block;
}
.login-container .academy-name {
  font-family: 'Montserrat', sans-serif;
  font-weight: 700;
  font-size: 1.5rem;
  color: #075985;
  margin: 10px 0 0 0;
  letter-spacing: 0.01em;
}
.login-container .academy-subtitle {
  font-family: 'Poppins', sans-serif;
  font-size: 1rem;
  color: #64748b;
  margin-top: 5px;
  margin-bottom: 10px;
  font-weight: 500;
}
form {
  width: 100%;
  margin-top: 6px;
}
.login-container label.form-label {
  font-family: 'Poppins', sans-serif;
  font-weight: 600;
  color: #1e293b;
  margin-top: 13px;
  margin-bottom: 6px;
  font-size: 1.04rem;
  display: block;
  text-align: left;
}
.login-container .required {
  color: #ef4444;
  font-weight: 700;
  margin-left: 3px;
}
.input-wrapper {
    position: relative;
    width: 100%;
}
.input-field {
    width: 100%;
    padding: 14px 44px 14px 14px; /* right padding for icon space */
    border: 2px solid #e2e8f0;
    border-radius: 8px;
    font-size: 1rem;
    background-color: #f8fafc;
    margin-bottom: 6px;
    transition: border 0.2s, box-shadow 0.2s;
    display: block;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}
.input-field:focus {
    border-color: #0284c7;
    outline: none;
    box-shadow: 0 0 0 3px rgba(2,132,199,0.13);
    background: #fff;
}
.input-field.error {
    border-color: #ef4444;
    background: #fff0f0;
}
.form-error {
    color: #ef4444;
    font-size: 0.99em;
    margin-bottom: 3px;
    margin-top: -4px;
    margin-left: 1px;
    text-align: left;
    font-weight: 500;
    letter-spacing: 0.01em;
}
.password-wrapper {
    position: relative;
    width: 100%;
    display: flex;
    align-items: center;
}
.password-wrapper input[type="password"],
.password-wrapper input[type="text"] {
    width: 100%;
    padding: 14px 44px 14px 14px;
    font-size: 1.12rem;
    border: 1.3px solid #7dd3fc;
    border-radius: 10px;
    background: #f0f9ff;
    transition: border 0.18s;
    font-family: inherit;
    outline: none;
    box-sizing: border-box;
}
.toggle-password {
    position: absolute;
    right: 15px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    font-size: 1.3rem;
    color: #64748b;
    user-select: none;
    z-index: 10;
}
.login-container button[type="submit"] {
  width: 100%;
  margin-top: 22px;
  padding: 15px 0;
  background: linear-gradient(90deg,#0284c7 0%, #06b6d4 100%);
  color: #fff;
  border: none;
  border-radius: 8px;
  font-size: 1.1rem;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.2s;
  box-shadow: 0 4px 12px rgba(2,132,199,0.12);
  font-family: 'Poppins', sans-serif;
}
.login-container button[type="submit"]:hover {
  background: linear-gradient(90deg,#0369a1 0%, #0284c7 100%);
  transform: translateY(-1.5px);
  box-shadow: 0 8px 24px rgba(2,132,199,0.19);
}
.login-container .login-error {
  color: #ef4444;
  text-align: center;
  background: rgba(239,68,68,0.09);
  padding: 10px 0;
  border-radius: 8px;
  margin-bottom: 16px;
  font-size: 1rem;
}
@media (max-width: 480px) {
  .login-container {
    padding: 28px 9px 22px 9px;
    margin: 30px 6px 0 6px;
  }
  .login-container .logo { width: 50px; height: 50px; }
  .login-container .academy-name { font-size: 1rem; }
}
.timeout-alert {
  display: flex;
  align-items: center;
  background: linear-gradient(90deg, #fffbe6 60%, #ffe1e7 100%);
  border: 1.5px solid #fde68a;
  color: #b45309;
  font-weight: 600;
  font-size: 1.09rem;
  padding: 14px 22px;
  border-radius: 12px;
  margin-bottom: 18px;
  box-shadow: 0 4px 16px rgba(251,191,36,0.10);
  position: relative;
  animation: fadeInDown 0.4s;
}
.timeout-icon {
  font-size: 1.25em;
  margin-right: 14px;
}
.close-btn {
  background: transparent;
  border: none;
  color: #e11d48;
  font-size: 1.4em;
  font-weight: bold;
  cursor: pointer;
  margin-left: auto;
  transition: color 0.16s;
}
.close-btn:hover {
  color: #be123c;
}
@keyframes fadeInDown {
  from { opacity: 0; transform: translateY(-20px);}
  to { opacity: 1; transform: translateY(0);}
}

    </style>
</head>
<body>
<div style="margin: 80px 0; display: flex; justify-content: center; align-items: flex-start;">
  <div class="login-container">
    <div class="authorised-notice">
        <span class="notice-icon">🔒</span>
        <span><span style="font-weight:700;">Authorised Access Only</span> &ndash; Admins must log in</span>
    </div>
    <div class="logo-header">
      <img src="image/logo.png" alt="SwimHub Logo" class="logo">
      <div class="academy-name">Admin Login</div>
      <div class="academy-subtitle">Swimming Academy</div>
    </div>
    <?php if (!empty($loginErr)): ?>
        <div class="login-error"><?= $loginErr; ?></div>
    <?php endif; ?>
<form method="POST" action="" novalidate>
    <label class="form-label" for="email">
        Email
        <span class="required">*</span>
    </label>
    <div class="input-wrapper">
<input 
    type="email" 
    name="email" 
    id="email" 
    class="input-field<?= $emailErr ? ' error' : '' ?>"
    placeholder="yourname@example.com"
    value="<?= htmlspecialchars($email); ?>" 
    required
    pattern="^[^@]+@[^@]+\.com$"
    title="Email must be valid and end with .com"
/>

        <div id="emailFeedback" class="form-error" style="display:none"></div>
        <?php if ($emailErr): ?><div class="form-error"><?= $emailErr ?></div><?php endif; ?>
    </div>

    <label class="form-label" for="password">
        Password
        <span class="required">*</span>
    </label>
    <div class="input-wrapper password-wrapper">
        <input type="password" name="password" id="password" class="input-field<?= $passwordErr ? ' error' : '' ?>" required>
        <span class="toggle-password" id="togglePassword">👁️</span>
    </div>
    <?php if ($passwordErr): ?><div class="form-error"><?= $passwordErr ?></div><?php endif; ?>

    <button type="submit" class="login-btn">Sign In</button>
</form>
  </div>
</div>
<script>
    // Password show/hide toggle
    document.getElementById('togglePassword').addEventListener('click', function () {
        var pwd = document.getElementById('password');
        if (pwd.type === "password") {
            pwd.type = "text";
            this.textContent = "🙈";
        } else {
            pwd.type = "password";
            this.textContent = "👁️";
        }
    });

    // Email instant feedback
    const emailInput = document.getElementById('email');
    const emailFeedback = document.getElementById('emailFeedback');
    const pattern = /^[^@]+@[^@]+\.com$/;


    emailInput.addEventListener('input', function() {
        if (!emailInput.value) {
            emailFeedback.textContent = "Email is required.";
            emailFeedback.style.display = "block";
            emailInput.classList.add('error');
            emailInput.setCustomValidity("Email is required.");
        } else if (!pattern.test(emailInput.value)) {
            emailFeedback.textContent = "Email must be valid and end with .com";
            emailFeedback.style.display = "block";
            emailInput.classList.add('error');
            emailInput.setCustomValidity("Email must be valid and end with .com");
        } else {
            emailFeedback.textContent = "";
            emailFeedback.style.display = "none";
            emailInput.classList.remove('error');
            emailInput.setCustomValidity("");
        }
    });
</script>
<script>
  // (Add to your existing script, or create a new <script> block if you want)
  setTimeout(function() {
    var alertBox = document.getElementById('timeoutAlert');
    if (alertBox) alertBox.style.display = 'none';
  }, 6000); // 6 seconds
</script>

</body>
</html>
