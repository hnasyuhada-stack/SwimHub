<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>About Us | SwimHub</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles/styles.css">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      margin: 0;
      padding: 0;
      background: linear-gradient(180deg, #e0f2fe 0%, #f0f9ff 100%);
      color: #084b6f;
      line-height: 1.7;
      overflow-x: hidden;
    }

    .section {
      max-width: 1150px;
      margin: 48px auto 40px auto;
      background: #fff;
      padding: 40px 34px 36px 34px;
      border-radius: 22px;
      box-shadow: 0 10px 32px rgba(2, 132, 199, 0.11);
    }
    .section:not(:first-child) { margin-top: 38px; }
    .section h2 {
      font-family: 'Playfair Display', serif;
      font-size: 2.3rem;
      color: #075985;
      margin-bottom: 26px;
      font-weight: 700;
      text-align: center;
      letter-spacing: 0.01em;
      position: relative;
    }
    .section h2::after {
      content: '';
      display: block;
      width: 60px;
      height: 4px;
      background: linear-gradient(90deg, #0ea5e9 30%, #bae6fd 100%);
      margin: 15px auto 0;
      border-radius: 2px;
    }
    .section p {
      line-height: 1.8;
      max-width: 800px;
      margin: 0 auto 40px auto;
      text-align: center;
      font-size: 1.08rem;
      color: #334155;
    }
    .features {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(270px, 1fr));
      gap: 30px;
      margin-top: 40px;
    }
    .feature-card {
      background-color: #fff;
      padding: 28px 20px;
      border-radius: 14px;
      box-shadow: 0 5px 22px rgba(2,132,199,0.10);
      text-align: center;
      transition: transform 0.3s, box-shadow 0.3s;
      border-top: 4px solid #bae6fd;
    }
    .feature-card:hover {
      transform: translateY(-7px) scale(1.02);
      box-shadow: 0 10px 28px rgba(2, 132, 199, 0.14);
    }
    .feature-card h3 {
      margin-bottom: 14px;
      color: #0284c7;
      font-family: 'Montserrat', sans-serif;
      font-size: 1.28rem;
    }
    .feature-card p {
      font-size: 1.01rem;
      text-align: center;
      margin-bottom: 0;
      color: #334155;
    }
    .feature-icon {
      font-size: 2.3rem;
      color: #0ea5e9;
      margin-bottom: 12px;
    }

    .team-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(245px, 1fr));
      gap: 30px;
      margin-top: 40px;
    }
    .team-member {
      background-color: #fff;
      padding: 28px 20px;
      border-radius: 14px;
      box-shadow: 0 6px 18px rgba(2,132,199,0.10);
      text-align: center;
      transition: transform 0.3s;
    }
    .team-member:hover {
      transform: translateY(-5px) scale(1.01);
    }
    .team-member img {
      width: 110px;
      height: 110px;
      object-fit: cover;
      border-radius: 50%;
      margin-bottom: 17px;
      border: 4px solid #e0f2fe;
      box-shadow: 0 4px 12px rgba(2, 132, 199, 0.10);
    }
    .team-member h4 {
      margin: 13px 0 6px 0;
      font-family: 'Montserrat', sans-serif;
      font-size: 1.19rem;
      color: #075985;
    }
    .team-member .position {
      color: #0284c7;
      font-weight: 600;
      margin-bottom: 8px;
      font-size: 1.04rem;
      letter-spacing: 0.2px;
    }
    .team-member p {
      font-size: 0.97rem;
      color: #64748b;
      margin-bottom: 0;
    }
    .cta {
      text-align: center;
      margin: 48px auto 0 auto;
      max-width: 850px;
      background: linear-gradient(135deg, #e0f2fe 0%, #ffffff 100%);
      border-radius: 16px;
      padding: 44px 18px 38px 18px;
      box-shadow: 0 6px 24px rgba(2,132,199,0.10);
    }
    .cta h2 {
      font-size: 2.2rem;
      color: #075985;
      font-family: 'Playfair Display', serif;
      margin-bottom: 18px;
    }
    .cta p {
      font-size: 1.13rem;
      color: #334155;
      margin-bottom: 27px;
    }
    .cta a {
      display: inline-block;
      background: linear-gradient(90deg, #0284c7 10%, #0ea5e9 100%);
      color: white;
      padding: 14px 38px;
      text-decoration: none;
      border-radius: 50px;
      font-size: 1.06rem;
      font-weight: 600;
      transition: all 0.3s;
      box-shadow: 0 4px 16px rgba(2,132,199,0.18);
    }
    .cta a:hover {
      transform: translateY(-2px) scale(1.04);
      box-shadow: 0 8px 22px rgba(2,132,199,0.16);
    }
    @media (max-width: 950px) {
      .section { padding: 14px 5px 14px 5px; }
      .cta { padding: 28px 5px 22px 5px; }
      .features, .team-grid { gap: 17px; }
    }
    @media (max-width: 650px) {
      .section { border-radius: 13px; }
      .section h2, .cta h2 { font-size: 1.22rem;}
      .features, .team-grid { grid-template-columns: 1fr; }
      .feature-card, .team-member { padding: 15px 7px; border-radius: 9px;}
      .cta { border-radius: 10px; }
    }
  </style>
</head>
<body>
<main>
  <!-- Our Story -->
  <section class="section">
    <h2>Our Story</h2>
    <p>
      SwimHub was founded on the belief that everyone should feel safe and confident in the water.
      Whether you're taking your first dip or preparing for competition, our certified instructors are here to guide you every stroke of the way.
      We offer personalised swim lessons for all ages and skill levels,
      making swimming accessible, fun, and life-changing for all.
    </p>
  </section>

  <!-- Features / Mission & Values -->
  <section class="section">
    <h2>What Makes Us Unique?</h2>
    <div class="features">
      <div class="feature-card">
        <div class="feature-icon">🏊‍♂️</div>
        <h3>Experienced Coaches</h3>
        <p>All our instructors are certified professionals with years of experience teaching swimmers of all levels.</p>
      </div>
      <div class="feature-card">
        <div class="feature-icon">✨</div>
        <h3>Customised Programmes</h3>
        <p>We tailor each lesson to meet individual goals — from beginner safety to advanced technique training.</p>
      </div>
      <div class="feature-card">
        <div class="feature-icon">🛡️</div>
        <h3>Safety First</h3>
        <p>Your safety is our priority. Our lessons emphasise water confidence, emergency preparedness, and healthy habits.</p>
      </div>
    </div>
  </section>

  <!-- Team -->
  <section class="section">
    <h2>Meet Our Instructors</h2>
    <div class="team-grid">
      <div class="team-member">
        <img src="image/3.jpg" alt="Aqeel">
        <h4>Aqeel</h4>
        <p class="position">Head Swimming Coach</p>
        <p>10+ years of experience teaching all age groups</p>
      </div>
      <div class="team-member">
        <img src="image/2.jpg" alt="Hana">
        <h4>Hana</h4>
        <p class="position">Competitive Coach</p>
        <p>Specialises in stroke refinement and competition prep</p>
      </div>
      <div class="team-member">
        <img src="image/10.jpg" alt="Najwa">
        <h4>Najwa</h4>
        <p class="position">Children's Specialist</p>
        <p>Focuses on water safety and beginner development</p>
      </div>
    </div>
  </section>

  <!-- Call to Action -->
  <section class="cta">
    <h2>Ready to Dive In?</h2>
    <p>Join SwimHub today and start your swimming journey with trusted professionals.</p>
    <a href="http://localhost/swinhub/index.php?page=SignUp">Get Started Today</a>
  </section>
</main>
</body>
</html>
