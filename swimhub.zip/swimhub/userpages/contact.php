<?php
require_once 'db.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

$success = "";
$error = "";
$showSuccess = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? "");
    $email = trim($_POST['email'] ?? "");
    $message = trim($_POST['message'] ?? "");

    if (!$name || !$email || !$message) {
        $error = "Please fill in all required fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } else {
        $stmt = $conn->prepare("INSERT INTO contact_messages (name, email, message) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $message);

        if ($stmt->execute()) {
            $mail = new PHPMailer(true);
            try {
                $mail->SMTPDebug = 0;
                $mail->SMTPOptions = [
                    'ssl' => [
                        'verify_peer' => false,
                        'verify_peer_name' => false,
                        'allow_self_signed' => true
                    ]
                ];
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'aqeelzol27@gmail.com';
                $mail->Password = 'emqk sdqd ergw pimv';
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;

                // Fixed sender (must match Gmail login)
                $mail->setFrom('aqeelzol27@gmail.com', 'SwimHub Contact Form');

                // Recipient (your inbox)
                $mail->addAddress('aqeelzol27@gmail.com');

                // Reply-To (user's input)
                $mail->addReplyTo($email, $name);

                $mail->isHTML(true);
                $mail->Subject = "New Contact Form Submission from $name";
                $mail->Body = "
                    <h3>You received a new message from the contact form:</h3>
                    <p><strong>Name:</strong> {$name}</p>
                    <p><strong>Email:</strong> {$email}</p>
                    <p><strong>Message:</strong><br>{$message}</p>";
                $mail->AltBody = "Name: $name\nEmail: $email\nMessage:\n$message";

                $mail->send();
                $success = "Thank you for reaching out! Your message has been received and emailed.";
                $showSuccess = true;
            } catch (Exception $e) {
                $error = "Message saved, but email could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        } else {
            $error = "Failed to send your message. Please try again.";
        }
        $stmt->close();
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Contact Us - SwimHub</title>
  <link rel="icon" type="image/png" href="image/logo.png">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles/styles.css">
  <style>
/* Scope all to #contactPage */
#contactPage {
  background: linear-gradient(135deg, #e6f4ff 70%, #caf0ff 100%);
  font-family: 'Segoe UI', 'Arial', sans-serif;
  min-height: 100vh;
}
#contactPage .main-contact-container {
  max-width: 950px;
  margin: 60px auto 0 auto;
  background: rgba(255,255,255,0.94);
  border-radius: 24px;
  padding: 48px 44px 42px 44px;
  box-shadow: 0 6px 32px 0 #9bd8fc1a, 0 1px 8px #6ec2fc30;
  display: flex;
  gap: 48px;
  justify-content: space-between;
}
#contactPage .contact-form-section {
  flex: 2;
  min-width: 260px;
}

/* New: Vertical column for logo + contact details card */
#contactPage .right-contact-column {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  flex: 1;
  min-width: 220px;
  max-width: 320px;
}

/* Logo at the top right, above card */
#contactPage .logo-top-right {
  margin-bottom: 10px;
  margin-right: 3px;
  width: 54px;
  display: flex;
  justify-content: flex-end;
}
#contactPage .logo-top-right img {
  width: 54px;
  height: 54px;
  border-radius: 12px;
  background: #fff;
  object-fit: contain;
  box-shadow: 0 2px 8px #bde0fc40;
  border: 2px solid #fff;
}

/* --- COMPACT SUPER FANCY CONTACT CARD --- */
#contactPage .super-fancy-contact {
  background: linear-gradient(135deg, #e6f4ff 70%, #bff0ff 100%);
  border-radius: 18px;
  box-shadow: 0 2px 14px #b4e6ff33, 0 1px 5px #a0eaff1c;
  padding: 16px 12px 14px 12px;
  position: relative;
  min-width: 0;
  max-width: 220px;
  width: 100%;
  border: 1.6px solid #c0e7ff;
  backdrop-filter: blur(2px);
  margin: 0 auto;
}
#contactPage .contact-header {
  background: linear-gradient(90deg, #39c1f3 70%, #7be4f7 100%);
  color: #fff;
  font-weight: 800;
  font-size: 1.03rem;
  border-radius: 14px 14px 18px 18px;
  padding: 10px 7px 6px 7px;
  margin: -16px -12px 14px -12px;
  display: flex;
  align-items: center;
  justify-content: center;   /* Center text */
  min-height: 35px;
  position: relative;
  box-shadow: 0 1.5px 7px #a6e6ff29;
  text-align: center;
}
#contactPage .contact-header span {
  width: 100%;
  text-align: center;
  font-size: 1.09rem;
  font-weight: 800;
  letter-spacing: 0.01em;
}
#contactPage .detail-vertical {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  margin-bottom: 10px;
  font-size: 0.98em;
}
#contactPage .detail-icon-box {
  width: 22px;
  height: 22px;
  border-radius: 50%;
  background: linear-gradient(135deg, #fff 55%, #f1faff 100%);
  box-shadow: 0 1px 7px #a7eaff20;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 3px;
}
#contactPage .detail-label {
  font-weight: 700;
  color: #28a7d3;
  margin-bottom: 2px;
  margin-top: 1px;
  font-size: 0.99em;
  letter-spacing: .01em;
}
#contactPage .detail-info {
  color: #184a6a;
  font-size: 1.02em;
  margin-bottom: 0;
  word-break: break-word;
  line-height: 1.32;
}
/* --- END COMPACT CARD --- */

#contactPage .detail-mail svg { filter: drop-shadow(0 1px 1px #a1d9ff6e); }
#contactPage .detail-phone svg { filter: drop-shadow(0 1px 1px #ff90ca6e);}
#contactPage .detail-location svg { filter: drop-shadow(0 1px 1px #8ce9b86e);}
#contactPage .detail-clock svg { filter: drop-shadow(0 1px 1px #d3b6f96e); }

#contactPage a {
  color: #1768ab;
  text-decoration: underline;
  font-weight: 600;
  transition: color .13s;
}
#contactPage a:hover { color: #2ec1ee; }

#contactPage .hours-row .detail-label {
  min-width: 97px;
}

@media (max-width: 1050px) {
  #contactPage .main-contact-container { flex-direction: column; gap: 28px; padding: 32px 5vw; }
  #contactPage .contact-details { margin-left: 0; }
  #contactPage .right-contact-column { align-items: flex-start; margin: 0 auto;}
}
@media (max-width: 900px) {
  #contactPage .super-fancy-contact {
    margin: 32px auto 0 auto;
    max-width: 320px;
    width: 97vw;
    padding: 12px 5vw 13px 5vw;
  }
}
@media (max-width: 700px) {
  #contactPage .main-contact-container { padding: 16px 2vw 24px 2vw; }
  #contactPage .contact-form-section h2 { font-size: 1.39rem; }
  #contactPage .contact-details { padding: 18px 9px; font-size: .99em; }
  #contactPage .super-fancy-contact { max-width: 98vw; min-width: 0; padding: 10px 2vw 10px 2vw;}
  #contactPage .contact-header { font-size: 0.97rem; padding-left: 7px; }
}

#contactPage .contact-details strong {
  font-weight: 600;
  color: #1b4269;
}
#contactPage .contact-details .detail-label {
  font-weight: 600;
  color: #21598c;
  margin-top: 6px;
}
#contactPage .contact-form-section h2 {
  color: #214c7c;
  font-size: 2rem;
  margin-bottom: 16px;
  margin-top: 0;
  font-weight: 700;
}
#contactPage .contact-form-section p {
  font-size: 1.08rem;
  color: #356193;
  margin-bottom: 30px;
}
#contactPage .contact-form label {
  font-weight: 600;
  color: #2d567e;
  font-size: 1.08rem;
  display: block;
  margin-bottom: 7px;
  margin-top: 8px;
}
#contactPage .contact-form .required {
  color: #e53935;
  font-size: 1.08em;
  margin-left: 3px;
  font-weight: 700;
}
#contactPage .contact-form input[type="text"],
#contactPage .contact-form input[type="email"],
#contactPage .contact-form textarea {
  width: 100%;
  padding: 13px 15px;
  border: 1.4px solid #b2d7f5;
  border-radius: 9px;
  font-size: 1.06em;
  margin-bottom: 16px;
  box-sizing: border-box;
  outline: none;
  background: #fafdff;
  resize: none;
  transition: border .19s;
}
#contactPage .contact-form textarea {
  min-height: 90px;
  resize: vertical;
  max-height: 280px;
}
#contactPage .contact-form input:focus,
#contactPage .contact-form textarea:focus {
  border: 1.8px solid #27a2ee;
}
#contactPage .contact-form .submit-btn {
  background: linear-gradient(90deg, #15a6e0 70%, #1cc6e4 100%);
  color: #fff;
  font-weight: 700;
  border: none;
  border-radius: 8px;
  font-size: 1.11rem;
  padding: 13px 34px;
  box-shadow: 0 1px 8px #26b9ff22;
  cursor: pointer;
  transition: background .19s;
  margin-top: 10px;
  letter-spacing: .4px;
  display: inline-block;
}
#contactPage .contact-form .submit-btn:hover {
  background: linear-gradient(90deg, #1577b8 60%, #17b7d6 100%);
}
#contactPage .msg-success { background: #d4fbe8; color: #156f44; padding: 12px 18px; border-radius: 7px; margin-bottom: 19px;}
#contactPage .msg-error { background: #ffdede; color: #ae2525; padding: 12px 18px; border-radius: 7px; margin-bottom: 19px;}

  </style>
  </style>
</head>
<body>
<div id="contactPage">
  <div class="main-contact-container">
    <section class="contact-form-section">
      <h2>Contact Us</h2>
      <p>Have a question or need more information? Fill in the form and our team will get back to you soon!</p>

      <?php if ($success): ?>
        <div class="msg-success" id="successMsg"><?php echo htmlspecialchars($success); ?></div>
      <?php elseif ($error): ?>
        <div class="msg-error"><?php echo htmlspecialchars($error); ?></div>
      <?php endif; ?>

      <form class="contact-form" method="post" action="" id="contactForm" autocomplete="off">
        <div style="display:flex; gap:18px;">
          <div style="flex:1;">
            <label for="name">Your Name <span class="required">*</span></label>
            <input type="text" name="name" id="name" required maxlength="80" autocomplete="name" value="<?php echo ($success ? "" : htmlspecialchars($_POST['name'] ?? '')); ?>">
          </div>
          <div style="flex:1;">
            <label for="email">Email <span class="required">*</span></label>
            <input type="email" name="email" id="email" required maxlength="100" autocomplete="email" value="<?php echo ($success ? "" : htmlspecialchars($_POST['email'] ?? '')); ?>">
          </div>
        </div>
        <label for="message">Message <span class="required">*</span></label>
        <textarea name="message" id="message" required maxlength="700" placeholder="Type your message here..."><?php echo ($success ? "" : htmlspecialchars($_POST['message'] ?? '')); ?></textarea>
        <button class="submit-btn" type="submit">Send Message</button>
      </form>
    </section>

    <div class="right-contact-column">
      <aside class="contact-details super-fancy-contact">
        <div class="contact-header"><span>Contact Details</span></div>
        <div class="detail-vertical">
          <div class="detail-icon-box detail-mail">
            <svg width="22" height="22" viewBox="0 0 20 20"><circle cx="10" cy="10" r="10" fill="#e1e9ff"/><path d="M5 7h10a1 1 0 0 1 1 1v4a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm0 1v.217l5 3.1 5-3.1V8l-5 3.1L5 8.217z" fill="#2992fa"/></svg>
          </div>
          <div class="detail-label">Email:</div>
          <a class="detail-info" href="mailto:swimhub@gmail.com"><strong>swimhub@gmail.com</strong></a>
        </div>
        <div class="detail-vertical">
          <div class="detail-icon-box detail-phone">
            <svg width="22" height="22" viewBox="0 0 20 20"><circle cx="10" cy="10" r="10" fill="#fde7ee"/><path d="M13.5 12.5l-1-1c-.2-.2-.5-.2-.7 0l-.6.6a7.48 7.48 0 0 1-3.1-3.1l.6-.6c.2-.2.2-.5 0-.7l-1-1c-.2-.2-.5-.2-.7 0l-.7.7c-.2.2-.3.5-.3.8C6.1 11.4 8.6 13.9 11.5 14c.3 0 .6-.1.8-.3l.7-.7c.2-.2.2-.5 0-.7z" fill="#ea408b"/></svg>
          </div>
          <div class="detail-label">Phone:</div>
          <div class="detail-info"><strong>+60 12-345 6789</strong></div>
        </div>
        <div class="detail-vertical">
          <div class="detail-icon-box detail-location">
            <svg width="22" height="22" viewBox="0 0 20 20"><circle cx="10" cy="10" r="10" fill="#e5ffe5"/><path d="M10 4a4 4 0 0 0-4 4c0 3.3 4 8 4 8s4-4.7 4-8a4 4 0 0 0-4-4zm0 5.5A1.5 1.5 0 1 1 10 6a1.5 1.5 0 0 1 0 3z" fill="#3fd48b"/></svg>
          </div>
          <div class="detail-label">Location:</div>
          <div class="detail-info"><strong>UiTM Shah Alam,<br>Malaysia</strong></div>
        </div>
        <div class="detail-vertical">
          <div class="detail-icon-box detail-clock">
            <svg width="22" height="22" viewBox="0 0 20 20"><circle cx="10" cy="10" r="10" fill="#f9eaff"/><path d="M10 5.5a.75.75 0 0 1 .75.75V10h2.25a.75.75 0 1 1 0 1.5h-3A.75.75 0 0 1 9.25 10V6.25A.75.75 0 0 1 10 5.5z" fill="#9469fa"/></svg>
          </div>
          <div class="detail-label">Operating Hours:</div>
          <div class="detail-info">
            <strong>Mon–Fri:</strong> 9:00am – 6:00pm<br>
            <strong>Sat–Sun:</strong> 10:00am – 4:00pm
          </div>
        </div>
      </aside>
    </div>
  </div>
</div>

<script>
  document.addEventListener("DOMContentLoaded", function() {
    var successMsg = document.getElementById('successMsg');
    <?php if ($showSuccess): ?>
      setTimeout(function() {
        if (successMsg) successMsg.style.display = 'none';
      }, 4000);
    <?php endif; ?>
  });
</script>
</body>
</html>
