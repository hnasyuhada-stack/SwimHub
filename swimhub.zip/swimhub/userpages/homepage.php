<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SwimHub Homepage</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Montserrat:wght@400;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="styles/styles.css">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      margin: 0;
      padding: 0;
      background: linear-gradient(180deg, #f0f9ff 0%, #e0f2fe 100%);
      color: #0c4a6e;
      line-height: 1.6;
    }
    .container {
      max-width: 1200px;
      margin: 40px auto;
      padding: 0 25px;
    }

    /* Banner Section like swimming.php */
    .main-banner {
      width: 95%;
      background: linear-gradient(100deg, #12b6ed 0%, #21b3ea 80%, #6cd8fa 100%);
      border-radius: 40px;
      margin-bottom: 40px;
      margin-top: 20px;
      box-shadow: 0 6px 32px rgba(14,165,233,0.15);
      padding: 54px 32px 42px 32px;
      text-align: center;
      position: relative;
      overflow: hidden;
    }
    .banner-title {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 22px;
      font-size: 2.5rem;
      font-family: 'Playfair Display', serif;
      color: #fff;
      font-weight: bold;
      letter-spacing: 1px;
      margin-bottom: 16px;
      text-shadow: 0 2px 18px rgba(8,47,73,0.10);
    }
    .banner-title .emoji {
      font-size: 2.7rem;
      line-height: 1;
      vertical-align: middle;
    }
    .banner-text {
      font-size: 2.8rem;
      font-family: 'Playfair Display', serif;
      font-weight: 700;
      color: #fff;
    }
    .banner-subtitle {
      font-family: 'Poppins', sans-serif;
      font-size: 1.45rem;
      color: #f3fafc;
      font-weight: 400;
      letter-spacing: 0.01em;
      margin-top: 5px;
      margin-bottom: 0;
      text-shadow: 0 1px 7px rgba(8,47,73,0.12);
    }

    /* Benefits section */
    .benefits-section {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 30px;
      margin: 50px 0;
    }
    .benefit-card {
      background-color: #fff;
      border-radius: 24px;
      text-align: center;
      box-shadow: 0 8px 20px rgba(2, 132, 199, 0.15);
      overflow: hidden;
      transition: transform 0.4s, box-shadow 0.4s;
      position: relative;
      padding-bottom: 16px;
      cursor: pointer;
      border: none;
      outline: none;
    }
    .benefit-card:hover,
    .benefit-card:focus {
      transform: translateY(-8px) scale(1.025);
      box-shadow: 0 12px 25px rgba(2, 132, 199, 0.25);
    }
    .benefit-card img {
      width: 100%;
      height: 220px;
      object-fit: cover;
      filter: brightness(0.93);
      border-top-left-radius: 24px;
      border-top-right-radius: 24px;
    }
    .benefit-card h2 {
      font-family: 'Montserrat', sans-serif;
      font-weight: 700;
      font-size: 1.5rem;
      margin: 22px 0 0 0;
      color: #0284c7;
      background: none;
      padding: 0 20px;
      position: static;
      text-shadow: none;
    }

    /* Modal Styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 80;
      left: 0; top: 0; right: 0; bottom: 0;
      width: 100vw; height: 100vh;
      background: rgba(24, 145, 202, 0.20);
      justify-content: center;
      align-items: center;
      backdrop-filter: blur(2px);
    }
    .modal.active {
      display: flex;
      animation: fadeIn 0.2s;
    }
    @keyframes fadeIn {
      from { opacity: 0; }
      to   { opacity: 1; }
    }
    .modal-content {
      background: #fff;
      border-radius: 26px;
      padding: 40px 30px 32px 30px;
      box-shadow: 0 8px 32px rgba(14,165,233,0.14);
      max-width: 420px;
      width: 90vw;
      text-align: left;
      position: relative;
      animation: popIn 0.24s;
    }
    @keyframes popIn {
      0%   { transform: scale(0.90);}
      100% { transform: scale(1);}
    }
    .modal-content h3 {
      font-family: 'Montserrat', sans-serif;
      font-size: 1.46rem;
      color: #1588cc;
      font-weight: 700;
      margin-bottom: 20px;
      letter-spacing: 0.01em;
    }
    .modal-content ul, .modal-content p {
      color: #355e6b;
      font-size: 1.07rem;
      margin-bottom: 0;
    }
    .close-btn {
      position: absolute;
      top: 18px; right: 22px;
      background: #e0f2fe;
      color: #1976ad;
      border: none;
      font-size: 1.5rem;
      border-radius: 8px;
      cursor: pointer;
      padding: 3px 14px 4px 14px;
      transition: background 0.14s;
    }
    .close-btn:hover {
      background: #bae6fd;
      color: #0c4a6e;
    }

    /* Swimming classes section */
    .swimming-section {
      display: flex;
      gap: 30px;
      margin: 70px 0;
      align-items: center;
    }
    .swimming-section img {
      width: 55%;
      height: 350px;
      object-fit: cover;
      border-radius: 22px;
      box-shadow: 5px 5px 15px rgba(2, 132, 199, 0.2);
      transition: transform 0.4s;
    }
    .swimming-section img:hover {
      transform: scale(1.02);
    }
    .swimming-section .details {
      background-color: #fff;
      padding: 40px;
      border-radius: 18px;
      box-shadow: 0 8px 20px rgba(2, 132, 199, 0.13);
      width: 45%;
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }
    .swimming-section .details h2 {
      font-family: 'Playfair Display', serif;
      font-size: 2.2rem;
      color: #075985;
      margin-bottom: 18px;
      font-weight: 700;
      text-align: center;
    }
    .swimming-section .details p {
      margin-bottom: 28px;
      color: #334155;
      font-size: 1.1rem;
      text-align: center;
    }

    /* Reviews section */
    .reviews-section {
      margin: 80px 0;
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 30px;
    }
    .review-card {
      background-color: #fff;
      border-radius: 16px;
      padding: 30px;
      text-align: center;
      box-shadow: 0 8px 20px rgba(2, 132, 199, 0.1);
      transition: transform 0.3s;
    }
    .review-card:hover {
      transform: translateY(-8px);
    }
    .review-card img {
      width: 90px;
      height: 90px;
      border-radius: 50%;
      object-fit: cover;
      margin-bottom: 18px;
      border: 4px solid #bae6fd;
      box-shadow: 0 4px 10px rgba(2, 132, 199, 0.12);
    }
    .review-card .rating {
      color: #f59e0b;
      font-size: 1.5rem;
      margin: 14px 0;
      letter-spacing: 3px;
    }
    .review-card p {
      font-style: italic;
      color: #475569;
      position: relative;
    }
    .review-card p::before,
    .review-card p::after {
      content: '"';
      font-size: 1.3rem;
      color: #0ea5e9;
      opacity: 0.6;
    }

    @media (max-width: 850px) {
      .main-banner { padding: 32px 8px 28px 8px; border-radius: 22px;}
      .banner-title { font-size: 1.25rem; gap: 12px;}
      .banner-text { font-size: 1.35rem; }
      .banner-title .emoji { font-size: 1.5rem; }
      .banner-subtitle { font-size: 1.05rem;}
      .container { padding: 0 8px; }
      .benefits-section { grid-template-columns: 1fr; gap: 20px; }
      .reviews-section { grid-template-columns: 1fr; gap: 18px;}
      .swimming-section { flex-direction: column; gap: 20px; margin: 35px 0;}
      .swimming-section img, .swimming-section .details { width: 100%; }
      .swimming-section img { height: 200px;}
    }
    @media (max-width: 600px) {
      .main-banner { border-radius: 12px; }
      .swimming-section .details { padding: 18px 8px; border-radius: 11px;}
      .swimming-section .details h2 { font-size: 1.15rem;}
      .review-card { padding: 15px; }
      .benefit-card img { height: 140px; }
    }
  </style>
</head>
<body>
  <div class="container">
    <!-- Banner Section Styled Like Swimming.php -->
    <section class="main-banner">
      <div class="banner-title">
        <span class="emoji">🏊‍♂️</span>
        <span class="banner-text">Swimming Classes at SwimHub</span>
        <span class="emoji">🏊‍♀️</span>
      </div>
      <div class="banner-subtitle">
        Inspiring confidence, skill, and fun for every age &amp; ability
      </div>
    </section>

    <!-- Benefits Section with clickable popups -->
    <section class="benefits-section">
      <button class="benefit-card" id="benefitsCard" tabindex="0">
        <img src="image/1.jpeg" alt="Benefit Image">
        <h2>Key Benefits of Joining</h2>
      </button>
      <button class="benefit-card" id="whoCanJoinCard" tabindex="0">
        <img src="image/2.jpeg" alt="Benefit Image">
        <h2>Who Can Join?</h2>
      </button>
    </section>

    <!-- Key Benefits Modal -->
    <div class="modal" id="benefitsModal">
      <div class="modal-content">
        <button class="close-btn" onclick="closeModal('benefitsModal')">&times;</button>
        <h3>Key Benefits of Joining</h3>
        <ul>
          <li>Professional, certified instructors dedicated to every swimmer's progress.</li>
          <li>Small class sizes for personal attention and a supportive learning environment.</li>
          <li>Flexible schedules to fit your lifestyle – weekdays and weekends available.</li>
          <li>Safe, clean facilities and a fun, welcoming community.</li>
        </ul>
      </div>
    </div>
    <!-- Who Can Join Modal -->
    <div class="modal" id="whoCanJoinModal">
      <div class="modal-content">
        <button class="close-btn" onclick="closeModal('whoCanJoinModal')">&times;</button>
        <h3>Who Can Join?</h3>
        <ul>
          <li>Children (from age 4+), teens, adults, and seniors – all levels welcome!</li>
          <li>Absolute beginners to advanced swimmers and competitive athletes.</li>
          <li>Anyone who wants to learn to swim, improve technique, or build water confidence.</li>
          <li>Families and individuals looking for a healthy, skill-building activity.</li>
        </ul>
      </div>
    </div>

    <!-- Swimming Classes Section -->
    <section class="swimming-section">
      <img src="image/3.jpeg" alt="Swimming Class Image">
      <div class="details">
        <h2>Swimming Classes</h2>
        <p>Join our expert-led swimming classes designed for all skill levels. Whether you're just starting out or looking to refine your technique, our certified instructors will guide you every stroke of the way.</p>
      </div>
    </section>

    <!-- Reviews Section -->
    <section class="reviews-section">
      <div class="review-card">
        <img src="image/4.jpeg" alt="User Profile">
        <div class="rating">★★★★★</div>
        <p>The instructors are amazing! My kids learned so much in just a few weeks.</p>
      </div>
      <div class="review-card">
        <img src="image/5.jpeg" alt="User Profile">
        <div class="rating">★★★★☆</div>
        <p>Great facilities and professional staff. Highly recommend for adult beginners.</p>
      </div>
      <div class="review-card">
        <img src="image/6.jpeg" alt="User Profile">
        <div class="rating">★★★★★</div>
        <p>Transformed my swimming technique completely. Worth every penny!</p>
      </div>
    </section>
  </div>
  <script>
    // Modal functionality
    const benefitsCard = document.getElementById('benefitsCard');
    const whoCanJoinCard = document.getElementById('whoCanJoinCard');
    const benefitsModal = document.getElementById('benefitsModal');
    const whoCanJoinModal = document.getElementById('whoCanJoinModal');

    function openModal(modalId) {
      document.getElementById(modalId).classList.add('active');
    }
    function closeModal(modalId) {
      document.getElementById(modalId).classList.remove('active');
    }

    // Open modals on click
    benefitsCard.onclick = () => openModal('benefitsModal');
    whoCanJoinCard.onclick = () => openModal('whoCanJoinModal');

    // Optional: Close modal when clicking outside or pressing Esc
    document.querySelectorAll('.modal').forEach(modal => {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.remove('active');
      });
    });
    document.addEventListener('keydown', function(e) {
      if (e.key === "Escape") {
        benefitsModal.classList.remove('active');
        whoCanJoinModal.classList.remove('active');
      }
    });
  </script>
</body>
</html>
