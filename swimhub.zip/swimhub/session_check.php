<?php
include_once __DIR__ . '/db.php';

if (isset($_SESSION['admin_id'])) {
    $timeout_duration = 3600; // 3600 seconds = 1 hour
    $redirect_url = "/swinhub/index.php?page=admin_login&timeout=1";
} elseif (isset($_SESSION['user_id'])) {
    $timeout_duration = 3600; // 3600 seconds = 1 hour
    $redirect_url = "/swinhub/index.php?page=Login&timeout=1";
} else {
    header("Location: /swinhub/index.php?page=Login");
    exit();
}

if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset();
    session_destroy();
    header("Location: $redirect_url");
    exit();
}

$_SESSION['LAST_ACTIVITY'] = time();
?>
