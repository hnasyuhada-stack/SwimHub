<!-- public_header.php -->
<header>
  <div class="logo">
    <img src="image/logo.png" alt="Logo">
    <span>SwimHub</span>
  </div>
  <nav>
    <ul>
      <li><a href="homepage.php" class="<?php if(basename($_SERVER['PHP_SELF'])=='homepage.php'){echo 'active';} ?>">HOME</a></li>
      <li><a href="aboutus.php" class="<?php if(basename($_SERVER['PHP_SELF'])=='aboutus.php'){echo 'active';} ?>">ABOUT US</a></li>
      <li><a href="staff.php" class="<?php if(basename($_SERVER['PHP_SELF'])=='staff.php'){echo 'active';} ?>">STAFF</a></li>
      <li><a href="swimming.php" class="<?php if(basename($_SERVER['PHP_SELF'])=='swimming.php'){echo 'active';} ?>">SWIMMING</a></li>
      <li><a href="policy.php" class="<?php if(basename($_SERVER['PHP_SELF'])=='policy.php'){echo 'active';} ?>">POLICY</a></li>
      <li>
        <div class="user-icon">
          <a href="Login.php">
            <img src="image/user-icon.png" alt="User Icon">
          </a>
        </div>
      </li>
    </ul>
  </nav>
</header>
