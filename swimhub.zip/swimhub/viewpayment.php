<?php 
session_start();
include 'session_check.php';
include 'db.php';
$user_id = $_SESSION['user_id'] ?? null;

if (!$user_id) {
    header("Location: Login.php");
    exit();
}

// Show redirect message after payment actions
$message = "";
if (isset($_GET['msg'])) {
    if ($_GET['msg'] == "success") {
        $message = "<div id='payment-message' class='msg-success'>Payment successful! Your membership has been updated.</div>";
    } elseif ($_GET['msg'] == "failed") {
        $message = "<div id='payment-message' class='msg-error'>Payment failed! Please try again.</div>";
    } elseif ($_GET['msg'] == "notfound") {
        $message = "<div id='payment-message' class='msg-error'>Payment not found or already processed.</div>";
    } elseif ($_GET['msg'] == "cancelled") {
        $message = "<div id='payment-message' class='msg-success'>Payment cancelled.</div>";
    }
}

// Show all PENDING and RECENT PAID payments (for receipt link)
$stmt = $conn->prepare("SELECT * FROM payment WHERE user_id=? AND (status='Pending' OR (status='Paid' AND paid_date >= DATE_SUB(NOW(), INTERVAL 1 DAY))) ORDER BY payment_id DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Payments | SwimHub</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="styles/styles.css">
    <style>
        :root {
            --primary: #0284c7;
            --primary-dark: #075985;
            --primary-light: #e0f2fe;
            --accent: #06b6d4;
            --text: #1e293b;
            --text-light: #64748b;
            --background: #f0f9ff;
        }
        html { height: 100%; overflow-y: scroll; }
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(180deg, #e0f2fe 0%, #e0f2fe 100%);
            color: #0c4a6e;
            line-height: 1.6;
        }

        .dashboard-container {
            display: flex;
            flex-direction: row;
            max-width: 1400px;       /* unified fixed width */
            min-width: 340px;
            width: 1200%;
            margin: 48px auto 32px auto;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 5px 24px rgba(2, 132, 199, 0.10);
            background: #fff;
        }

        .sidebar {
            width: 250px;
            background-color: #fff;
            padding: 30px 20px;
            border-right: 1px solid #e2e8f0;
        }

        .content {
            flex: 1 1 0%;
            padding: 38px 42px 30px 42px;
            min-width: 0;
            max-width: 100%;
            display: flex;
            flex-direction: column;
            background: #fff;
        }

        /* Header style for consistency */
        .content h2 {
            font-family: 'Montserrat', sans-serif;
            color: #075985;
            font-size: 2rem;
            margin-bottom: 15px;
        }

        /* Table styles */
        .payment-table { width: 100%; border-collapse: collapse; margin-top: 25px; }
        .payment-table th, .payment-table td { padding: 14px 12px; text-align: left; vertical-align: middle; }
        .payment-table th { background: #e0f2fe; color: #075985; }
        .payment-table tr { background: #fff; border-bottom: 1px solid #e0e7ef; }

        /* Messages */
        .msg-success {
            background: #d1fae5;
            color: #065f46;
            border: 1.5px solid #10b981;
            padding: 16px 28px;
            border-radius: 8px;
            margin-bottom: 22px;
            text-align: center;
            font-weight: 600;
        }
        .msg-error {
            background: #fee2e2;
            color: #991b1b;
            border: 1.5px solid #ef4444;
            padding: 16px 28px;
            border-radius: 8px;
            margin-bottom: 22px;
            text-align: center;
            font-weight: 600;
        }

        /* Payment action buttons */
        .payment-action-btn, .action-btn-download {
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            border: none;
            outline: none;
            margin: 2px 6px 2px 0;
            cursor: pointer;
            transition: background 0.18s, transform 0.18s, box-shadow 0.18s;
            box-shadow: 0 2px 7px rgba(2, 132, 199, 0.08);
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }
        /* Pay Now = Blue */
        .payment-action-btn.pay {
            background: linear-gradient(90deg, #0284c7 60%, #0ea5e9 100%);
            color: #fff;
        }
        .payment-action-btn.pay:hover {
            background: linear-gradient(90deg, #0369a1 60%, #0284c7 100%);
            transform: scale(1.04) translateY(-1px);
        }
        /* Cancel = Red */
        .payment-action-btn.cancel {
            background: #e11d48;
            color: #fff;
        }
        .payment-action-btn.cancel:hover {
            background: #be123c;
            transform: scale(1.04) translateY(-1px);
        }
        /* Download Receipt = Purple accent */
        .action-btn-download {
            background: #ede9fe;
            color: #7c3aed;
            border: 1.3px solid #a5b4fc;
            padding: 6px 18px;
            border-radius: 14px;
            font-size: 12px;
            font-weight: 600;
            box-shadow: 0 2px 7px rgba(2, 132, 199, 0.07);
            transition: background 0.16s, color 0.16s, border 0.16s, transform 0.16s;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }
        .action-btn-download:hover {
            background: #c7d2fe;
            color: #3730a3;
            border-color: #818cf8;
            transform: scale(1.04) translateY(-1px);
        }
        .center-action-btns {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
            justify-content: center;
            min-width: 120px;
        }
        .center-action-btns form { margin: 0; }
        .payment-action-wrap {
            display: flex;
            justify-content: center;
        }

        /* Responsive tweaks to match rest of dashboard */
        @media (max-width: 1024px) {
            .dashboard-container { max-width: 98vw; }
            .content { padding: 20px 8vw 24px 8vw; }
        }
        @media (max-width: 900px) {
            .content { padding: 16px 5vw 20px 5vw; }
        }
        @media (max-width: 768px) {
            .dashboard-container { flex-direction: column; }
            .sidebar {
                width: 100%;
                border-right: none;
                border-bottom: 1px solid #e2e8f0;
            }
            .content { padding: 16px 2vw 14px 2vw; }
        }
        @media (max-width: 480px) {
            .dashboard-container { max-width: 100vw; margin: 0; border-radius: 0; }
            .content { padding: 8px 1vw 8px 1vw; }
        }
    </style>
</head>
<body>
<div class="dashboard-container">
    <?php include 'user_sidebar.php'; ?>
    <div class="content">
        <h2>Your Payments</h2>
        <?php if ($message): ?>
            <?= $message ?>
        <?php endif; ?>
        <table class="payment-table">
            <tr>
                <th>Description</th>
                <th>Amount (RM)</th>
                <th>Status</th>
                <th>Action</th>
                <th>Reference No / Date</th>
            </tr>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= htmlspecialchars($row['description'] ?? 'Membership Payment') ?></td>
                    <td><?= number_format($row['amount'],2) ?></td>
                    <td><?= htmlspecialchars($row['status']) ?></td>
                    <td>
                        <div class="payment-action-wrap">
                        <?php if ($row['status'] == 'Pending'): ?>
                            <div class="center-action-btns">
                                <form method="get" action="gateway.php">
                                    <input type="hidden" name="payment_id" value="<?= $row['payment_id'] ?>">
                                    <button type="submit" class="payment-action-btn pay">Pay</button>
                                </form>
                                <form method="post" action="cancel_payment.php">
                                    <input type="hidden" name="payment_id" value="<?= $row['payment_id'] ?>">
                                    <button type="submit" class="payment-action-btn cancel">Cancel</button>
                                </form>
                            </div>
                        <?php elseif ($row['status'] == 'Paid'): ?>
                            <a href="receipt.php?payment_id=<?= $row['payment_id'] ?>" target="_blank" class="action-btn-download">Download Receipt</a>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                        </div>
                    </td>
                    <td>
                        <?= htmlspecialchars($row['reference_no'] ?? '-') ?><br>
                        <?= $row['paid_date'] ? date('d/m/Y H:i', strtotime($row['paid_date'])) : '-' ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>
<script>
    setTimeout(function() {
        var msg = document.getElementById('payment-message');
        if (msg) msg.style.display = 'none';
    }, 4000);
</script>
<?php include 'footer.php'; ?>
</body>
</html>
