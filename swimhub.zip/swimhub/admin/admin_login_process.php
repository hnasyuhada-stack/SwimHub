<?php
session_start();
require '../db.php'; // Change this to match your DB connection file

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input
    $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'];

    // Basic input validation
    if (!$email || empty($password)) {
        $_SESSION['login_error'] = "Please fill in all fields with valid data.";
        header("Location: admin_login.php");
        exit;
    }

    // Query database for this admin user
    $stmt = $conn->prepare("SELECT admin_id, admin_name, admin_password FROM admin WHERE admin_email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows === 1) {
        $stmt->bind_result($admin_id, $admin_name, $hashed_password);
        $stmt->fetch();

        if (password_verify($password, $hashed_password)) {
            // Security best practices
            session_regenerate_id(true);
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id'] = $admin_id;
            $_SESSION['admin_name'] = $admin_name;

            $_SESSION['login_success'] = "Welcome, $admin_name!";
            header("Location: admin_dashboard.php");
            exit;
        } else {
            $_SESSION['login_error'] = "Incorrect password.";
        }
    } else {
        $_SESSION['login_error'] = "Admin account not found.";
    }
    $stmt->close();
    $conn->close();

    header("Location: admin_login.php");
    exit;
} else {
    header("Location: admin_login.php");
    exit;
}
?>
