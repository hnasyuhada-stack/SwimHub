<?php $current = basename($_SERVER['PHP_SELF']); ?>
<style>
.sidebar {
  position: fixed;
  top: 0; left: 0;
  height: 100vh;
  width: 230px;
  background: linear-gradient(160deg, #e6f0ff 80%, #c9e2ff 100%);
  padding: 36px 20px 24px 20px;
  box-shadow: 2px 0 16px #e0e7ef77;
  border-top-right-radius: 24px;
  border-bottom-right-radius: 24px;
  display: flex;
  flex-direction: column;
  z-index: 100;
  align-items: center;
}
.sidebar-logo {
  width: 80px;
  height: 80px;
  object-fit: contain;
  margin-bottom: 16px;
  margin-top: 6px;
  border-radius: 18px;
  box-shadow: 0 2px 8px #c9e2ff70;
  background: #fff;
  padding: 10px;
}
.sidebar h3 {
  margin-top: 0;
  color: #17456e;
  font-size: 1.15rem;
  letter-spacing: 1.5px;
  font-weight: 900;
  text-transform: uppercase;
  border-bottom: 2px solid #bedcf8;
  padding-bottom: 12px;
  margin-bottom: 30px;
  opacity: 0.88;
  text-align: center;
  width: 100%;
}
.sidebar-nav {
  display: flex;
  flex-direction: column;
  gap: 8px;
  width: 100%;
}
.sidebar-nav a {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-bottom: 0;
  padding: 12px 20px;
  color: #16426a;
  background: none;
  border-radius: 12px;
  font-size: 16px;
  font-weight: 600;
  text-decoration: none;
  box-shadow: none;
  transition: background 0.19s, color 0.16s, box-shadow 0.15s;
  outline: none;
  border: none;
}
.sidebar-nav a.active,
.sidebar-nav a:hover {
  background: #1765b4;
  color: #fff;
  box-shadow: 0 2px 10px #8cc4f430;
  font-weight: 700;
  transform: translateY(-1px) scale(1.04);
}
.sidebar-nav a .sidebar-icon {
  font-size: 1.4rem;
  display: inline-block;
  width: 26px;
  text-align: center;
  transition: color 0.15s;
}
.sidebar-nav a.active .sidebar-icon,
.sidebar-nav a:hover .sidebar-icon {
  color: #ffd180;
}
@media (max-width: 750px) {
  .sidebar {
    width: 85vw;
    min-width: 150px;
    max-width: 250px;
    padding: 22px 10px 14px 14px;
  }
  .sidebar h3 {
    font-size: 1rem;
    padding-bottom: 7px;
  }
  .sidebar-nav a {
    font-size: 15px;
    padding: 10px 10px;
    gap: 10px;
  }
  .sidebar-logo {
    width: 54px; height: 54px; padding: 6px;
  }
}
</style>
<div class="sidebar">
  <!-- Logo section -->
      <img src="../image/logo.png" alt="Logo" class="sidebar-logo">

  <h3>Admin Menu</h3>
  <nav class="sidebar-nav">
    <a href="admin_dashboard.php" class="<?php if($current == 'admin_dashboard.php') echo 'active'; ?>">
      <span class="sidebar-icon">🏠</span>Dashboard
    </a>
    <a href="admin_view_members.php" class="<?php if($current == 'admin_view_members.php') echo 'active'; ?>">
      <span class="sidebar-icon">👥</span>View Members
    </a>
    <a href="admin_view_payments.php" class="<?php if($current == 'admin_view_payments.php') echo 'active'; ?>">
      <span class="sidebar-icon">💳</span>View Payments
    </a>
    <a href="admin_manage_packages.php" class="<?php if($current == 'admin_manage_packages.php') echo 'active'; ?>">
      <span class="sidebar-icon">📦</span>Manage Packages
    </a>
    <a href="admin_logout.php" onclick="return confirm('Are you sure you want to logout?')">
      <span class="sidebar-icon">🚪</span>Logout
    </a>
  </nav>
</div>
