<?php
session_start();
include '../session_check.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit;
}
require '../db.php';

// Handle filter parameters
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$status = isset($_GET['status']) ? trim($_GET['status']) : '';
$from_date = isset($_GET['from_date']) ? trim($_GET['from_date']) : '';
$to_date = isset($_GET['to_date']) ? trim($_GET['to_date']) : '';

$where = [];
if ($search !== "") {
    $safe_search = $conn->real_escape_string($search);
    $where[] = "(CONCAT(u.first_name, ' ', u.last_name) LIKE '%$safe_search%')";
}
if ($status !== "") {
    $safe_status = $conn->real_escape_string($status);
    $where[] = "LOWER(p.status) = '$safe_status'";
}
if ($from_date !== "") {
    $safe_from = $conn->real_escape_string($from_date);
    $where[] = "DATE(p.paid_date) >= '$safe_from'";
}
if ($to_date !== "") {
    $safe_to = $conn->real_escape_string($to_date);
    $where[] = "DATE(p.paid_date) <= '$safe_to'";
}
$where_sql = $where ? "WHERE " . implode(' AND ', $where) : "";

// Fetch payments with user and package info
$sql = "
SELECT 
    u.user_id,
    CONCAT(u.first_name, ' ', u.last_name) AS member_name,
    mp.package_name,
    p.amount,
    p.paid_date,
    p.status
FROM payment p
LEFT JOIN user_membership um ON p.membership_id = um.membership_id
LEFT JOIN users u ON um.user_id = u.user_id
LEFT JOIN membership_package mp ON um.package_id = mp.package_id
$where_sql
ORDER BY p.paid_date DESC
";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin - View Payments</title>
  <link rel="stylesheet" href="../styles/admin.css">
  <style>
    body {
      background: #f5f7fb;
      font-family: 'Segoe UI', 'Arial', sans-serif;
      margin: 0;
      padding: 0;
    }
    .dashboard-container {
      display: flex;
      min-height: 100vh;
    }
    .main-content {
      margin-left: 300px;
      padding: 35px 35px 35px 10px;
      width: 100%;
      background: #f8fafc;
      min-height: 100vh;
    }
    h2 {
      font-size: 2rem;
      margin-bottom: 20px;
      color: #214c7c;
      font-weight: 700;
    }

    .filter-bar form {
      display: flex;
      align-items: flex-end;
      gap: 18px;
      margin: 20px 0 28px 0;
      background: #e9f4ff;
      padding: 16px 24px;
      border-radius: 14px;
      box-shadow: 0 1px 6px #c9e2ff40;
      flex-wrap: wrap;
    }
    .filter-bar input[type="text"],
    .filter-bar select,
    .filter-bar input[type="date"] {
      height: 44px;
      font-size: 16px;
      padding: 0 15px;
      border-radius: 8px;
      border: 1px solid #bedcf8;
      background: #fafdff;
      min-width: 170px;
      box-sizing: border-box;
    }
    .filter-bar label {
      font-size: 14px;
      color: #3a4a64;
      margin-bottom: 3px;
      font-weight: 600;
    }
    .filter-bar button,
    .filter-bar .clear-btn {
      height: 44px;
      border-radius: 8px;
      font-weight: 600;
      font-size: 16px;
      box-shadow: 0 1px 4px #bedcf866;
      cursor: pointer;
      border: none;
      padding: 0 26px;
      transition: background 0.2s;
      margin-left: 0;
      vertical-align: middle;
      display: inline-block;
    }
    .filter-bar button {
      background-color: #1992dd;
      color: #fff;
      margin-right: 0;
    }
    .filter-bar button:hover {
      background-color: #1765b4;
    }
    .filter-bar .clear-btn {
      background-color: #ffe066;
      color: #8d6500;
      border: 1px solid #ffdd87;
      margin-left: 0;
      box-shadow: 0 1px 4px #eed66630;
      text-decoration: none;
      font-weight: 600;
      padding-top: 0;
      padding-bottom: 0;
      line-height: 44px;
      text-align: center;
    }
    .filter-bar .clear-btn:hover {
      background: #ffd43b;
      color: #7c5700;
    }

    .payments-table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0;
      background: #fff;
      border-radius: 16px;
      box-shadow: 0 1px 12px #e5eaf2;
      overflow: hidden;
      margin-top: 0;
    }
    .payments-table th {
      font-size: 15px;
      background: #e6f0ff;
      color: #003366;
      padding: 14px 10px;
      border-bottom: 2px solid #eaf0f6;
      font-weight: 700;
      letter-spacing: 0.13px;
      text-align: left;
    }
    .payments-table td {
      font-size: 15px;
      padding: 12px 10px;
      border-bottom: 1px solid #f2f2f2;
      background: #fff;
    }
    .payments-table tr:last-child td {
      border-bottom: none;
    }
    .payments-table tr:hover {
      background-color: #f7fcff;
      transition: background 0.13s;
    }
    .paid {
      color: #25ad53;
      font-weight: bold;
      background: #e4ffe4;
      border-radius: 6px;
      padding: 4px 14px;
      display: inline-block;
    }
    .pending {
      color: #e8a503;
      font-weight: bold;
      background: #fff8e1;
      border-radius: 6px;
      padding: 4px 14px;
      display: inline-block;
    }
    @media (max-width: 1000px) {
      .main-content { padding: 15px 3vw; margin-left: 0; }
      .dashboard-container { flex-direction: column; }
      .payments-table, .filter-bar input, .filter-bar select { font-size: 13px; }
      .filter-bar form { flex-direction: column; gap: 10px; align-items: stretch; }
      .filter-bar button, .filter-bar .clear-btn { width: 100%; margin-top: 7px; }
    }
  </style>
</head>
<body>
<div class="dashboard-container">
  <?php include 'admin_sidebar.php'; ?>
  <div class="main-content">
    <h2>All Payment Records</h2>
    <div class="filter-bar">
      <form method="get" action="">
        <input type="text" name="search" placeholder="Search by member name..." value="<?php echo htmlspecialchars($search); ?>">
        <select name="status">
          <option value="">All Statuses</option>
          <option value="paid" <?php if($status == 'paid') echo 'selected'; ?>>Paid</option>
          <option value="pending" <?php if($status == 'pending') echo 'selected'; ?>>Pending</option>
        </select>
        <label for="from_date">From</label>
        <input type="date" id="from_date" name="from_date" value="<?php echo htmlspecialchars($from_date); ?>">
        <label for="to_date">To</label>
        <input type="date" id="to_date" name="to_date" value="<?php echo htmlspecialchars($to_date); ?>">
        <button type="submit">Filter</button>
        <?php if($search || $status || $from_date || $to_date): ?>
          <a href="admin_view_payments.php" class="clear-btn">Clear</a>
        <?php endif; ?>
      </form>
    </div>
    <table class="payments-table">
      <thead>
        <tr>
          <th>Member ID</th>
          <th>Member Name</th>
          <th>Package</th>
          <th>Amount (RM)</th>
          <th>Date</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
          <?php while($row = $result->fetch_assoc()): ?>
            <tr>
              <td>#<?php echo htmlspecialchars(str_pad($row['user_id'], 3, '0', STR_PAD_LEFT)); ?></td>
              <td><?php echo htmlspecialchars($row['member_name']); ?></td>
              <td><?php echo htmlspecialchars($row['package_name']); ?></td>
              <td><?php echo htmlspecialchars(number_format($row['amount'], 2)); ?></td>
              <td><?php echo htmlspecialchars($row['paid_date']); ?></td>
              <td>
                <?php
                  $status_text = ucfirst(strtolower($row['status']));
                  $status_class = strtolower($row['status']) == 'paid' ? 'paid' : 'pending';
                  echo "<span class=\"$status_class\">$status_text</span>";
                ?>
              </td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="6" style="text-align:center; color:#888; font-style:italic;">No payments found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
</body>
</html>
