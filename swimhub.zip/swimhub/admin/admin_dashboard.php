<?php 
session_start();
include '../session_check.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit;
}
require_once __DIR__ . '/../db.php';

// Total Members
$result = $conn->query("SELECT COUNT(*) AS total FROM users");
$row = $result->fetch_assoc();
$total_members = $row['total'] ?? 0;

// Active Memberships
$result = $conn->query("SELECT COUNT(*) AS total FROM user_membership WHERE status = 'Active'");
$row = $result->fetch_assoc();
$active_memberships = $row['total'] ?? 0;

// Payments This Month (Total Received)
$result = $conn->query("SELECT SUM(amount) AS total FROM payment WHERE MONTH(paid_date) = MONTH(CURRENT_DATE()) AND YEAR(paid_date) = YEAR(CURRENT_DATE()) AND status = 'Paid'");
$row = $result->fetch_assoc();
$payments_this_month = $row['total'] ? "RM" . number_format($row['total'], 2) : "RM0.00";

// Pending Payments
$result = $conn->query("SELECT COUNT(*) AS total FROM payment WHERE status = 'Pending'");
$row = $result->fetch_assoc();
$pending_payments = $row['total'] ?? 0;

// --- Chart Data ---
$growth = [];
$growth_labels = [];
for ($i = 11; $i >= 0; $i--) {
    $ym = date('Y-m', strtotime("-$i months"));
    $start = $ym . '-01';
    $end = date('Y-m-t', strtotime($start));
    $sql = $conn->prepare("SELECT COUNT(*) AS total FROM user_membership WHERE DATE(start_date) >= ? AND DATE(start_date) <= ?");
    $sql->bind_param("ss", $start, $end);
    $sql->execute();
    $res = $sql->get_result()->fetch_assoc();
    $growth[] = (int)($res['total'] ?? 0);
    $growth_labels[] = date('M Y', strtotime($start));
    $sql->close();
}
$breakdown_query = $conn->query("
    SELECT package_age_group, COUNT(*) as count
    FROM user_membership um
    JOIN membership_package mp ON um.package_id = mp.package_id
    WHERE um.status = 'Active'
    GROUP BY package_age_group
");
$bd_labels = [];
$bd_values = [];
while ($row = $breakdown_query->fetch_assoc()) {
    $bd_labels[] = $row['package_age_group'];
    $bd_values[] = (int)$row['count'];
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
   <style>
    body {
      background: #f5f7fb;
      font-family: 'Segoe UI', 'Arial', sans-serif;
      margin: 0;
      padding: 0;
    }
.main-content {
  margin-left: 300px;  /* Make sure this matches your sidebar width! */
  padding: 35px 35px 35px 10px;
}

    h2 {
      font-size: 2rem;
      margin-bottom: 22px;
      color: #214c7c;
      font-weight: 700;
    }
    .summary-cards {
      display: flex;
      gap: 20px;
      margin-top: 18px;
      margin-bottom: 32px;
    }
    .card {
      flex: 1;
      background: #fff;
      border-radius: 16px;
      box-shadow: 0 2px 12px rgba(0,0,0,0.06);
      text-align: center;
      padding: 28px 0 22px 0;
      transition: box-shadow 0.22s;
      min-width: 170px;
    }
    .card h3 {
      margin: 0 0 8px 0;
      font-size: 1.12rem;
      color: #1992dd;
      font-weight: 600;
      letter-spacing: 0.4px;
    }
    .card p {
      font-size: 2rem;
      font-weight: 600;
      color: #222e3e;
      margin: 0;
    }

    .dashboard-analytics {
      display: flex;
      gap: 30px;
      margin-bottom: 34px;
    }
    .analytics-card {
      flex: 1;
      background: #fff;
      border-radius: 16px;
      box-shadow: 0 2px 12px rgba(0,0,0,0.06);
      padding: 22px 28px 16px 28px;
      display: flex;
      flex-direction: column;
      align-items: center;
      min-width: 270px;
      min-height: 310px;
      justify-content: flex-start;
    }
    .analytics-title {
      color: #133e5f;
      font-size: 1.15rem;
      font-weight: 600;
      margin-bottom: 12px;
      letter-spacing: 0.1px;
      text-align: left;
      width: 100%;
    }
    canvas {
      width: 100% !important;
      min-height: 210px !important;
      max-height: 250px !important;
      margin-top: 10px;
    }

    @media (max-width: 900px) {
      .dashboard-analytics, .summary-cards { flex-direction: column; gap: 12px; }
    }
  </style>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="dashboard-container">
  <?php include 'admin_sidebar.php'; ?>
  <div class="main-content">
    <h2>
      Welcome,
      <?php
        echo isset($_SESSION['admin_name']) 
            ? htmlspecialchars($_SESSION['admin_name']) 
            : "System Admin";
      ?>!
    </h2>
    <!-- Summary Cards -->
    <div class="summary-cards">
      <div class="card">
        <h3>Total Members</h3>
        <p><?php echo $total_members; ?></p>
      </div>
      <div class="card">
        <h3>Active Memberships</h3>
        <p><?php echo $active_memberships; ?></p>
      </div>
      <div class="card">
        <h3>Payments This Month</h3>
        <p><?php echo $payments_this_month; ?></p>
      </div>
      <div class="card">
        <h3>Pending Payments</h3>
        <p><?php echo $pending_payments; ?></p>
      </div>
    </div>

    <!-- Analytics & Tables -->
    <div class="dashboard-analytics">
      <div class="analytics-card">
        <div class="analytics-title">Member Growth Trend</div>
        <canvas id="growthChart"></canvas>
      </div>
      <div class="analytics-card">
        <div class="analytics-title">Membership Breakdown</div>
        <canvas id="breakdownChart"></canvas>
      </div>
    </div>
  </div>
</div>

<script>
// Member Growth Trend Chart
const growthCtx = document.getElementById('growthChart').getContext('2d');
new Chart(growthCtx, {
    type: 'line',
    data: {
        labels: <?= json_encode($growth_labels) ?>,
        datasets: [{
            label: 'New Members',
            data: <?= json_encode($growth) ?>,
            fill: true,
            tension: 0.35,
            borderColor: '#1c8ae6',
            backgroundColor: 'rgba(28, 138, 230, 0.14)',
            pointBackgroundColor: '#1992dd',
            pointRadius: 4,
            pointHoverRadius: 7,
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { display: false },
            tooltip: { enabled: true }
        },
        scales: {
            y: {
                title: { display: true, text: 'New Memberships' },
                beginAtZero: true,
                ticks: { stepSize: 1 }
            },
            x: {
                title: { display: true, text: 'Month' }
            }
        }
    }
});

// Membership Breakdown Pie Chart
const breakdownCtx = document.getElementById('breakdownChart').getContext('2d');
new Chart(breakdownCtx, {
    type: 'pie',
    data: {
        labels: <?= json_encode($bd_labels) ?>,
        datasets: [{
            data: <?= json_encode($bd_values) ?>,
            backgroundColor: ['#FFB347', '#6ec177', '#007acc', '#fa8383', '#b6a3f1', '#E8C3B9', '#C45850'],
            borderWidth: 2,
            borderColor: '#fff'
        }]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { position: 'bottom' },
            tooltip: { enabled: true }
        }
    }
});
</script>
</body>
</html>
