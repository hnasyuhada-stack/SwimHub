<?php
session_start();
include '../session_check.php';
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit;
}
require '../db.php';

// --- Handle Add Package ---
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['package_name']) && !isset($_POST['edit_id'])) {
    $name = $conn->real_escape_string(trim($_POST['package_name']));
    $age_group = $conn->real_escape_string(trim($_POST['age_group']));
    $class_size = $conn->real_escape_string(trim($_POST['class_size']));
    $sessions = (int)$_POST['session_count'];
    $duration = (int)$_POST['duration_months'];
    $price = (float)$_POST['price'];
    $desc = $conn->real_escape_string(trim($_POST['description']));

    $errors = [];
    if (!$name) $errors[] = "Package name is required.";
    if (!$age_group) $errors[] = "Age group is required.";
    if (!$class_size) $errors[] = "Class size is required.";
    if (!$sessions) $errors[] = "Session count is required.";
    if (!$duration) $errors[] = "Duration is required.";
    if ($price < 1) $errors[] = "Price must be at least RM1.00.";

    if (empty($errors)) {
        $conn->query("INSERT INTO membership_package 
            (package_name, package_age_group, package_class, package_session, package_duration, package_price, package_desc)
            VALUES 
            ('$name', '$age_group', '$class_size', $sessions, $duration, $price, '$desc')");
        header("Location: admin_manage_packages.php");
        exit;
    }
}

// --- Handle Update Package (Edit) ---
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['edit_id'])) {
    $id = (int)$_POST['edit_id'];
    $name = $conn->real_escape_string(trim($_POST['package_name']));
    $age_group = $conn->real_escape_string(trim($_POST['age_group']));
    $class_size = $conn->real_escape_string(trim($_POST['class_size']));
    $sessions = (int)$_POST['session_count'];
    $duration = (int)$_POST['duration_months'];
    $price = (float)$_POST['price'];
    $desc = $conn->real_escape_string(trim($_POST['description']));

    $errors = [];
    if (!$name) $errors[] = "Package name is required.";
    if (!$age_group) $errors[] = "Age group is required.";
    if (!$class_size) $errors[] = "Class size is required.";
    if (!$sessions) $errors[] = "Session count is required.";
    if (!$duration) $errors[] = "Duration is required.";
    if ($price < 1) $errors[] = "Price must be at least RM1.00.";

    if (empty($errors)) {
        $conn->query("UPDATE membership_package SET
            package_name='$name', package_age_group='$age_group', package_class='$class_size',
            package_session=$sessions, package_duration=$duration, package_price=$price, package_desc='$desc'
            WHERE package_id = $id");
        header("Location: admin_manage_packages.php");
        exit;
    } else {
        // repopulate edit_package if there are errors
        $edit_package = [
            'package_id' => $id,
            'package_name' => $name,
            'package_age_group' => $age_group,
            'package_class' => $class_size,
            'package_session' => $sessions,
            'package_duration' => $duration,
            'package_price' => $price,
            'package_desc' => $desc
        ];
    }
}

// --- Handle Delete Package ---
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM membership_package WHERE package_id = $id");
    header("Location: admin_manage_packages.php");
    exit;
}

// --- Get List of Packages ---
$packages = $conn->query("SELECT * FROM membership_package ORDER BY package_id");

// --- If Editing, Get the Row ---
if (!isset($edit_package) && isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $res = $conn->query("SELECT * FROM membership_package WHERE package_id=$edit_id");
    if ($res && $res->num_rows > 0) $edit_package = $res->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin - Manage Membership Packages</title>
 <link rel="stylesheet" href="../styles/admin.css">

<style>
body {
  background: #f5f7fb;
  font-family: 'Segoe UI', 'Arial', sans-serif;
  margin: 0;
  padding: 0;
}
.dashboard-container {
  display: flex;
  min-height: 100vh;
}
.main-content {
  margin-left: 300px;
  padding: 35px 35px 35px 10px;
  width: 100%;
  background: #f8fafc;
  min-height: 100vh;
}
h2 {
  font-size: 2rem;
  margin-bottom: 26px;
  color: #214c7c;
  font-weight: 700;
}
.card-section {
  background: #e9f4ff;
  padding: 28px 26px;
  border-radius: 18px;
  box-shadow: 0 1px 8px #c9e2ff50;
  margin-bottom: 38px;
  margin-top: 10px;
}
.table-title {
  font-size: 1.2rem;
  font-weight: 700;
  margin-bottom: 15px;
  color: #21598c;
}
.packages-table {
  width: 100%;
  border-collapse: separate;
  border-spacing: 0;
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 1px 12px #e5eaf2;
  overflow: hidden;
  margin-top: 0;
  margin-bottom: 32px;
}
.packages-table th {
  background: #e6f0ff;
  color: #003366;
  font-size: 15px;
  font-weight: 700;
  letter-spacing: 0.14px;
  padding: 13px 10px;
  border-bottom: 2px solid #eaf0f6;
  text-align: left;
}
.packages-table td {
  font-size: 15px;
  padding: 11px 10px;
  border-bottom: 1px solid #f2f2f2;
  background: #fff;
}
.packages-table tr:last-child td {
  border-bottom: none;
}
.packages-table tr:hover {
  background: #f7fcff;
  transition: background 0.13s;
}
.packages-table .btn {
  border: none;
  padding: 8px 18px;
  border-radius: 7px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  margin-right: 7px;
  transition: background 0.18s;
  box-shadow: 0 1px 4px #cce3ff40;
  text-decoration: none;
  display: inline-block;
}
.packages-table .btn-edit {
  background: #1992dd;
  color: #fff;
}
.packages-table .btn-edit:hover {
  background: #1765b4;
}
.packages-table .btn-delete {
  background: #ff5e5e;
  color: #fff;
}
.packages-table .btn-delete:hover {
  background: #d93737;
}
.form-section {
  background: #e9f4ff;
  padding: 30px 32px 24px 32px;
  border-radius: 18px;
  box-shadow: 0 1px 8px #c9e2ff30;
  margin-top: 30px;
  max-width: 700px;
  margin-bottom: 32px;
}
.form-section h3 {
  margin-top: 0;
  margin-bottom: 22px;
  font-size: 1.18rem;
  color: #22659c;
  font-weight: 700;
}
.form-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px 24px;
  margin-bottom: 18px;
}
.form-grid-full { grid-column: 1 / 3; }
label {
  font-weight: 600;
  color: #1d4975;
  font-size: 15px;
  margin-bottom: 6px;
  display: block;
}
input[type="text"], input[type="number"], select, textarea {
  width: 100%;
  padding: 10px 13px;
  margin-top: 3px;
  margin-bottom: 8px;
  border: 1px solid #b2d7f5;
  border-radius: 7px;
  font-size: 15px;
  background: #fafdff;
  box-sizing: border-box;
  transition: border 0.2s;
}
textarea {
  resize: vertical;
  min-height: 38px;
  max-height: 160px;
}
.form-btns {
  margin-top: 18px;
  display: flex;
  gap: 16px;
}
.form-btn {
  padding: 11px 28px;
  border-radius: 8px;
  font-weight: 700;
  font-size: 16px;
  background: #1992dd;
  color: #fff;
  border: none;
  cursor: pointer;
  box-shadow: 0 1px 4px #bedcf866;
  transition: background 0.18s;
}
.form-btn:hover { background: #1765b4; }
.form-btn-clear {
  background: #ffe066;
  color: #8d6500;
  border: 1px solid #ffdd87;
  margin-left: 0;
  box-shadow: 0 1px 4px #eed66630;
  text-decoration: none;
  font-weight: 600;
  padding: 11px 28px;
  border-radius: 8px;
  font-size: 16px;
  transition: background 0.2s;
}
.form-btn-clear:hover {
  background: #ffd43b;
  color: #7c5700;
}

@media (max-width: 1100px) {
  .form-section, .card-section { padding: 13px 7vw; }
  .main-content { padding: 14px 3vw; }
}
@media (max-width: 800px) {
  .main-content { margin-left: 0; }
  .form-section, .card-section { padding: 12px 2vw; }
  .form-grid { grid-template-columns: 1fr; }
  .form-grid-full { grid-column: auto; }
}
.form-section {
  background: #e6f2ff;
  padding: 28px 20px 24px 20px;
  border-radius: 18px;
  margin-top: 35px;
  max-width: 95vw;
}
.form-section h3 {
  color: #19456e;
  margin-bottom: 18px;
  font-size: 1.21rem;
}
.form-row {
  display: flex;
  gap: 24px;
  margin-bottom: 20px;
}
.form-col {
  flex: 1;
  display: flex;
  flex-direction: column;
}
.form-col label {
  font-weight: 600;
  color: #214c7c;
  margin-bottom: 7px;
  font-size: 1.06rem;
}
.form-col input,
.form-col select,
.form-col textarea {
  padding: 12px 14px;
  border: 1px solid #b8d0eb;
  border-radius: 8px;
  background: #fafdff;
  font-size: 1rem;
}
.form-col textarea {
  min-height: 60px;
  resize: vertical;
}
@media (max-width: 800px) {
  .form-row {
    flex-direction: column;
    gap: 4px;
  }
}
.required {
  color: #e53935;
  font-size: 1.13em;
  margin-left: 2px;
  font-weight: 700;
}
input:invalid, select:invalid, textarea:invalid {
  border-color: #ffb3b3;
}

 .error-list { background:#ffeaea; color:#c50000; border-radius:7px; padding: 12px 22px; margin-bottom:12px; font-size:15px;}
    .error-list ul { margin:0; padding-left:18px;}
</style>
  <script>
    // Extra JS validation if you want
    function validatePackageForm() {
      var price = document.getElementById('price').value;
      if (price === "" || parseFloat(price) < 1) {
        alert('Price must be at least RM1.00');
        document.getElementById('price').focus();
        return false;
      }
      return true;
    }
  </script>
</head>
<body>
<div class="dashboard-container">
  <?php include 'admin_sidebar.php'; ?>
  <div class="main-content">
    <h2>Existing Membership Packages</h2>
    <table class="packages-table">
      <thead>
        <tr>
          <th>Package Name</th>
          <th>Age Group</th>
          <th>Class Size</th>
          <th>Sessions</th>
          <th>Duration (Months)</th>
          <th>Price (RM)</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php if ($packages && $packages->num_rows > 0): ?>
        <?php while($row = $packages->fetch_assoc()): ?>
        <tr>
          <td><?php echo htmlspecialchars($row['package_name']); ?></td>
          <td><?php echo htmlspecialchars($row['package_age_group']); ?></td>
          <td><?php echo htmlspecialchars($row['package_class']); ?></td>
          <td><?php echo htmlspecialchars($row['package_session']); ?></td>
          <td><?php echo htmlspecialchars($row['package_duration']); ?></td>
          <td><?php echo number_format($row['package_price'],2); ?></td>
          <td>
            <a href="admin_manage_packages.php?edit=<?php echo $row['package_id']; ?>" class="btn btn-edit">Edit</a>
            <a href="admin_manage_packages.php?delete=<?php echo $row['package_id']; ?>" onclick="return confirm('Delete this package?')" class="btn btn-delete">Delete</a>
          </td>
        </tr>
        <?php endwhile; ?>
      <?php else: ?>
        <tr><td colspan="7">No packages found.</td></tr>
      <?php endif; ?>
      </tbody>
    </table>

    <div class="form-section">
      <h3><?php echo isset($edit_package) ? 'Edit Membership Package' : 'Add New Membership Package'; ?></h3>
      <?php if (!empty($errors)): ?>
        <div class="error-list">
          <strong>Please fix the following:</strong>
          <ul>
            <?php foreach ($errors as $err) echo "<li>".htmlspecialchars($err)."</li>"; ?>
          </ul>
        </div>
      <?php endif; ?>
      <form method="post" action="" onsubmit="return validatePackageForm()">
        <?php if (isset($edit_package)): ?>
          <input type="hidden" name="edit_id" value="<?php echo htmlspecialchars($edit_package['package_id']); ?>">
        <?php endif; ?>
        <!-- Row 1: Package Name + Age Group -->
        <div class="form-row">
          <div class="form-col">
            <label for="package_name">Package Name <span class="required">*</span></label>
            <input type="text" id="package_name" name="package_name" required maxlength="100"
                value="<?php echo isset($edit_package) ? htmlspecialchars($edit_package['package_name']) : ''; ?>">
          </div>
          <div class="form-col">
            <label for="age_group">Age Group <span class="required">*</span></label>
            <select id="age_group" name="age_group" required>
              <option value="">--Select Age Group--</option>
              <option value="3-6" <?php if(isset($edit_package)&&$edit_package['package_age_group']=="3-6") echo "selected"; ?>>3–6 (Toddlers)</option>
              <option value="7-12" <?php if(isset($edit_package)&&$edit_package['package_age_group']=="7-12") echo "selected"; ?>>7–12 (Kids)</option>
              <option value="13-17" <?php if(isset($edit_package)&&$edit_package['package_age_group']=="13-17") echo "selected"; ?>>13–17 (Teens)</option>
              <option value="18+" <?php if(isset($edit_package)&&$edit_package['package_age_group']=="18+") echo "selected"; ?>>18+ (Adults)</option>
            </select>
          </div>
        </div>
        <!-- Row 2: Class Size + Session Count -->
        <div class="form-row">
          <div class="form-col">
<label for="class_size">Class Size (Max participants) <span class="required">*</span></label>
<select id="class_size" name="class_size" required>
  <option value="">--Select Size--</option>
  <option value="4" <?php if(isset($edit_package)&&$edit_package['package_class']==4) echo "selected"; ?>>4</option>
  <option value="8" <?php if(isset($edit_package)&&$edit_package['package_class']==8) echo "selected"; ?>>8</option>
  <option value="12" <?php if(isset($edit_package)&&$edit_package['package_class']==12) echo "selected"; ?>>12</option>
  <option value="16" <?php if(isset($edit_package)&&$edit_package['package_class']==16) echo "selected"; ?>>16</option>
</select>
          </div>
          <div class="form-col">
            <label for="session_count">Session Count <span class="required">*</span></label>
            <select id="session_count" name="session_count" required>
              <option value="">--Select Sessions--</option>
              <option value="4" <?php if(isset($edit_package)&&$edit_package['package_session']==4) echo "selected"; ?>>4</option>
              <option value="8" <?php if(isset($edit_package)&&$edit_package['package_session']==8) echo "selected"; ?>>8</option>
              <option value="10" <?php if(isset($edit_package)&&$edit_package['package_session']==10) echo "selected"; ?>>10</option>
              <option value="12" <?php if(isset($edit_package)&&$edit_package['package_session']==12) echo "selected"; ?>>12</option>
              <option value="20" <?php if(isset($edit_package)&&$edit_package['package_session']==20) echo "selected"; ?>>20</option>
            </select>
          </div>
        </div>
        <!-- Row 3: Duration + Price -->
        <div class="form-row">
          <div class="form-col">
            <label for="duration_months">Duration (Months) <span class="required">*</span></label>
            <select id="duration_months" name="duration_months" required>
              <option value="">--Select Duration--</option>
              <option value="1" <?php if(isset($edit_package)&&$edit_package['package_duration']==1) echo "selected"; ?>>1</option>
              <option value="3" <?php if(isset($edit_package)&&$edit_package['package_duration']==3) echo "selected"; ?>>3</option>
              <option value="6" <?php if(isset($edit_package)&&$edit_package['package_duration']==6) echo "selected"; ?>>6</option>
              <option value="12" <?php if(isset($edit_package)&&$edit_package['package_duration']==12) echo "selected"; ?>>12</option>
            </select>
          </div>
          <div class="form-col">
            <label for="price">Price (RM) <span class="required">*</span></label>
            <input type="number" id="price" name="price" step="0.01" min="1" required 
                value="<?php echo isset($edit_package) ? htmlspecialchars($edit_package['package_price']) : ''; ?>" 
                oninput="validity.valid||(value='');">
          </div>
        </div>
        <!-- Full-width Description -->
        <div class="form-row">
          <div class="form-col" style="width: 100%;">
            <label for="description">Description</label>
            <textarea id="description" name="description" rows="3" maxlength="250"><?php echo isset($edit_package) ? htmlspecialchars($edit_package['package_desc']) : ''; ?></textarea>
          </div>
        </div>
        <button type="submit" class="form-btn" name="<?php echo isset($edit_package) ? 'update_package' : 'add_package'; ?>" style="margin-top: 18px;">
          <?php echo isset($edit_package) ? 'Update Package' : 'Add Package'; ?>
        </button>
        <?php if(isset($edit_package)): ?>
          <a href="admin_manage_packages.php" class="form-btn-clear" style="margin-left:10px;">Cancel</a>
        <?php endif; ?>
      </form>
    </div>
  </div>
</div>
</body>
</html>