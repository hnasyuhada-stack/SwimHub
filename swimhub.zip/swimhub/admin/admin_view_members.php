<?php
session_start();
include '../session_check.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: admin_login.php");
    exit;
}
require '../db.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$where = "";
if ($search !== "") {
    $safe_search = $conn->real_escape_string($search);
    $where = "WHERE CONCAT(u.first_name, ' ', u.last_name) LIKE '%$safe_search%' OR u.email LIKE '%$safe_search%'";
}

$sql = "
SELECT 
    u.user_id, 
    CONCAT(u.first_name, ' ', u.last_name) AS name, 
    u.email, u.phoneno, u.swimming_level,
    mp.package_name,
    um.start_date
FROM users u
LEFT JOIN user_membership um ON u.user_id = um.user_id
LEFT JOIN membership_package mp ON um.package_id = mp.package_id
$where
GROUP BY u.user_id
ORDER BY u.user_id
";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin - View Members</title>
  <link rel="stylesheet" href="../styles/admin.css">
  <style>
    body {
      background: #f5f7fb;
      font-family: 'Segoe UI', 'Arial', sans-serif;
      margin: 0;
      padding: 0;
    }
    .dashboard-container {
      display: flex;
      min-height: 100vh;
    }
    .main-content {
      margin-left: 300px;  /* Sidebar width */
      padding: 35px 35px 35px 10px;
      width: 100%;
      background: #f8fafc;
      min-height: 100vh;
    }
    h2 {
      font-size: 2rem;
      margin-bottom: 20px;
      color: #214c7c;
      font-weight: 700;
    }
.search-bar form {
  display: flex;
  align-items: flex-end;  /* <--- Aligns input and buttons bottom-to-bottom */
  gap: 18px;
  margin: 20px 0 28px 0;
  background: #e9f4ff;
  padding: 16px 24px;
  border-radius: 14px;
  box-shadow: 0 1px 6px #c9e2ff40;
}

.search-bar input[type="text"] {
  width: 260px;
  padding: 0 14px;
  border-radius: 7px;
  border: 1px solid #c1d6ef;
  font-size: 16px;
  background: #fafdff;
  height: 44px;
  box-sizing: border-box;
  display: block;
}
.search-bar button,
.search-bar .clear-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 44px;
  padding: 0 22px;
  border-radius: 7px;
  border: none;
  font-weight: 600;
  font-size: 15px;
  letter-spacing: .3px;
  cursor: pointer;
  min-width: 100px;
  box-sizing: border-box;
}
.search-bar button {
  background-color: #1992dd;
  color: white;
}
.search-bar button:hover {
  background-color: #146bb2;
}
.search-bar .clear-btn {
  background-color: #ffe066;
  color: #8d6500;
  text-decoration: none;
  border: 1px solid #ffdd87;
  box-shadow: 0 1px 4px #eed66630;
  font-weight: 600;
}
.search-bar .clear-btn:hover {
  background: #ffd43b;
  color: #7c5700;
}


    .members-table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0;
      margin-top: 0;
      background: white;
      border-radius: 16px;
      box-shadow: 0 1px 12px #e5eaf2;
      overflow: hidden;
    }
    .members-table th {
      font-size: 15px;
      background: #e6f0ff;
      color: #003366;
      padding: 13px 10px;
      border-bottom: 2px solid #eaf0f6;
      font-weight: 700;
      letter-spacing: 0.15px;
      text-align: left;
    }
    .members-table td {
      font-size: 15px;
      padding: 11px 10px;
      border-bottom: 1px solid #f2f2f2;
      background: #fff;
    }
    .members-table tr:last-child td {
      border-bottom: none;
    }
    .members-table tr:hover {
      background-color: #f7fcff;
      transition: background 0.13s;
    }
    @media (max-width: 1000px) {
      .main-content { padding: 15px 3vw; margin-left: 0; }
      .dashboard-container { flex-direction: column; }
      .members-table, .search-bar input[type="text"] { font-size: 13px; }
    }
  </style>
</head>
<body>

<div class="dashboard-container">
  <?php include 'admin_sidebar.php'; ?>

  <div class="main-content">
    <h2>All Registered Members</h2>
    <div class="search-bar">
     <form method="get" action="">
  <input type="text" name="search" placeholder="Search by name or email..." value="<?php echo htmlspecialchars($search); ?>">
  <button type="submit">Search</button>
  <?php if($search): ?>
    <button type="button" class="clear-btn" onclick="window.location.href='admin_view_members.php'">Clear</button>
  <?php endif; ?>
</form>

    </div>
    <table class="members-table">
      <thead>
        <tr>
          <th>Member ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Swimming Level</th>
          <th>Membership Package</th>
          <th>Join Date</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
          <?php while($row = $result->fetch_assoc()): ?>
            <tr>
              <td>#<?php echo htmlspecialchars(str_pad($row['user_id'], 3, '0', STR_PAD_LEFT)); ?></td>
              <td><?php echo htmlspecialchars($row['name']); ?></td>
              <td><?php echo htmlspecialchars($row['email']); ?></td>
              <td><?php echo htmlspecialchars($row['phoneno']); ?></td>
              <td><?php echo htmlspecialchars($row['swimming_level']); ?></td>
              <td><?php echo htmlspecialchars($row['package_name'] ?? '—'); ?></td>
              <td><?php echo htmlspecialchars($row['start_date'] ?? '—'); ?></td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="7" style="text-align:center; color:#888; font-style:italic;">No members found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
</body>
</html>
