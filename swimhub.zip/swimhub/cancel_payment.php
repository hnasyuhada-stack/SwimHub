<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id']) || !isset($_POST['payment_id'])) {
    header("Location: viewpayment.php?msg=notfound");
    exit();
}

$user_id = $_SESSION['user_id'];
$payment_id = intval($_POST['payment_id']);

// 1. Get payment and related membership
$stmt = $conn->prepare("SELECT * FROM payment WHERE payment_id = ? AND user_id = ?");
$stmt->bind_param("ii", $payment_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    // 2. Cancel the payment
    $update = $conn->prepare("UPDATE payment SET status='Cancelled' WHERE payment_id = ?");
    $update->bind_param("i", $payment_id);
    $update->execute();

    // 3. Also cancel (or deactivate) the related membership if status is Pending/New
    if (!empty($row['membership_id'])) {
        // Only cancel membership if this payment created the membership (new membership, not renewal)
        // You may need to add logic here based on your rules
        $update2 = $conn->prepare("UPDATE user_membership SET status='Cancelled' WHERE membership_id = ? AND user_id = ?");
        $update2->bind_param("ii", $row['membership_id'], $user_id);
        $update2->execute();
    }
    header("Location: viewpayment.php?msg=cancelled");
    exit();
} else {
    header("Location: viewpayment.php?msg=notfound");
    exit();
}
?>
