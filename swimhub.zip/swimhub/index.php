<?php
session_start();

// Check login status 
$isLoggedIn = isset($_SESSION['user_id']);
$username = $isLoggedIn ? $_SESSION['first_name'] : ''; 
$page = isset($_GET['page']) ? $_GET['page'] : 'home'; // Default to home

// Optionally show logout message
if (isset($_GET['msg']) && $_GET['msg'] === 'logout') {
    echo '<div style="background:#d4edda;color:#155724;padding:12px 20px;margin:15px auto 10px auto;
    border-radius:4px;max-width:450px;text-align:center;">You have successfully logged out.</div>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>SwimHub</title>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="styles/styles.css">
</head>
<body>

<!-- HEADER (navbar) -->
<header>
  <div class="logo">
    <img src="image/logo.png" alt="Logo">
    <span>SwimHub</span>
  </div>
<nav>
  <ul>
    <li><a href="index.php?page=homepage" class="<?= ($page=='homepage')?'active':'' ?>">HOME</a></li>
    <li><a href="index.php?page=aboutus" class="<?= ($page=='aboutus')?'active':'' ?>">ABOUT US</a></li>
    <li><a href="index.php?page=contact" <?php if($page=='contact') echo 'class="active"'; ?>>CONTACT US</a></li>
    <li><a href="index.php?page=admin_login" class="<?= ($page=='admin_login')?'active':'' ?>">STAFF</a></li>
    <li><a href="index.php?page=swimming" class="<?= ($page=='swimming')?'active':'' ?>">SWIMMING</a></li>
    <li><a href="index.php?page=policy" class="<?= ($page=='policy')?'active':'' ?>">POLICY</a></li>
    <li>
      <div class="user-icon">
        <a href="index.php?page=Login">
          <img src="image/user-icon.png" alt="User Icon">
        </a>
      </div>
    </li>
  </ul>
</nav>

</header>


<!-- END HEADER -->

<main>
  <?php
    $file = "userpages/$page.php";
    if (file_exists($file)) {
      include $file;
    } else {
      echo "<p style='text-align:center;color:#ef4444;'>Page not found.</p>";
    }
  ?>
</main>

<?php include 'footer.php'; ?>
</body>
</html>
