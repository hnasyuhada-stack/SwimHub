<?php
session_start();
include 'session_check.php';
include 'db.php';

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    header("Location: Login.php");
    exit();
}

$message = "";

// Count total memberships for user
$countQ = $conn->prepare("SELECT COUNT(*) AS total FROM user_membership WHERE user_id=?");
$countQ->bind_param("i", $user_id);
$countQ->execute();
$countRes = $countQ->get_result()->fetch_assoc();
$totalMemberships = $countRes['total'];
$countQ->close();

// Get cancelled but not yet expired membership
$cancelled = null;
$stmt = $conn->prepare("
    SELECT um.*, mp.package_name, mp.package_desc
    FROM user_membership um
    JOIN membership_package mp ON um.package_id = mp.package_id
    WHERE um.user_id=? AND um.status='Cancelled' AND um.end_date >= CURDATE()
    ORDER BY um.end_date DESC LIMIT 1
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$cancelled = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Get active membership
$current = null;
$stmt = $conn->prepare("
    SELECT um.*, mp.package_name, mp.package_desc
    FROM user_membership um
    JOIN membership_package mp ON um.package_id = mp.package_id
    WHERE um.user_id=? AND um.status='Active'
    ORDER BY um.end_date DESC LIMIT 1
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$current = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Get the latest payment for this membership 
$current_payment = null;
if ($current) {
    $paystmt = $conn->prepare("SELECT * FROM payment WHERE membership_id=? ORDER BY payment_id DESC LIMIT 1");
    $paystmt->bind_param("i", $current['membership_id']);
    $paystmt->execute();
    $current_payment = $paystmt->get_result()->fetch_assoc();
    $paystmt->close();
}

// For display
$showStatus = $current['status'] ?? '';
if ($current_payment && $current_payment['status'] == "Pending") {
    $showStatus = "Pending";
}

// All packages (for duration/session/price display)
$pkgArr = [];
$pkgQ = $conn->query("SELECT * FROM membership_package");
while($pkg = $pkgQ->fetch_assoc()) {
    $pkgArr[$pkg['package_id']] = $pkg;
}

// Membership history
$stmt = $conn->prepare("
    SELECT um.*, mp.package_name
    FROM user_membership um
    JOIN membership_package mp ON um.package_id = mp.package_id
    WHERE um.user_id=?
    ORDER BY um.start_date DESC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$history = $stmt->get_result();

// Handle membership actions
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // RENEW
    if (isset($_POST['renew_confirm'])) {
        if ($current) {
            $pkgStmt = $conn->prepare("SELECT * FROM membership_package WHERE package_id=? LIMIT 1");
            $pkgStmt->bind_param("i", $current['package_id']);
            $pkgStmt->execute();
            $pkg = $pkgStmt->get_result()->fetch_assoc();
            $pkgStmt->close();

            $duration = $pkg['package_duration'] ?? 3;
            $price = $pkg['package_price'] ?? 80.00;

            // Prevent multiple pending renewals
            $check = $conn->prepare("SELECT 1 FROM payment WHERE membership_id=? AND status='Pending' AND description LIKE 'Renew%' LIMIT 1");
            $check->bind_param("i", $current['membership_id']);
            $check->execute();
            $check->store_result();
            if ($check->num_rows > 0) {
                $message = "You already have a pending renewal payment for this membership.";
            } else {
                $current_end = $current['end_date'];
                $now = date('Y-m-d');
                $base = (strtotime($current_end) > strtotime($now)) ? $current_end : $now;
                $new_end = date('Y-m-d', strtotime("+$duration months", strtotime($base)));
                $desc = "Renew membership for package #" . $current['package_id'] . " ({$duration} months). New expiry: $new_end";
                $stmt2 = $conn->prepare("INSERT INTO payment (user_id, membership_id, amount, status, description) VALUES (?, ?, ?, 'Pending', ?)");
                $stmt2->bind_param("iids", $user_id, $current['membership_id'], $price, $desc);
                $stmt2->execute();
                $stmt2->close();

                header("Location: viewpayment.php?membership_id={$current['membership_id']}&new_end_date=$new_end");
                exit();
            }
            $check->close();
        }
    }
    // CANCEL
    if (isset($_POST['cancel'])) {
        if ($current) {
            $stmt = $conn->prepare("UPDATE user_membership SET status='Cancelled' WHERE membership_id=?");
            $stmt->bind_param("i", $current['membership_id']);
            $stmt->execute();
            $stmt->close();
            $message = "Membership cancelled!";
            header("Location: managemembership.php");
            exit();
        } else {
            $message = "No active membership to cancel.";
        }
    }
    // REACTIVATE
    if (isset($_POST['reactivate'])) {
        if ($cancelled) {
            $stmt = $conn->prepare("UPDATE user_membership SET status='Active' WHERE membership_id=?");
            $stmt->bind_param("i", $cancelled['membership_id']);
            $stmt->execute();
            $stmt->close();
            $message = "Membership reactivated!";
            header("Location: managemembership.php");
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Membership | SwimHub</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">
    <style>
        :root {
            --primary: #0284c7;
            --primary-dark: #075985;
            --primary-light: #e0f2fe;
            --accent: #06b6d4;
            --text: #1e293b;
            --text-light: #64748b;
            --background: #f0f9ff;
            --success: #10b981;
        }
        html { height: 100%; overflow-y: scroll; }
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(180deg, #e0f2fe 0%, #e0f2fe 100%);
            color: #0c4a6e;
            line-height: 1.6;
        }
        .dashboard-container {
            display: flex;
            flex-direction: row;
            max-width: 1400px;
            min-width: 340px;
            width: 1200%;
            margin: 48px auto 32px auto;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 5px 24px rgba(2, 132, 199, 0.10);
            background: #fff;
        }
        .sidebar {
            width: 250px;
            background-color: #fff;
            padding: 30px 20px;
            border-right: 1px solid #e2e8f0;
        }
        .content {
            flex: 1 1 0%;
            padding: 38px 42px 30px 42px;
            min-width: 0;
            max-width: 100%;
            display: flex;
            flex-direction: column;
            background: #fff;
        }
        .page-header {
            text-align: center;
            margin-bottom: 40px;
        }
        .page-header h1 {
            font-family: 'Montserrat', sans-serif;
            color: var(--primary-dark);
            font-size: 2rem;
            margin-bottom: 10px;
            position: relative;
        }
        .page-header h1::after {
            content: '';
            display: block;
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            margin: 15px auto 0;
            border-radius: 2px;
        }
        .page-header p {
            color: var(--text-light);
        }
        .membership-details-card {
            background: #fff;
            border-radius: 16px;
            padding: 40px 30px;
            box-shadow: 0 4px 18px rgba(2, 132, 199, 0.09);
            margin-bottom: 35px;
            width: 100%;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }
        .membership-details-card h2 {
            font-family: 'Montserrat', sans-serif;
            color: #075985;
            margin-bottom: 15px;
            font-size: 1.7rem;
            text-align: left;
        }
        .membership-info-list {
            list-style: none;
            padding: 0;
            margin-bottom: 30px;
        }
        .membership-info-list li {
            margin-bottom: 16px;
            font-size: 1.07rem;
            display: flex;
            align-items: center;
        }
        .membership-info-list .label {
            min-width: 180px;
            color: #0284c7;
            font-weight: 600;
        }
        .membership-actions {
            display: flex;
            gap: 18px;
            margin-top: 8px;
        }
        .membership-actions .action-btn {
            padding: 12px 32px;
            border-radius: 25px;
            font-size: 1rem;
            font-weight: 600;
            border: none;
            cursor: pointer;
            background: linear-gradient(90deg, #0284c7, #0ea5e9);
            color: #fff;
            transition: background 0.2s, transform 0.2s;
            box-shadow: 0 3px 10px rgba(2,132,199,0.10);
        }
        .membership-actions .action-btn:hover {
            background: linear-gradient(90deg, #0369a1 0%, #0284c7 100%);
            transform: translateY(-2px) scale(1.03);
        }
        .membership-actions .action-btn.cancel {
            background: #e11d48;
            color: #fff;
        }
        .membership-actions .action-btn.cancel:hover {
            background: #be123c;
        }
        .history-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 35px;
        }
        .history-table th, .history-table td {
            padding: 14px 12px;
            text-align: left;
        }
        .history-table th {
            background: #e0f2fe;
            color: #075985;
            font-weight: 700;
        }
        .history-table tr {
            background: #fff;
            border-bottom: 1px solid #e0e7ef;
        }
        .history-table tr:last-child {
            border-bottom: none;
        }
        .status-pill {
            display: inline-block;
            padding: 4px 18px;
            border-radius: 20px;
            font-size: 0.98rem;
            font-weight: 600;
            background: #10b98110;
            color: #10b981;
        }
        .status-pill.expired {
            background: #f8717110;
            color: #ef4444;
        }
        @media (max-width: 1024px) {
            .dashboard-container { max-width: 98vw; }
            .content { padding: 20px 8vw 24px 8vw; }
            .membership-details-card { padding: 24px 6vw; }
        }
        @media (max-width: 900px) {
            .membership-details-card { padding: 18px 5vw; }
            .membership-actions { flex-direction: column; gap: 10px; }
        }
        @media (max-width: 768px) {
            .dashboard-container { flex-direction: column; }
            .sidebar {
                width: 100%;
                border-right: none;
                border-bottom: 1px solid #e2e8f0;
            }
            .content { padding: 20px 5vw 24px 5vw; }
        }
        @media (max-width: 480px) {
            .dashboard-container { max-width: 100vw; margin: 0; border-radius: 0; }
            .content { padding: 14px 2vw 18px 2vw; }
            .membership-details-card { padding: 8vw 2vw; }
        }
        .action-btn {
            padding: 12px 32px;
            border-radius: 25px;
            font-size: 1rem;
            font-weight: 600;
            border: none;
            cursor: pointer;
            background: linear-gradient(90deg, #0284c7, #0ea5e9);
            color: #fff;
            transition: background 0.2s, transform 0.2s;
            box-shadow: 0 3px 10px rgba(2,132,199,0.10);
            text-align: center;
            display: inline-block;
            text-decoration: none;
        }
        .action-btn:hover {
            background: linear-gradient(90deg, #0369a1 0%, #0284c7 100%);
            transform: translateY(-2px) scale(1.03);
            text-decoration: none;
        }
        .action-btn.cancel { background: #e11d48; color: #fff; }
        .action-btn.cancel:hover { background: #be123c; }
        .package-details-table {
            border-collapse: collapse;
            margin: 8px 0 10px 0;
            width: auto;
            background: #f8fafc;
            border-radius: 10px;
            overflow: hidden;
            font-size: 1rem;
        }
        .package-details-table td { padding: 6px 18px 6px 0; border: none; vertical-align: top; color: #0c4a6e; }
        .package-details-table tr:not(:last-child) td { border-bottom: 1px solid #e0e7ef; }
        .info-tooltip { cursor: help; font-size: 1.15em; margin-left: 6px; color: #0284c7; vertical-align: middle; display: inline-block; }
        .date-start { color: #0284c7; font-weight: 600; }
        .date-end { color: #f59e42; font-weight: 600; }
        .date-next-payment { color: #10b981; font-weight: 700; }
    </style>
</head>
<body>
<div class="dashboard-container">
    <?php include 'user_sidebar.php'; ?>
    <div class="content">
        <div class="page-header">
            <h1>Manage Membership</h1>
            <p>View, renew, or update your SwimHub membership.</p>
        </div>
        <div class="membership-details-card">
            <h2>Current Membership</h2>
            <?php if ($current): ?>
                <!-- ACTIVE membership details -->
                <ul class="membership-info-list">
                    <li>
                        <span class="label">Status:</span>
                        <span class="status-pill"><?= htmlspecialchars($showStatus) ?></span>
                    </li>
                    <li>
                        <span class="label">Package:</span>
                        <div>
                            <strong><?= htmlspecialchars($current['package_name']) ?></strong>
                            <table class="package-details-table">
                                <tr>
                                    <td><b>Description</b></td>
                                    <td><?= htmlspecialchars($current['package_desc'] ?? '-') ?></td>
                                </tr>
                                <tr>
                                    <td><b>Group</b></td>
                                    <td><?= htmlspecialchars($current['selected_class_size'] ?? '-') ?></td>
                                </tr>
                                <tr>
                                    <td><b>Duration</b></td>
                                    <td><?= htmlspecialchars($pkgArr[$current['package_id']]['package_duration'] ?? '-') ?> months</td>
                                </tr>
                                <tr>
                                    <td><b>Sessions</b></td>
                                    <td><?= htmlspecialchars($pkgArr[$current['package_id']]['package_session'] ?? '-') ?></td>
                                </tr>
                                <tr>
                                    <td><b>Price</b></td>
                                    <td>RM<?= htmlspecialchars(number_format($pkgArr[$current['package_id']]['package_price'] ?? 0,2)) ?></td>
                                </tr>
                            </table>
                        </div>
                    </li>
                    <li>
                        <span class="label">Start Date:</span>
                        <span class="date-start"><?= date('j F Y', strtotime($current['start_date'])) ?></span>
                    </li>
                    <li>
                        <span class="label">End Date:</span>
                        <span class="date-end"><?= date('j F Y', strtotime($current['end_date'])) ?></span>
                    </li>
                    <li>
                        <span class="label">Next Payment:</span>
                        <span class="date-next-payment"><?= date('j F Y', strtotime($current['end_date'])) ?></span>
                    </li>
                </ul>
                <?php if ($showStatus == "Pending"): ?>
                    <div style="margin-bottom: 18px; background: #fff9db; color: #92400e; border: 1.5px solid #fde68a; padding: 12px 22px; border-radius: 10px;">
                        <strong>⚠️ Payment Pending:</strong> Your membership will be activated once payment is complete.<br>
                        <a href="viewpayment.php?membership_id=<?= $current['membership_id'] ?>" class="action-btn" style="margin-top:10px;">Pay Now</a>
                    </div>
                <?php endif; ?>

                <!-- Renew & Cancel buttons -->
                <form method="post" id="renewForm" style="display:inline;">
                    <input type="hidden" name="renew_confirm" value="1">
                    <button class="action-btn" id="renewBtn" type="button" <?= $showStatus == 'Pending' ? 'disabled' : '' ?>>Renew Membership</button>
                </form>
                <form method="post" style="display:inline;">
                    <input type="hidden" name="cancel" value="1">
                    <button class="action-btn cancel" type="submit" onclick="return confirm('Are you sure you want to cancel your membership?');" <?= $showStatus == 'Pending' ? 'disabled' : '' ?>>Cancel Membership</button>
                </form>
                <div id="renewModal" style="display:none;position:fixed;left:0;top:0;width:100vw;height:100vh;z-index:9999;background:rgba(0,0,0,0.25);align-items:center;justify-content:center;">
                    <div style="background:#fff;padding:32px 24px;border-radius:18px;width:350px;box-shadow:0 10px 30px rgba(0,0,0,0.10)">
                        <h3 style="margin-top:0;">Renew Membership?</h3>
                        <div>
                            <div><b>Current End Date:</b> <?= date('j F Y', strtotime($current['end_date'])) ?></div>
                            <div><b>New End Date:</b> <span id="modalNewEndDate"><?= date('j F Y', strtotime("+{$pkgArr[$current['package_id']]['package_duration']} months", strtotime((strtotime($current['end_date']) > strtotime(date('Y-m-d'))) ? $current['end_date'] : date('Y-m-d')))) ?></span></div>
                            <div style="margin:10px 0;"><b>Renewal Fee:</b> RM<?= number_format($pkgArr[$current['package_id']]['package_price'], 2) ?></div>
                        </div>
                        <button class="action-btn" onclick="confirmRenewal()" style="width:100%;margin-top:16px;">Confirm & Pay</button>
                        <button class="action-btn cancel" style="width:100%;margin-top:6px;" onclick="document.getElementById('renewModal').style.display='none'">Cancel</button>
                    </div>
                </div>
                <script>
                    function confirmRenewal() { document.getElementById('renewForm').submit(); }
                    document.getElementById('renewBtn').onclick = function() {
                        document.getElementById('renewModal').style.display = 'flex';
                    }
                </script>
            <?php elseif ($cancelled): ?>
                <!-- If only one cancelled membership, show Add Membership. Else show Reactivate. -->
                <ul class="membership-info-list">
                    <li>
                        <span class="label">Status:</span>
                        <span class="status-pill cancelled">Cancelled (not expired)</span>
                    </li>
                    <li>
                        <span class="label">End Date:</span>
                        <span class="date-end"><?= date('j F Y', strtotime($cancelled['end_date'])) ?></span>
                    </li>
                </ul>
                <form method="post">
                    <input type="hidden" name="reactivate" value="1">
                    <button class="action-btn" type="submit">Reactivate Membership</button>
                </form>
            <?php else: ?>
                <p>You do not have an active membership.</p>
                <a href="add_membership.php" class="action-btn">Add Membership</a>
            <?php endif; ?>
            <?php if (!empty($message)) echo "<div style='margin-top:15px;color:green;font-weight:600;'>$message</div>"; ?>
        </div>
        <div class="membership-details-card">
            <h2>Membership History</h2>
            <table class="history-table">
                <tr>
                    <th>Package</th>
                    <th>Period</th>
                    <th>Status</th>
                    <th>Paid (RM)</th>
                </tr>
                <?php if ($history->num_rows > 0): ?>
                    <?php while($row = $history->fetch_assoc()): ?>
                        <?php
                        $memid = $row['membership_id'];
                        $payq = $conn->query("SELECT * FROM payment WHERE membership_id=$memid ORDER BY payment_id DESC LIMIT 1");
                        $pay = $payq->fetch_assoc();
                        $status_show = $row['status'];
                        $paid_show = "-";
                        if ($pay) {
                            if ($pay['status'] === 'Pending') {
                                $status_show = "Pending";
                                $paid_show = "-";
                            } else if ($pay['status'] === 'Paid') {
                                $status_show = $row['status'];
                                $paid_show = "RM" . number_format($pay['amount'], 2);
                            }
                        }
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($row['package_name']) ?></td>
                            <td><?= date('j M Y', strtotime($row['start_date'])) ?> - <?= date('j M Y', strtotime($row['end_date'])) ?></td>
                            <td>
                                <span class="status-pill"><?= htmlspecialchars($status_show) ?></span>
                            </td>
                            <td><?= htmlspecialchars($paid_show) ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="4" style="text-align:center;">No membership history found.</td></tr>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>
</body>
</html>