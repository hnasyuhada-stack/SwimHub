<?php
session_start();
include 'db.php';

$user_id = $_SESSION['user_id'] ?? null;
$payment_id = $_GET['payment_id'] ?? 0;
$stmt = $conn->prepare("SELECT * FROM payment WHERE payment_id=? AND user_id=?");
$stmt->bind_param("ii", $payment_id, $user_id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();

if (!$row) die("No receipt found.");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Payment Receipt</title>
    <style>
        body {
            background: #f0f9ff;
            font-family: 'Segoe UI', Arial, sans-serif;
            color: #193356;
        }
        .receipt-container {
            background: #fff;
            border-radius: 24px;
            box-shadow: 0 6px 32px rgba(2,132,199,0.09);
            margin: 40px auto;
            padding: 42px 44px 30px 44px;
            max-width: 520px;
        }
        .logo {
            width: 110px;
            display: block;
            margin: 0 auto 14px auto;
        }
        .title {
            color: #0284c7;
            font-size: 2rem;
            font-weight: 700;
            margin-bottom: 18px;
            text-align: center;
        }
        hr {
            border: none;
            border-top: 2px solid #bae6fd;
            margin: 18px 0 26px 0;
        }
        .details {
            font-size: 1.12rem;
            line-height: 2.1;
            margin-bottom: 22px;
            text-align: left;
        }
        .details .label {
            color: #0284c7;
            font-weight: 700;
            min-width:140px;
            display:inline-block;
        }
        .details .value {
            font-weight: 500;
            color: #0091ae;
        }
        .details .refno {
            color: #0891b2;
            font-weight: 700;
            font-size: 1.05rem;
        }
        .details .amount {
            color: #2563eb;
            font-size: 1.15rem;
            font-weight: 700;
        }
        .footer {
            color: #64748b;
            margin-top: 22px;
            font-size: 1.04rem;
            text-align: center;
        }
        .receipt-actions {
            display: flex;
            justify-content: center;
            gap: 16px;
            margin-top: 34px;
            flex-wrap: wrap;
        }
        .action-btn {
            background: linear-gradient(90deg,#0284c7,#0ea5e9);
            color: #fff;
            font-weight: 700;
            padding: 15px 36px;
            border-radius: 28px;
            border: none;
            cursor: pointer;
            font-size: 1.14rem;
            margin-bottom: 0;
            box-shadow: 0 3px 12px rgba(2,132,199,0.08);
            transition: background 0.2s;
        }
        .action-btn:hover {
            background: linear-gradient(90deg,#0369a1,#0284c7);
        }
        @media (max-width: 600px) {
            .receipt-container {
                padding: 18px 4vw;
            }
            .action-btn {
                width: 100%;
                margin-bottom: 8px;
            }
            .receipt-actions {
                flex-direction: column;
                gap: 10px;
            }
        }
        @media print {
            .action-btn, .receipt-actions {
                display: none !important;
            }
            body {
                background: #fff !important;
            }
            .receipt-container {
                box-shadow: none;
                margin: 0;
                max-width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="receipt-container" id="receipt-area">
        <img src="image/logo.png" alt="SwimHub Logo" class="logo">
        <div class="title">SwimHub Membership Payment Receipt</div>
        <hr>
        <div class="details">
            <span class="label">Reference No:</span> <span class="value refno"><?= htmlspecialchars($row['reference_no']) ?></span><br>
            <span class="label">Date:</span> <span class="value"><?= $row['paid_date'] ?></span><br>
            <span class="label">Description:</span> <span class="value"><?= htmlspecialchars($row['description']) ?></span><br>
            <span class="label">Amount:</span> <span class="value amount">RM <?= number_format($row['amount'],2) ?></span><br>
        </div>
        <hr>
        <div class="footer">
            Thank you for your payment.<br>
            For any enquiry, contact support@swimhub.com</a>
        </div>
        <div class="receipt-actions">
            <button class="action-btn" onclick="window.print()">Print Receipt</button>
            <button class="action-btn" onclick="window.location.href='viewpayment.php'">Back</button>
        </div>
    </div>
</body>
</html>
