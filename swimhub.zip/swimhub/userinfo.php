<?php
session_start();
include 'session_check.php';

// Check if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: Login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>My Account | SwimHub</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css"> 
    <style>
        :root {
            --primary: #0284c7;
            --primary-dark: #075985;
            --primary-light: #e0f2fe;
            --accent: #06b6d4;
            --text: #1e293b;
            --text-light: #64748b;
            --background: #f0f9ff;
            --success: #10b981;
        }
        html { height: 100%; overflow-y: scroll; }
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(180deg, #e0f2fe 0%, #e0f2fe 100%);
            color: #0c4a6e;
            line-height: 1.6;
        }

        /* Dashboard Container */
        .dashboard-container {
            display: flex;
            flex-direction: row;
            max-width: 1400px;       /* unified fixed width */
            min-width: 340px;
            width: 1200%;
            margin: 48px auto 32px auto;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 5px 24px rgba(2, 132, 199, 0.10);
            background: #fff;
        }
        .sidebar {
            width: 250px;
            background-color: #fff;
            padding: 30px 20px;
            border-right: 1px solid #e2e8f0;
        }

        .content {
            flex: 1 1 0%;
            padding: 38px 42px 30px 42px;
            min-width: 0;
            max-width: 100%;
            display: flex;
            flex-direction: column;
            background: #fff;
        }

        /* Header for consistency */
        .page-header {
            text-align: center;
            margin-bottom: 40px;
        }
        .page-header h1 {
            font-family: 'Montserrat', sans-serif;
            color: var(--primary-dark);
            font-size: 2rem;
            margin-bottom: 10px;
            position: relative;
        }
        .page-header h1::after {
            content: '';
            display: block;
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            margin: 15px auto 0;
            border-radius: 2px;
        }
        .page-header p {
            color: var(--text-light);
        }

        /* Info Table */
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0 35px;
            max-width: 700px;
            margin: 0 auto 20px auto;
            background: #fff;
        }
        .info-item {
            padding: 15px 0;
            border-bottom: 1px solid #f1f5f9;
        }
        .info-label {
            font-weight: 600;
            color: var(--primary-dark);
        }
        .info-value {
            color: var(--text);
        }
        .edit-button {
            display: inline-block;
            margin-top: 35px;
            padding: 14px 36px;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            color: white;
            text-decoration: none;
            border-radius: 50px;
            font-weight: 600;
            font-size: 1.05rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(2, 132, 199, 0.3);
        }
        .edit-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(2, 132, 199, 0.4);
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .dashboard-container { max-width: 98vw; }
            .content { padding: 20px 8vw 24px 8vw; }
        }
        @media (max-width: 900px) {
            .content { padding: 16px 5vw 20px 5vw; }
        }
        @media (max-width: 768px) {
            .dashboard-container { flex-direction: column; }
            .sidebar {
                width: 100%;
                border-right: none;
                border-bottom: 1px solid #e2e8f0;
            }
            .content { padding: 16px 2vw 14px 2vw; }
            .info-grid { grid-template-columns: 1fr; gap: 0; }
        }
        @media (max-width: 480px) {
            .dashboard-container { max-width: 100vw; margin: 0; border-radius: 0; }
            .content { padding: 8px 1vw 8px 1vw; }
            .edit-button { width: 100%; font-size: 1rem; padding: 12px 0; }
        }
    </style>
</head>
<body>
<!-- User Dashboard -->
<div class="dashboard-container">
    <!-- Sidebar -->
    <?php include 'user_sidebar.php'; ?>

    <!-- Main Content -->
    <div class="content">

        <?php if (isset($_GET['success'])): ?>
            <div id="successMsg" style="margin-bottom:18px; background:#dcfce7; border:1.5px solid #86efac; color:#166534; border-radius:10px; padding:12px 18px; font-weight:600;">
                ✅ Profile updated successfully!
            </div>
            <script>
                setTimeout(function() {
                    var msg = document.getElementById('successMsg');
                    if (msg) { msg.style.display = 'none'; }
                }, 3000);
            </script>
        <?php endif; ?>

        <div class="page-header">
            <h1>My Profile</h1>
            <p>View and manage your account information</p>
        </div>
        <div class="info-grid">
            <div class="info-item">
                <div class="info-label">First Name</div>
                <div class="info-value"><?php echo htmlspecialchars($_SESSION['first_name']); ?></div>
            </div>
            <div class="info-item">
                <div class="info-label">Last Name</div>
                <div class="info-value"><?php echo htmlspecialchars($_SESSION['last_name']); ?></div>
            </div>
            <div class="info-item">
                <div class="info-label">Email</div>
                <div class="info-value"><?php echo htmlspecialchars($_SESSION['email']); ?></div>
            </div>
            <div class="info-item">
                <div class="info-label">Phone</div>
                <div class="info-value"><?php echo htmlspecialchars($_SESSION['phoneno']); ?></div>
            </div>
            <div class="info-item">
                <div class="info-label">Age</div>
                <div class="info-value"><?php echo htmlspecialchars($_SESSION['age']); ?></div>
            </div>
            <div class="info-item">
                <div class="info-label">Swim Level</div>
                <div class="info-value"><?php echo htmlspecialchars($_SESSION['swimming_level']); ?></div>
            </div>
        </div>
        <div style="text-align: center;">
            <a href="editinfo.php" class="edit-button">Edit Profile</a>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>
</body>
</html>