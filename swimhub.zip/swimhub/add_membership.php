<?php
session_start();
include 'db.php';

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) {
    header("Location: Login.php");
    exit();
}

$message = "";
$success = false;

// Handle form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $package_id = intval($_POST['package_id'] ?? 0);
    $start_date = $_POST['start_date'] ?? '';

    // Validate input
    if ($package_id <= 0) {
        $message = "Please select a package.";
    } elseif (!$start_date) {
        $message = "Please select a start date.";
    } else {
        // Check if user already has an active membership
        $check = $conn->prepare("SELECT 1 FROM user_membership WHERE user_id=? AND status='Active' LIMIT 1");
        $check->bind_param("i", $user_id);
        $check->execute();
        $check->store_result();
        if ($check->num_rows > 0) {
            $message = "You already have an active membership. Please cancel or upgrade it before adding a new one.";
        } else {
            // Get package info
            $stmt = $conn->prepare("SELECT package_duration, package_price, package_name FROM membership_package WHERE package_id=?");
            $stmt->bind_param("i", $package_id);
            $stmt->execute();
            $stmt->bind_result($package_duration, $package_price, $package_name);
            if ($stmt->fetch()) {
                // Calculate end date
                $end_date = date('Y-m-d', strtotime($start_date . " +$package_duration months"));
                $status = 'Active';
                $stmt->close();

                // Insert membership
                $ins = $conn->prepare("INSERT INTO user_membership (user_id, package_id, status, start_date, end_date) VALUES (?, ?, ?, ?, ?)");
                $ins->bind_param("iisss", $user_id, $package_id, $status, $start_date, $end_date);
                if ($ins->execute()) {
                    $membership_id = $ins->insert_id;

                    // Prevent duplicate pending payment for this membership (new)
                    $check2 = $conn->prepare("SELECT 1 FROM payment WHERE membership_id=? AND status='Pending' AND description LIKE ? LIMIT 1");
                    $descCheck = "New membership for package $package_id%";
                    $check2->bind_param("is", $membership_id, $descCheck);
                    $check2->execute();
                    $check2->store_result();
                    if ($check2->num_rows == 0) {
                        // Insert pending payment
                        $desc = "New membership for package $package_id";
                        $pay = $conn->prepare("INSERT INTO payment (user_id, membership_id, amount, status, description) VALUES (?, ?, ?, 'Pending', ?)");
                        $pay->bind_param("iids", $user_id, $membership_id, $package_price, $desc);
                        $pay->execute();
                        $pay->close();
                    }
                    $check2->close();

                    header("Location: viewpayment.php?success=1");
                    exit();
                } else {
                    $message = "Failed to add membership. Please try again.";
                }
                $ins->close();
            } else {
                $message = "Selected package not found.";
            }
        }
        $check->close();
    }
}

// Get available packages and full info for preview
$packages = [];
$result = $conn->query("SELECT package_id, package_name, package_price, package_duration, package_session, package_desc FROM membership_package");
while ($row = $result->fetch_assoc()) {
    $packages[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Membership | SwimHub</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">
<style>
:root {
    --primary: #0284c7;
    --primary-dark: #075985;
    --primary-light: #e0f2fe;
    --accent: #06b6d4;
    --text: #1e293b;
    --text-light: #64748b;
    --background: #f0f9ff;
}
body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
    background: linear-gradient(180deg, #f0f9ff 0%, #e0f2fe 100%);
    color: #0c4a6e;
    line-height: 1.6;
}
.form-card {
    background: #fff;
    border-radius: 22px;
    padding: 44px 46px 36px 46px;
    box-shadow: 0 8px 32px rgba(2, 132, 199, 0.10);
    margin: 60px auto;
    max-width: 440px;
    min-width: 340px;
}
.form-card h2 {
    text-align: center;
    color: #075985;
    font-family: 'Montserrat', sans-serif;
    margin-bottom: 26px;
    font-size: 2.2rem;
    font-weight: 700;
    letter-spacing: 0.5px;
}
.field-wrap {
    width: 100%;
    max-width: 360px;
    margin: 0 auto 18px auto;
    display: flex;
    flex-direction: column;
    align-items: stretch;
}
label {
    font-weight: 700;
    color: #0284c7;
    margin-bottom: 8px;
    font-size: 1.09rem;
    letter-spacing: 0.01em;
}
select, input[type="date"] {
    width: 100%;
    box-sizing: border-box;
    padding: 14px 12px;
    border-radius: 11px;
    border: 1.8px solid #e2e8f0;
    font-size: 1rem;
    background: #f8fafc;
    outline: none;
    transition: border 0.17s;
    margin-bottom: 0;
}
select:focus, input[type="date"]:focus {
    border-color: var(--primary);
    box-shadow: 0 0 0 2px var(--primary-light);
}
#package-details {
    margin-top: 7px;
    margin-bottom: 0;
    padding: 15px 16px 10px 16px;
    background: #f0f9ff;
    border-radius: 15px;
    color: #075985;
    font-size: 1.07rem;
    border: 1.2px solid #e0e7ef;
    display: none;
    font-weight: 500;
    width: 100%;
    max-width: 360px;
    box-sizing: border-box;
}
.form-actions {
    display: flex;
    gap: 20px;
    margin-top: 36px;
    justify-content: center;
}
.action-btn, .cancel-btn {
    padding: 14px 32px;
    border-radius: 30px;
    font-size: 1.07rem;
    font-weight: 700;
    border: none;
    cursor: pointer;
    background: linear-gradient(90deg, #0284c7, #0ea5e9);
    color: #fff;
    box-shadow: 0 3px 14px rgba(2,132,199,0.09);
    transition: background 0.19s, transform 0.18s;
    display: flex;
    align-items: center;
    gap: 8px;
}
.action-btn:hover {
    background: linear-gradient(90deg, #0369a1 0%, #0284c7 100%);
    transform: translateY(-2px) scale(1.04);
}
.cancel-btn {
    background: #64748b;
    color: #fff;
    font-weight: 600;
    text-decoration: underline;
}
.cancel-btn:hover {
    background: #475569;
}
.msg-error {
    color: #e11d48;
    background: #fff1f2;
    border: 1px solid #fca5a5;
    padding: 11px 20px;
    border-radius: 8px;
    text-align: center;
    margin-bottom: 18px;
    font-weight: 600;
    font-size: 1.05rem;
    animation: fadeIn 0.4s;
}
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-8px);}
    to { opacity: 1; transform: translateY(0);}
}
@media (max-width: 600px) {
    .form-card {padding: 30px 4vw;}
    .field-wrap, #package-details {max-width: 100%;}
}
</style>

</head>
<body>
<div class="form-card">
    <h2>Add Membership</h2>
    <?php if (!empty($message)): ?>
        <div class="msg-error"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    <form method="post" autocomplete="off">
        <div class="field-wrap">
            <label for="package_id">Select Package:</label>
            <select name="package_id" id="package_id" required>
                <option value="">-- Choose package --</option>
                <?php foreach ($packages as $pkg): ?>
                    <option value="<?= $pkg['package_id'] ?>"
                        <?= isset($_POST['package_id']) && $_POST['package_id'] == $pkg['package_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($pkg['package_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="field-wrap">
            <div id="package-details"></div>
        </div>
        <div class="field-wrap">
            <label for="start_date">Start Date:</label>
            <input type="date" name="start_date" id="start_date" required min="<?= date('Y-m-d') ?>"
                value="<?= isset($_POST['start_date']) ? htmlspecialchars($_POST['start_date']) : date('Y-m-d') ?>">
        </div>
        <div class="form-actions">
            <button type="submit" class="action-btn">
                <svg style="margin-right:7px" width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="#fff" stroke-width="2" stroke-linecap="round"/></svg>
                Add Membership
            </button>
            <a href="managemembership.php" class="cancel-btn">Cancel</a>
        </div>
    </form>
</div>

<script>
const packages = <?= json_encode($packages) ?>;
document.getElementById('package_id').addEventListener('change', function() {
    let pkgId = this.value;
    let info = '';
    if (pkgId && packages.length) {
        let pkg = packages.find(p => p.package_id == pkgId);
        if (pkg) {
            info = `
                <div style="margin-bottom:2px"><b>${pkg.package_name}</b></div>
                <div><span style="color:#0284c7">RM${parseFloat(pkg.package_price).toFixed(2)}</span> · Duration: ${pkg.package_duration} month(s)</div>
                <div>Sessions: ${pkg.package_session ? pkg.package_session : 'Unlimited'}</div>
                <div style="margin-top:2px">${pkg.package_desc ? pkg.package_desc : ''}</div>
            `;
        }
    }
    const details = document.getElementById('package-details');
    if (info) {
        details.innerHTML = info;
        details.style.display = 'block';
    } else {
        details.innerHTML = '';
        details.style.display = 'none';
    }
});

// Auto-trigger details if POST (for edit/retain)
window.onload = function() {
    const pkgId = document.getElementById('package_id').value;
    if (pkgId) document.getElementById('package_id').dispatchEvent(new Event('change'));
}
</script>
</body>
</html>
