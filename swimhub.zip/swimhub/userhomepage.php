<?php
session_start();
include 'session_check.php';  
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: Login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$first_name = $_SESSION['first_name'] ?? 'User';

// Fetch active membership (latest)
$stmt = $conn->prepare("SELECT um.*, mp.package_name FROM user_membership um
    JOIN membership_package mp ON um.package_id = mp.package_id
    WHERE um.user_id=? AND um.status='Active' ORDER BY um.end_date DESC LIMIT 1");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$current = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Fetch latest pending payment for this user's membership
$pending_payment = null;
if ($current) {
    $pay_stmt = $conn->prepare("SELECT * FROM payment WHERE membership_id=? AND status='Pending' ORDER BY payment_id DESC LIMIT 1");
    $pay_stmt->bind_param("i", $current['membership_id']);
    $pay_stmt->execute();
    $pending_payment = $pay_stmt->get_result()->fetch_assoc();
    $pay_stmt->close();
}

// Fetch all user's pending payments (for alert at the top)
$pstmt = $conn->prepare("SELECT * FROM payment WHERE user_id=? AND status='Pending' ORDER BY payment_id DESC");
$pstmt->bind_param("i", $user_id);
$pstmt->execute();
$pending_payments = $pstmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account | SwimHub</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">

    <style>
        :root {
            --primary: #0284c7;
            --primary-dark: #075985;
            --primary-light: #e0f2fe;
            --accent: #06b6d4;
            --text: #1e293b;
            --text-light: #64748b;
            --background: #f0f9ff;
            --success: #10b981;
        }
        html { height: 100%; overflow-y: scroll; }
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(180deg, #e0f2fe 0%, #e0f2fe 100%);
            color: #0c4a6e;
            line-height: 1.6;
        }

        /* Consistent Dashboard Container */
        .dashboard-container {
            display: flex;
            flex-direction: row;
            max-width: 1400px;       /* unified fixed width */
            min-width: 340px;
            width: 1200%;
            margin: 48px auto 32px auto;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 5px 24px rgba(2, 132, 199, 0.10);
            background: #fff;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background-color: #fff;
            padding: 30px 20px;
            border-right: 1px solid #e2e8f0;
        }
        .sidebar h3 {
            margin-bottom: 25px;
            color: var(--primary-dark);
            font-family: 'Montserrat', sans-serif;
            font-size: 1.3rem;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--primary-light);
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar li {
            margin-bottom: 8px;
        }
        .sidebar a {
            text-decoration: none;
            color: var(--text);
            display: block;
            padding: 12px 15px;
            background-color: #f9f9f9;
            border-radius: 8px;
            transition: all 0.3s ease;
            font-size: 0.95rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .sidebar a:hover {
            background-color: var(--primary-light);
            color: var(--primary-dark);
        }
        .sidebar a.active {
            background: linear-gradient(90deg, var(--primary), var(--accent));
            color: white;
            box-shadow: 0 3px 10px rgba(2, 132, 199, 0.3);
        }

        /* Main Content */
        .content {
            flex: 1 1 0%;
            padding: 38px 42px 30px 42px;
            min-width: 0;
            max-width: 100%;
            display: flex;
            flex-direction: column;
            background: #fff;
        }

        .page-header {
            text-align: center;
            margin-bottom: 40px;
        }
        .page-header h1 {
            font-family: 'Montserrat', sans-serif;
            color: var(--primary-dark);
            font-size: 2rem;
            margin-bottom: 10px;
            position: relative;
        }
        .page-header h1::after {
            content: '';
            display: block;
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            margin: 15px auto 0;
            border-radius: 2px;
        }
        .page-header p {
            color: var(--text-light);
        }
        .user-sidebar {
            width: 260px;
            min-width: 200px;
        }

        /* Card */
        .dashboard-card {
            width: 80%;
            max-width: 700px;
            margin: 0 auto 28px auto;
            background: #fff;
            border-radius: 18px;
            box-shadow: 0 2px 18px rgba(2, 132, 199, 0.07);
            padding: 36px 34px 28px 34px;
        }

        /* Pending Payment Alert */
        .pending-alert {
            background: #fffbe7;
            color: #c2410c;
            border: 1.5px solid #fde68a;
            padding: 16px 20px;
            border-radius: 10px;
            margin-bottom: 24px;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 24px;
            box-shadow: 0 2px 10px rgba(255, 187, 56, 0.06);
            max-width: 900px;
            margin-left: auto;
            margin-right: auto;
        }
        .pending-alert span { font-size: 1.05rem; }
        .pending-alert b { color: #0c4a6e; }

        /* Pay Now Button */
        .pay-btn {
            background: linear-gradient(90deg, #0284c7, #0ea5e9);
            color: #fff;
            font-weight: 600;
            border: none;
            border-radius: 20px;
            padding: 9px 24px;
            cursor: pointer;
            font-size: 1rem;
            box-shadow: 0 2px 7px rgba(2, 132, 199, 0.08);
            margin-left: 24px;
            transition: background 0.15s, transform 0.13s;
        }
        .pay-btn:hover {
            background: linear-gradient(90deg, #0369a1, #0284c7 100%);
            transform: scale(1.05) translateY(-1px);
        }

        /* Membership Status Indicator (the green dot) */
        .status-indicator {
            display: inline-block;
            width: 14px;
            height: 14px;
            border-radius: 50%;
            background: #10b981;
            margin-right: 12px;
            vertical-align: middle;
            box-shadow: 0 0 0 2px #ecfdf5;
        }
        .membership-status {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 5px;
        }
        .membership-status.inactive .status-indicator { background: #d1d5db; }

        /* Responsive */
        @media (max-width: 1024px) {
            .dashboard-container { max-width: 98vw; }
            .content { padding: 20px 8vw 24px 8vw; }
        }
        @media (max-width: 768px) {
            .dashboard-container { flex-direction: column; }
            .sidebar {
                width: 100%;
                border-right: none;
                border-bottom: 1px solid #e2e8f0;
            }
            .content { padding: 20px 5vw 24px 5vw; }
        }
        @media (max-width: 480px) {
            .dashboard-container { max-width: 100vw; margin: 0; border-radius: 0; }
            .content { padding: 14px 2vw 18px 2vw; }
        }
    </style>
</head>
<body>
    <!-- Main Content -->
    <div class="dashboard-container">
        <?php include 'user_sidebar.php'; ?>
        <div class="content">
            <div class="welcome-section">
                <h1>Welcome, <?= htmlspecialchars($first_name) ?>!</h1>
            </div>

            <!-- Show Pending Payments Alert -->
            <?php if ($pending_payments->num_rows > 0): ?>
                <?php while($row = $pending_payments->fetch_assoc()): ?>
                    <div class="pending-alert">
                        <span>&#9888;</span>
                        <span>
                            You have a pending payment: <b><?= htmlspecialchars($row['description']) ?></b>
                            <br>
                            Amount: <b>RM<?= number_format($row['amount'],2) ?></b>
                        </span>
                        <form method="get" action="gateway.php" style="margin:0;">
                            <input type="hidden" name="payment_id" value="<?= $row['payment_id'] ?>">
                            <button type="submit" class="pay-btn">Pay Now</button>
                        </form>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>

            <!-- Membership Summary -->
            <div class="dashboard-card">
                <h2>🏊‍♂️ Membership Summary</h2>
                <p>Your current membership details and status</p>
                <?php if ($current): ?>
                    <?php
                        // Membership status: show 'Pending' if there's a pending payment for this membership
                        $status_display = ($pending_payment) ? 'Pending' : $current['status'];
                    ?>
                    <div class="membership-status<?= $status_display == 'Active' ? '' : ' inactive' ?>">
                        <div class="status-indicator"></div>
                        <div>
                            <strong><?= htmlspecialchars($status_display) ?> Membership</strong>
                            <div><?= htmlspecialchars($current['package_name']) ?></div>
                        </div>
                    </div>
                    <div style="margin: 6px 0 7px 0;">
                        <span class="membership-summary-label">Next payment due:</span>
                        <strong><?= date('F j, Y', strtotime($current['end_date'])) ?></strong>
                    </div>
    
                <?php else: ?>
                    <div class="membership-status inactive">
                        <div class="status-indicator"></div>
                        <strong>No Active Membership</strong>
                    </div>
                    <div>You do not have an active membership at this time.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>