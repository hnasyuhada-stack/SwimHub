<?php 
session_start();
include 'db.php';

// Check if user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: Login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$first_name = $last_name = $email = $phoneno = $age = $swimming_level = "";

// Fetch user data from database
$sql = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 1) {
    $row = $result->fetch_assoc();
    $first_name     = $row['first_name'];
    $last_name      = $row['last_name'];
    $email          = $row['email'];
    $phoneno        = $row['phoneno'];
    $age            = $row['age'];
    $swimming_level = $row['swimming_level'];
} else {
    die("User not found.");
}
$stmt->close();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name     = trim($_POST['firstname']);
    $last_name      = trim($_POST['lastname']);
    $phoneno        = trim($_POST['phone']);
    $age            = trim($_POST['age']);
    $swimming_level = trim($_POST['swimlevel']);

    // Validation (basic for now)
    if (!empty($first_name) && !empty($last_name) && !empty($phoneno) && !empty($age)) {
        $sql = "UPDATE users SET first_name = ?, last_name = ?, phoneno = ?, age = ?, swimming_level = ? WHERE user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssi", $first_name, $last_name, $phoneno, $age, $swimming_level, $user_id);

        if ($stmt->execute()) {
            // Update session variables to keep everything in sync
            $_SESSION['first_name']     = $first_name;
            $_SESSION['last_name']      = $last_name;
            $_SESSION['phoneno']        = $phoneno;
            $_SESSION['age']            = $age;
            $_SESSION['swimming_level'] = $swimming_level;

            header("Location: userinfo.php?success=1");
            exit();
        } else {
            echo "<script>alert('Error updating record.');</script>";
        }
    } else {
        echo "<script>alert('Please fill all required fields.');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Account Details | SwimHub</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles/styles.css">

<style>
:root {
    --primary: #0284c7;
    --primary-dark: #075985;
    --primary-light: #e0f2fe;
    --accent: #06b6d4;
    --text: #1e293b;
    --text-light: #64748b;
    --background: #f0f9ff;
    --input-radius: 12px;
}
html { height: 100%; overflow-y: scroll; }
body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
    background: linear-gradient(180deg, #e0f2fe 0%, #e0f2fe 100%);
    color: #0c4a6e;
    line-height: 1.6;
}

      /* Dashboard Container */
        .dashboard-container {
            display: flex;
            flex-direction: row;
            max-width: 1400px;       /* unified fixed width */
            min-width: 340px;
            width: 1200%;
            margin: 48px auto 32px auto;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 5px 24px rgba(2, 132, 199, 0.10);
            background: #fff;
        }
.sidebar {
    width: 250px;
    background-color: #fff;
    padding: 30px 20px;
    border-right: 1px solid #e2e8f0;
}
.content {
    flex: 1 1 0%;
    padding: 48px 0 30px 0;
    display: flex;
    flex-direction: column;
    background: #fff;
    align-items: center;
    min-height: 700px;
}
.page-header {
    text-align: center;
    margin-bottom: 32px;
}
.page-header h1 {
    font-family: 'Montserrat', sans-serif;
    color: var(--primary-dark);
    font-size: 2rem;
    margin-bottom: 8px;
    font-weight: 700;
    position: relative;
}
.page-header h1::after {
    content: '';
    display: block;
    width: 80px;
    height: 4px;
    background: linear-gradient(90deg, var(--primary), var(--accent));
    margin: 15px auto 0;
    border-radius: 2px;
}
.page-header p {
    color: var(--text-light);
    margin-bottom: 12px;
    font-size: 1rem;
}

/* ---------- FORM GRID & FIELDS ---------- */
.edit-form-grid {
    display: flex;
    flex-direction: column;
    gap: 32px; /* Space BETWEEN rows */
    max-width: 580px;
    margin: 0 auto 36px auto;
    width: 100%;
}
.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px; /* Space BETWEEN columns (inputs in a row) */
}
@media (max-width: 700px) {
    .form-row {
        grid-template-columns: 1fr;
        gap: 18px;
    }
}
.edit-form-grid button[type="submit"] {
    margin-top: 30px;
}



label {
    font-weight: 700;
    color: var(--primary-dark);
    margin-bottom: 10px; /* slightly more spacing for visual comfort */
    font-size: 1.1rem;
    letter-spacing: 0.1px;
}
input[type="text"],
input[type="email"],
input[type="number"],
select {
    width: 100%;
    padding: 18px 18px; /* more vertical space */
    border: 2px solid #e2e8f0;
    border-radius: var(--input-radius);
    font-family: 'Poppins', sans-serif;
    font-size: 1.08rem;
    background-color: #f8fafc;
    box-shadow: none;
    transition: all 0.3s;
}
input[type="text"]:focus,
input[type="email"]:focus,
input[type="number"]:focus,
select:focus {
    border-color: var(--primary);
    outline: none;
    background-color: white;
}
input[readonly] {
    background-color: #f1f5f9;
    color: var(--text-light);
    font-weight: 500;
}
/* Button at full grid width */
.edit-form-grid button[type="submit"] {
    grid-column: 1 / span 2;
    background: linear-gradient(90deg, var(--primary), var(--accent));
    color: white;
    border: none;
    padding: 20px 0;
    border-radius: 40px;
    font-size: 1.13rem;
    font-weight: 700;
    cursor: pointer;
    box-shadow: 0 5px 20px rgba(2,132,199,0.13);
    margin-top: 20px;
    letter-spacing: 0.3px;
    transition: all 0.2s;
}
.edit-form-grid button[type="submit"]:hover {
    background: linear-gradient(90deg, #0369a1, #22d3ee 90%);
    transform: translateY(-2px) scale(1.03);
    box-shadow: 0 9px 24px rgba(2, 132, 199, 0.18);
}

/* Responsive Adjustments */
@media (max-width: 900px) {
    .dashboard-container { max-width: 98vw; }
    .content { padding: 22px 0 18px 0; }
    .edit-form-grid { max-width: 95vw; }
}
@media (max-width: 700px) {
    .edit-form-grid { grid-template-columns: 1fr; gap: 22px 0; }
    .edit-form-grid button[type="submit"] { grid-column: 1 / 2; }
}
@media (max-width: 480px) {
    .dashboard-container { max-width: 100vw; margin: 0; border-radius: 0; }
    .content { padding: 8px 0 8px 0; }
    .edit-form-grid { padding: 0 3vw; }
    .edit-form-grid button[type="submit"] { font-size: 1rem; padding: 13px 0; }
}
</style>

</head>
<body>
<!-- User Dashboard -->
<div class="dashboard-container">
    <?php include 'user_sidebar.php'; ?>
    <div class="content">
        <div class="page-header">
            <h1>Account Details</h1>
            <p>Update your account information</p>
        </div>
        <form class="edit-form-grid" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <!-- Row 1 -->
            <div class="form-group">
                <label for="firstname">First Name</label>
                <input type="text" id="firstname" name="firstname" value="<?php echo htmlspecialchars($first_name); ?>" required>
            </div>
            <div class="form-group">
                <label for="lastname">Last Name</label>
                <input type="text" id="lastname" name="lastname" value="<?php echo htmlspecialchars($last_name); ?>" required>
            </div>
            <!-- Row 2 -->
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" value="<?php echo htmlspecialchars($email); ?>" readonly>
            </div>
            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($phoneno); ?>" required>
            </div>
            <!-- Row 3 -->
            <div class="form-group">
                <label for="age">Age</label>
                <input type="number" id="age" name="age" value="<?php echo htmlspecialchars($age); ?>" required>
            </div>
            <div class="form-group">
                <label for="swimlevel">Swimming Level</label>
                <select id="swimlevel" name="swimlevel">
                    <option value="Beginner" <?php if ($swimming_level === 'Beginner') echo 'selected'; ?>>Beginner</option>
                    <option value="Intermediate" <?php if ($swimming_level === 'Intermediate') echo 'selected'; ?>>Intermediate</option>
                    <option value="Advanced" <?php if ($swimming_level === 'Advanced') echo 'selected'; ?>>Advanced</option>
                </select>
            </div>
            <button type="submit">Save Changes</button>
        </form>
    </div>
</div>
</body>
</html>
