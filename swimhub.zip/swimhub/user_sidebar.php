<div class="sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <img src="image/logo.png" alt="Logo">
        </div>
        <h3>User Homepage</h3>
    </div>
<ul>
    <li><a href="userhomepage.php" class="<?php if(basename($_SERVER['PHP_SELF'])=='userhomepage.php') echo 'active'; ?>">Home Page</a></li>
<li>
  <a href="managemembership.php" class="<?php if(basename($_SERVER['PHP_SELF'])=='managemembership.php') echo 'active'; ?>">Manage Membership</a>
</li>

    <li><a href="viewpayment.php" class="<?php if(basename($_SERVER['PHP_SELF'])=='viewpayment.php') echo 'active'; ?>">View Payment</a></li>
    <li><a href="userinfo.php" class="<?php if(basename($_SERVER['PHP_SELF'])=='userinfo.php') echo 'active'; ?>">Account Details</a></li>
    <li><a href="Logout.php">Log Out</a></li>
</ul>

</div>
